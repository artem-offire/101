import test from "node:test";
import assert from "node:assert/strict";
import { toWire, fromWire, composeAddress } from "../js/cardAdapter.js";

test("адреса складається в один рядок без порожніх частин", () => {
  assert.equal(composeAddress({ city: "Львів", street: "вул. Наукова", house: "17а", flat: "29", landmark: "" }), "Львів, вул. Наукова, 17а, кв. 29");
  assert.equal(composeAddress({ city: " ", street: "", house: "7" }), "7");
});
test("тип події і кількість постраждалих відповідають контракту бекенда", () => {
  const w = toWire({ incident_type: "Газ, загазованість", victims: "2", city: "Львів", street: "Наукова", house: "17а" });
  assert.equal(w.incident_type, "газ");
  assert.equal(w.victims, 2);
  assert.equal(w.address, "Львів, Наукова, 17а");
  assert.equal(toWire({ incident_type: "Рятування людей" }).incident_type, "рятування");
  assert.equal(toWire({ victims: "" }).victims, "");
  assert.equal(toWire({ victims: "abc" }).victims, "");
  assert.equal(toWire({ victims: "-3" }).victims, 0);
});
test("поверхи, загроза вибуху і під'їзд", () => {
  const w = toWire({ floors: "9", explosion: "Є", access: " шлагбаум " });
  assert.equal(w.floors, 9);
  assert.equal(w.explosion, "так");
  assert.equal(w.access, "шлагбаум");
  assert.equal(toWire({ explosion: "Немає" }).explosion, "ні");
  assert.equal(toWire({ explosion: "Невідомо" }).explosion, "невідомо");
  assert.equal(toWire({ floors: "" }).floors, "");
  assert.equal(toWire({ floors: "x" }).floors, "");
  assert.equal(toWire({ floors: "-2" }).floors, 0);
});
test("поля «стан постраждалих» більше немає", () => {
  const w = toWire({ victims_state: "Легкі" });
  assert.equal("ui_victims_state" in w, false);
  assert.equal("victims_state" in fromWire({}), false);
});
test("круговий обмін зберігає поля", () => {
  const ui = { incident_type: "Пожежа", victims: "1", explosion: "Є", floors: "5", access: "шлагбаум", city: "Львів", street: "Зелена", house: "3", flat: "9", landmark: "біля аптеки", caller_name: "Мельник", phone: "+380501234567", notes: "дим" };
  assert.deepEqual(fromWire(toWire(ui)), ui);
});
test("стара картка без ui_* потрапляє в поле міста, нічого не губиться", () => {
  const ui = fromWire({ incident_type: "пожежа", address: "Одеса, Дерибасівська 5", victims: 1 });
  assert.equal(ui.city, "Одеса, Дерибасівська 5");
  assert.equal(ui.incident_type, "Пожежа");
  assert.equal(ui.explosion, "Невідомо");
});
