// Контролер екрана виклику: єдине місце, що знає про WebSocket, мікрофон і синтез голосу.
// Візуальна частина (callScreen.js) отримує лише props і викликає on*-обробники.
import { api, wsUrl, toast } from "./core.js";
import { CallerVoice, OperatorASR, playSound } from "./voice.js";
import { mount } from "./callScreen.js";
import { toWire, fromWire } from "./cardAdapter.js";

const STAGE = /^\([^)]*\)\s*/;
const strip = (t) => String(t || "").replace(STAGE, "").trim();

export async function renderCall(app, user, callId) {
  app.classList.add("call");
  const st = {
    phase: "connecting", connection: "online", elapsed: 0, card: fromWire({}), dirty: {}, saveStatus: "idle",
    utterance: null, caption: "", emotion: null, partial: "", transcript: [], micOn: false, micLevel: 0, micError: false,
    mode: "voice", canOpenReport: false, actions: {},
  };
  let ws = null, closed = false, started = false, finished = false, retry = 0, reconnectT = 0;
  let tStart = performance.now(), tOffset = 0, lastFinalAt = null, typingT0 = null, startSent = false, vadTimer = 0, partialSent = 0;
  let cardTimer = 0, cardPending = false, pollT = 0, delayT = 0;

  const ui = mount(app, { ...st, onEditCard, onSend, onAccept, onEnd, onToggleMic, onMicHold, onAction, onHome: () => { location.hash = "#/home"; }, onOpenReport: () => { location.hash = `#/report/${callId}`; } });
  const push = (patch) => { Object.assign(st, patch); ui.update(patch); };
  ui.focusTitle();

  // ── Голос ───────────────────────────────────────────
  const voice = new CallerVoice({
    onStart: (item) => {
      if (item.filler) return;
      const p = { uid: item.uid };
      if (lastFinalAt) { p.latency_ms = Math.round(performance.now() - lastFinalAt); lastFinalAt = null; }
      send("tts.playing", p);
    },
    onEnd: (item, played, completed) => {
      if (item.filler) return;
      send("tts.stopped", { uid: item.uid, played_chars: completed ? item.text.length : played });
    },
  });
  const asr = new OperatorASR({
    onStart: () => operatorStart(),
    onPartial: (t) => {
      push({ partial: t });
      if (performance.now() - partialSent > 300) { partialSent = performance.now(); send("operator.partial", { text: t }); }
    },
    onFinal: (t, dur) => { push({ partial: "" }); finalize(t, dur, true); },
    onState: (on, err) => push({ micOn: on, micError: !!err, micLevel: on ? st.micLevel : 0 }),
    onLevel: (v) => push({ micLevel: v }),
  });
  push({ mode: asr.supported ? "voice" : "text" });

  function onToggleMic() { if (asr.supported) asr.toggle(); }
  function onMicHold(down) { if (asr.supported && down !== asr.on) asr.toggle(); }

  // ── Дії курсанта ─────────────────────────────────────
  function operatorStart() { if (!startSent) { startSent = true; send("operator.speech_start", {}); } }
  function onSend(text) {
    operatorStart();
    finalize(text, typingT0 ? Math.round(performance.now() - typingT0) : 0, false);
  }
  function finalize(text, dur, fromAsr) {
    clearTimeout(vadTimer);
    send("operator.final", { text, duration_ms: dur, asr: fromAsr });
    lastFinalAt = performance.now(); typingT0 = null; startSent = false;
  }
  // перебивання друком: перший символ, що трималася довше 300 мс, вважаємо початком мовлення
  const onTyping = (e) => {
    if (e.target.id !== "reply" || e.key.length !== 1 || e.ctrlKey || e.metaKey || typingT0 !== null) return;
    typingT0 = performance.now();
    vadTimer = setTimeout(operatorStart, 300);
  };
  app.addEventListener("keydown", onTyping);

  function onAccept() { send("call.accept", {}); goLive(0); }
  function onEnd() { if (finished) return; send("call.end", { reason: "operator" }); endUi("operator"); }
  // кнопки «Тривога» і «Доповідь»: одна відправка на дію, час показуємо одразу
  function onAction(id) {
    if (finished || st.actions[id] != null) return;
    if (!send("operator.action", { action: id })) return;
    push({ actions: { ...st.actions, [id]: Math.round(st.elapsed * 1000) } });
  }
  function goLive(offset) {
    started = true; tOffset = offset; tStart = performance.now();
    if (st.phase === "connecting" || st.phase === "incoming") push({ phase: "live" });
  }

  // ── Картка ──────────────────────────────────────────
  function onEditCard(key, value) {
    const card = { ...st.card, [key]: value };
    push({ card, dirty: { ...st.dirty, [key]: true }, saveStatus: "saving" });
    clearTimeout(cardTimer);
    cardTimer = setTimeout(flushCard, 500);
  }
  function flushCard() {
    if (!send("card.updated", { fields: toWire(st.card) })) { cardPending = true; push({ saveStatus: "offline" }); return; }
    cardPending = false;
    push({ saveStatus: "saved", dirty: {} });
  }

  // ── Таймер: стоїть, поки зв'язку немає ─────────────────
  const tick = setInterval(() => {
    if (started && !finished && st.connection === "online") push({ elapsed: tOffset + (performance.now() - tStart) / 1000 });
  }, 500);

  // ── Завершення і очікування звіту ──────────────────────
  function endUi(reason) {
    if (finished) return;
    finished = true;
    voice.stop(); if (asr.on) asr.toggle();
    push({ phase: "ending", partial: "", reason });
    delayT = setTimeout(() => push({ phase: "reportDelayed", canOpenReport: true }), 20000);
    pollT = setInterval(async () => {
      try { const s = await api.get(`/api/sessions/${callId}`); if (s && s.status === "done") toReport(); } catch { /* повторимо */ }
    }, 3000);
  }
  function toReport() { if (!closed) { closed = true; location.hash = `#/report/${callId}`; } }

  // ── WebSocket ────────────────────────────────────────
  function send(type, payload) {
    if (ws && ws.readyState === 1) { ws.send(JSON.stringify({ type, payload })); return true; }
    return false;
  }
  const addLine = (uid, who, text) => {
    if (!text || st.transcript.some((m) => m.uid === uid)) return;
    st.transcript = [...st.transcript, { uid, who, text }];
    ui.update({ transcript: st.transcript });
  };
  const emotionOf = (c) => {
    if (!c || c.panic === undefined) return null;
    const p = +c.panic;
    return p >= 7 ? { level: "high", label: "Дуже схвильований" } : p >= 4 ? { level: "mid", label: "Напружений" } : { level: "low", label: "Спокійний" };
  };

  function connect() {
    ws = new WebSocket(wsUrl(`/ws/call/${callId}?role=trainee&name=${encodeURIComponent(user.name)}`));
    ws.onopen = () => { retry = 0; };
    ws.onmessage = (m) => {
      const ev = JSON.parse(m.data);
      const p = ev.payload || {};
      switch (ev.type) {
        case "error": push({ phase: "unavailable" }); closed = true; break;
        case "call.snapshot": {
          (p.transcript || []).forEach((u) => addLine(u.id, u.who === "caller" ? "caller" : "op", strip(u.text)));
          const lastCaller = [...(p.transcript || [])].reverse().find((u) => u.who === "caller");
          const patch = { connection: "online", emotion: emotionOf(p.caller) };
          if (lastCaller && !st.utterance) patch.utterance = { uid: lastCaller.id, text: strip(lastCaller.text) };
          if (p.card && !Object.keys(st.dirty).length) patch.card = fromWire(p.card);
          if (p.actions) patch.actions = p.actions;
          push(patch);
          if (p.finished) { started = true; endUi(p.end_reason); }
          else if (p.started) goLive(p.t_now || 0);
          else push({ phase: "incoming" });
          if (cardPending || Object.keys(st.dirty).length) flushCard();
          break;
        }
        case "caller.utterance": {
          const text = strip(p.text);
          push({ utterance: { uid: p.uid, text }, caption: "" });
          addLine(p.uid, "caller", text);
          if (p.panic !== undefined) push({ emotion: emotionOf(p) });
          break;
        }
        case "operator.action": push({ actions: { ...st.actions, [p.action]: ev.t } }); break;
        case "operator.final": addLine(p.uid, "op", p.text); break;
        case "tts.say": voice.say(p); break;
        case "tts.stop": voice.stop(); break;
        case "scene.event":
          if (p.sound) playSound(p.sound);
          if (p.caption) { push({ caption: p.caption }); addLine(`scene-${ev.t}-${p.caption}`, "scene", p.caption); }
          break;
        case "caller.emotion": if (p.panic !== undefined) push({ emotion: emotionOf(p) }); break;
        case "call.restored": toast("Дзвінок відновлено з місця, де ви зупинилися. Спробуйте інакше.", 4000); break;
        case "call.end": endUi(p.reason); break;
        case "report.ready": setTimeout(toReport, 600); break;
        default: break;
      }
    };
    ws.onclose = () => {
      if (closed || finished) return;
      push({ connection: "reconnecting" });
      reconnectT = setTimeout(connect, Math.min(8000, 1000 * 2 ** retry++));
    };
  }
  connect();

  const onBeforeUnload = (e) => { if (started && !finished) { e.preventDefault(); e.returnValue = ""; } };
  window.addEventListener("beforeunload", onBeforeUnload);

  const cleanup = () => {
    closed = true;
    clearInterval(tick); clearInterval(pollT); clearTimeout(delayT); clearTimeout(reconnectT); clearTimeout(cardTimer); clearTimeout(vadTimer);
    window.removeEventListener("beforeunload", onBeforeUnload);
    app.removeEventListener("keydown", onTyping);
    voice.stop(); if (asr.on) asr.toggle();
    if (ws) { ws.onclose = null; ws.close(); }
    ui.destroy();
    app.classList.remove("call");
  };
  cleanup.isActive = () => started && !finished;
  return cleanup;
}
