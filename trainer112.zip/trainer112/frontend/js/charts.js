// Лінійний графік на SVG: паніка/довіра в часі, маркери подій, підказка при наведенні.
import { h, fmtT, tok } from "./core.js";

const NS = "http://www.w3.org/2000/svg";
const s = (tag, attrs = {}) => { const e = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v); return e; };

export function lineChart({ series, xMax, yMax = 10, height = 220, markers = [], onPick }) {
  const W = 800, H = height, L = 34, R = 12, T = 12, B = 26;
  const wrap = h("div.chart");
  const svg = s("svg", { viewBox: `0 0 ${W} ${H}`, preserveAspectRatio: "none", style: `height:${H}px` });
  const X = (x) => L + (x / Math.max(1, xMax)) * (W - L - R);
  const Y = (y) => T + (1 - y / yMax) * (H - T - B);
  for (let y = 0; y <= yMax; y += yMax / 5) {
    svg.append(s("line", { x1: L, x2: W - R, y1: Y(y), y2: Y(y), stroke: tok("--line"), "stroke-width": 1 }));
    const tx = s("text", { x: L - 8, y: Y(y) + 4, fill: tok("--faint"), "font-size": 13, "text-anchor": "end", "font-family": "JetBrains Mono, monospace" });
    tx.textContent = Math.round(y); svg.append(tx);
  }
  const stepX = xMax > 240000 ? 60000 : 30000;
  for (let x = 0; x <= xMax; x += stepX) {
    const tx = s("text", { x: X(x), y: H - 6, fill: tok("--faint"), "font-size": 13, "text-anchor": "middle", "font-family": "JetBrains Mono, monospace" });
    tx.textContent = fmtT(x); svg.append(tx);
  }
  for (const m of markers) {
    svg.append(s("line", { x1: X(m.x), x2: X(m.x), y1: T, y2: H - B, stroke: m.color || tok("--amber"), "stroke-width": 1.5, "stroke-dasharray": "3 4", opacity: .7 }));
  }
  for (const se of series) {
    if (!se.points.length) continue;
    // ступінчаста лінія: значення змінюється подіями
    let d = "";
    se.points.forEach((p, i) => {
      if (i === 0) d += `M${X(p.x)},${Y(p.y)}`;
      else d += `H${X(p.x)}V${Y(p.y)}`;
    });
    d += `H${X(xMax)}`;
    if (se.fill) {
      const area = d + `V${Y(0)}H${X(se.points[0].x)}Z`;
      svg.append(s("path", { d: area, fill: se.color, opacity: .08 }));
    }
    svg.append(s("path", { d, fill: "none", stroke: se.color, "stroke-width": 2.5, "stroke-linejoin": "round" }));
    for (const p of se.points) {
      if (!p.label) continue;
      const c = s("circle", { cx: X(p.x), cy: Y(p.y), r: 4, fill: se.color, stroke: tok("--panel"), "stroke-width": 2 });
      c.style.cursor = "pointer"; svg.append(c);
    }
  }
  const cursor = s("line", { y1: T, y2: H - B, stroke: tok("--muted"), "stroke-width": 1, opacity: 0 });
  svg.append(cursor);
  const tip = h("div.tip.hidden");
  wrap.append(svg, tip);
  const valueAt = (pts, x) => { let v = null; for (const p of pts) { if (p.x <= x) v = p; else break; } return v; };
  svg.addEventListener("mousemove", (e) => {
    const r = svg.getBoundingClientRect();
    const px = ((e.clientX - r.left) / r.width) * W;
    const x = Math.max(0, Math.min(xMax, ((px - L) / (W - L - R)) * xMax));
    cursor.setAttribute("x1", X(x)); cursor.setAttribute("x2", X(x)); cursor.setAttribute("opacity", .6);
    const lines = [h("div.mono.faint", fmtT(x))];
    let reason = null;
    for (const se of series) {
      const v = valueAt(se.points, x);
      if (v) { lines.push(h("div", h("b", { style: { color: se.color } }, `${se.name}: ${(+v.y).toFixed(1)}`))); if (v.label && x - v.x < 8000) reason = v.label; }
    }
    const mk = markers.find((m) => Math.abs(m.x - x) < xMax / 60);
    if (mk) lines.push(h("div", { class: "check-late" }, mk.label));
    if (reason) lines.push(h("div.muted", reason));
    tip.replaceChildren(...lines); tip.classList.remove("hidden");
    const left = ((X(x)) / W) * r.width;
    tip.style.left = `${Math.min(r.width - 200, left + 10)}px`; tip.style.top = "6px";
  });
  svg.addEventListener("mouseleave", () => { tip.classList.add("hidden"); cursor.setAttribute("opacity", 0); });
  if (onPick) svg.addEventListener("click", (e) => {
    const r = svg.getBoundingClientRect(); const px = ((e.clientX - r.left) / r.width) * W;
    onPick(Math.max(0, Math.min(xMax, ((px - L) / (W - L - R)) * xMax)));
  });
  return wrap;
}

export function emotionChart(series, xMax, markers = [], onPick) {
  const pts = (k) => series.map((e) => ({ x: e.t, y: e[k], label: e.reason }));
  return lineChart({
    series: [{ name: "Паніка", color: tok("--red"), points: pts("panic"), fill: true },
             { name: "Довіра", color: tok("--blue"), points: pts("trust") }],
    xMax: Math.max(xMax, 30000), markers, onPick,
  });
}

export function sparkline(values, { w = 120, hgt = 32, color = tok("--blue"), max = null } = {}) {
  const svg = s("svg", { viewBox: `0 0 ${w} ${hgt}`, width: w, height: hgt });
  if (values.length < 2) return svg;
  const mx = max ?? Math.max(...values, 1);
  const d = values.map((v, i) => `${i ? "L" : "M"}${(i / (values.length - 1)) * (w - 4) + 2},${hgt - 2 - (v / mx) * (hgt - 4)}`).join("");
  svg.append(s("path", { d, fill: "none", stroke: color, "stroke-width": 2 }));
  return svg;
}

export function scoreRing(score, passed) {
  const r = 54, c = 2 * Math.PI * r, col = passed ? tok("--green") : tok("--red");
  const svg = s("svg", { viewBox: "0 0 132 132" });
  svg.append(s("circle", { cx: 66, cy: 66, r, fill: "none", stroke: tok("--line"), "stroke-width": 10 }));
  const arc = s("circle", { cx: 66, cy: 66, r, fill: "none", stroke: col, "stroke-width": 10, "stroke-linecap": "round", class: "arc", "stroke-dasharray": `0 ${c}` });
  svg.append(arc);
  requestAnimationFrame(() => requestAnimationFrame(() => arc.setAttribute("stroke-dasharray", `${(c * score) / 100} ${c}`)));
  return h("div.score-ring", svg, h("div.val", h("div", h("b", Math.round(score)), h("span.small.muted", "балів"))));
}
