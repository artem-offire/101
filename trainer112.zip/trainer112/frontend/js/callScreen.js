/* Екран виклику · UI-модуль за контрактом з розділу 2.3 плану:
   mount(root, props) -> { update(props), destroy() }
   Компонент не читає WS і не викликає api: дані приходять у props, дії йдуть через on*.
   update() чіпає лише вузли, залежні від змінених полів, тож фокус і курсор
   у полях картки не губляться під час розмови. */

export const MSG = {
  title: 'Прийом повідомлення',
  line: 'Лінія 101',
  status: {
    connecting: 'Підключаємося до лінії…',
    incoming: 'Вхідний виклик',
    live: 'На зв’язку',
    reconnecting: 'Зв’язок перервано. Відновлюємо…',
    ending: 'Готуємо розбір…',
    reportDelayed: 'Розбір ще готується',
    unavailable: 'Виклик недоступний',
  },
  save: {
    idle: 'Змін ще немає',
    saving: 'Зберігаємо…',
    saved: 'Збережено',
    offline: 'Немає зв’язку. Збережемо, коли він з’явиться',
  },
  incoming: {
    h: 'Вхідний виклик',
    p: 'Заявник на лінії. Перевірте мікрофон і прийміть виклик.',
    accept: 'Прийняти',
    micOk: 'Мікрофон готовий',
    micText: 'Текстовий режим',
  },
  recon: 'Зв’язок перервано. Картку можна редагувати, зміни збережемо після відновлення.',
  delayed: 'Розбір готується довше звичайного. Він з’явиться в розділі «Прогрес».',
  unavailable: 'Виклик більше недоступний.',
  micDenied: 'Немає доступу до мікрофона. Дозвольте його в браузері або працюйте текстом.',
  endHint: 'Утримуйте півсекунди або двічі натисніть Enter.',
  card: {
    title: 'Картка виклику',
    where: 'Місце події',
    what: 'Подія',
    victims: 'Загрози',
    building: 'Будівля і під’їзд',
    who: 'Заявник',
    notes: 'Інші відомості',
    actions: 'Дії після прийому',
    city: 'Населений пункт',
    street: 'Вулиця',
    house: 'Будинок',
    flat: 'Квартира',
    landmark: 'Об’єкт, місце загоряння, орієнтир',
    count: 'Людей у небезпеці / постраждалих',
    explosion: 'Загроза вибуху',
    floors: 'Поверхів у будівлі',
    access: 'Особливості під’їзду',
    name: 'Прізвище заявника',
    phone: 'Телефон',
    notesLbl: 'Додаткові відомості',
  },
  actions: { alarm: 'Подати сигнал «Тривога»', report: 'Доповісти про виїзд' },
  talk: {
    caller: 'Заявник',
    last: 'Остання репліка',
    log: 'Розмова',
    reply: 'Ваша відповідь',
    send: 'Надіслати',
    voiceHint: 'Мікрофон вмикається клавішею F2.',
  },
  who: { caller: 'Заявник', op: 'Ви', scene: 'Звук' },
};

export const INCIDENT_TYPES = ['Пожежа', 'ДТП', 'Газ, загазованість', 'Рятування людей', 'Обстріл, руйнування', 'Інша подія'];
export const EXPLOSION = ['Невідомо', 'Немає', 'Є'];
export const ACTION_IDS = ['alarm', 'report'];

const ICONS = {
  mic: '<path d="M12 14a3 3 0 0 0 3-3V6a3 3 0 1 0-6 0v5a3 3 0 0 0 3 3Zm5-3a5 5 0 0 1-10 0M12 16v4m-3 0h6"/>',
  phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2Z"/>',
  send: '<path d="m4 12 16-8-6 16-3-7-7-1Z"/>',
  warn: '<path d="M12 4 2.5 20h19L12 4Zm0 6v5m0 3h.01"/>',
  help: '<path d="M9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1 .9-1 1.7M12 17h.01"/><circle cx="12" cy="12" r="9"/>',
  check: '<path d="m5 12 5 5 9-10"/>',
};
function icon(name, size = 18) {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('width', size); s.setAttribute('height', size);
  s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor');
  s.setAttribute('stroke-width', '2'); s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round');
  s.setAttribute('aria-hidden', 'true'); s.innerHTML = ICONS[name];
  return s;
}

function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2).toLowerCase(), v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat()) {
    if (kid == null || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(kid));
  }
  return el;
}

export function formatTime(sec) {
  sec = Math.max(0, Math.floor(sec || 0));
  const m = String(Math.floor((sec % 3600) / 60)).padStart(2, '0');
  const s = String(sec % 60).padStart(2, '0');
  return sec >= 3600 ? `${Math.floor(sec / 3600)}:${m}:${s}` : `${m}:${s}`;
}

const DEFAULTS = {
  phase: 'connecting',          // connecting | incoming | live | ending | reportDelayed | unavailable
  connection: 'online',         // online | reconnecting
  mode: 'voice',                // voice | text
  micMode: 'toggle',            // toggle | hold
  micOn: false, micLevel: 0, micError: false,
  elapsed: 0,
  card: {}, dirty: {}, saveStatus: 'idle',
  actions: {},                  // { alarm: мс, report: мс } після натискання
  utterance: null,              // { uid, text }
  caption: '',                  // підпис звукової події сцени
  emotion: null,                // { level: low|mid|high, label } лише в навчальному режимі
  partial: '',
  transcript: [],               // [{ uid, who: caller|op|scene, text }]
  trainingHint: null,
  canOpenReport: false,
  shortcut: 'F2',
  incidentTypes: INCIDENT_TYPES,
};

const METER_WEIGHTS = [0.45, 0.75, 1, 0.85, 0.6, 0.4];
const HOLD_MS = 700;

export function mount(root, initial = {}) {
  let props = { ...DEFAULTS, ...initial };
  let prev = {};
  const rendered = new Set();
  let skTimer = 0, holdTimer = 0, lastEnter = 0, opener = null;
  const ref = {};

  /* ---------- розмітка ---------- */
  const fieldInput = (key, label, attrs = {}, cls = '') => {
    const id = `f-${key}`;
    const tag = attrs.tag || 'input';
    const el = h(tag, { id, 'data-field': key, autocomplete: 'off', lang: 'uk', ...attrs.attrs });
    if (attrs.type) el.type = attrs.type;
    el.addEventListener('input', () => props.onEditCard?.(key, el.value));
    ref.fields[key] = el;
    return h('div', { class: `field ${cls}` }, h('label', { for: id }, label), el, attrs.hint ? h('span', { class: 'hint' }, attrs.hint) : null);
  };

  function buildCard() {
    ref.fields = {};
    const M = MSG.card;
    ref.chips = h('div', { class: 'choices', role: 'radiogroup', 'aria-labelledby': 'lbl-what' });
    const expl = h('select', { id: 'f-explosion', 'data-field': 'explosion' },
      EXPLOSION.map(v => h('option', { value: v }, v)));
    expl.addEventListener('change', () => props.onEditCard?.('explosion', expl.value));
    ref.fields.explosion = expl;
    ref.actionBtns = {};
    const actionButtons = ACTION_IDS.map(id => {
      const b = h('button', { type: 'button', class: 'btn', 'data-action': id }, MSG.actions[id]);
      b.addEventListener('click', () => props.onAction?.(id));
      ref.actionBtns[id] = b;
      return b;
    });

    ref.cardBody = h('div', { class: 'card-grid' },
      h('div', { class: 'fgroup eyebrow' }, M.where),
      fieldInput('city', M.city, { attrs: { placeholder: 'Наприклад, Львів' } }, 'f-wide'),
      h('div', { class: 'addr-row' },
        fieldInput('street', M.street, { attrs: { placeholder: 'Вулиця або проспект' } }, 'f-street'),
        fieldInput('house', M.house, { attrs: { inputmode: 'text' } }),
        fieldInput('flat', M.flat, { attrs: { inputmode: 'numeric' } })),
      fieldInput('landmark', M.landmark, { attrs: { placeholder: 'Біля чого, який під’їзд' } }, 'f-wide'),
      h('div', { class: 'fgroup eyebrow', id: 'lbl-what' }, M.what),
      h('div', { class: 'field f-wide' }, ref.chips),
      h('div', { class: 'fgroup eyebrow' }, M.victims),
      fieldInput('victims', M.count, { type: 'number', attrs: { min: '0', inputmode: 'numeric' } }),
      h('div', { class: 'field' }, h('label', { for: 'f-explosion' }, M.explosion), expl),
      h('div', { class: 'fgroup eyebrow' }, M.building),
      fieldInput('floors', M.floors, { type: 'number', attrs: { min: '0', inputmode: 'numeric' } }),
      fieldInput('access', M.access, { attrs: { placeholder: 'Шлагбаум, ворота, двір…' } }),
      h('div', { class: 'fgroup eyebrow' }, M.who),
      fieldInput('caller_name', M.name, { attrs: { placeholder: 'Прізвище' } }),
      fieldInput('phone', M.phone, { type: 'tel', attrs: { inputmode: 'tel', placeholder: '+380…' } }),
      h('div', { class: 'fgroup eyebrow' }, M.notes),
      fieldInput('notes', M.notesLbl, { tag: 'textarea', attrs: { rows: 4 } }, 'f-wide'),
      h('div', { class: 'fgroup eyebrow' }, M.actions),
      h('div', { class: 'field f-wide', style: 'display:flex;gap:var(--s-3);flex-wrap:wrap' }, ...actionButtons));
  }

  function buildChips() {
    ref.chips.replaceChildren();
    props.incidentTypes.forEach((t, i) => {
      const b = h('button', { type: 'button', class: 'choice', role: 'radio', 'aria-checked': 'false', tabindex: i === 0 ? '0' : '-1', 'data-value': t }, t);
      b.addEventListener('click', () => props.onEditCard?.('incident_type', t));
      b.addEventListener('keydown', e => {
        const all = [...ref.chips.children]; const idx = all.indexOf(b);
        let n = -1;
        if (e.key === 'ArrowRight' || e.key === 'ArrowDown') n = (idx + 1) % all.length;
        if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') n = (idx - 1 + all.length) % all.length;
        if (n >= 0) { e.preventDefault(); all[n].focus(); props.onEditCard?.('incident_type', all[n].dataset.value); }
      });
      ref.chips.append(b);
    });
  }

  function skeletonBlock(rows) {
    return h('div', { class: 'skeleton', 'aria-hidden': 'true' }, ...rows.map(c => h('div', { class: `sk ${c}` })));
  }

  function build() {
    buildCard();
    ref.h1 = h('h1', { class: 'sr-only', tabindex: '-1' }, MSG.title);
    ref.statusText = h('span', { role: 'status' });
    ref.timer = h('time', { class: 'timer' }, '00:00');

    ref.micMeter = h('span', { class: 'meter', 'aria-hidden': 'true' }, METER_WEIGHTS.map(() => h('i')));
    ref.micLabel = h('span', { class: 'mic-label' }, 'Мікрофон');
    ref.mic = h('button', { type: 'button', class: 'mic', 'aria-pressed': 'false', 'aria-keyshortcuts': props.shortcut },
      h('span', { class: 'mic-ico' }, icon('mic')), ref.micLabel, ref.micMeter, h('span', { class: 'kbd' }, props.shortcut));
    ref.textPill = h('span', { class: 'line-pill' }, MSG.incoming.micText);

    ref.endHint = h('span', { id: 'end-hint', class: 'sr-only' }, MSG.endHint);
    ref.end = h('button', { type: 'button', class: 'btn end', 'aria-describedby': 'end-hint' }, 'Завершити', h('small', { class: 'kbd' }, 'утримуйте'), ref.endHint);

    ref.bar = h('header', { class: 'statusbar' },
      h('span', { class: 'line-pill' }, h('i', { class: 'dot' }), ref.statusText),
      ref.timer,
      h('div', { class: 'bar-actions' }, ref.textPill, ref.mic, ref.end));

    ref.bReconn = h('div', { class: 'banner banner-warn', role: 'alert', hidden: '' }, icon('warn'), MSG.recon);
    ref.bMic = h('div', { class: 'banner banner-warn', role: 'alert', hidden: '' }, icon('warn'), MSG.micDenied);
    ref.bDelay = h('div', { class: 'banner banner-info', role: 'status', hidden: '' }, MSG.delayed,
      h('button', { class: 'btn ghost', type: 'button', onclick: () => props.onHome?.() }, 'На головну'));
    ref.bOpen = h('button', { class: 'btn ghost', type: 'button', onclick: () => props.onOpenReport?.() }, 'Відкрити розбір');
    ref.bUnavail = h('div', { class: 'banner banner-warn', role: 'status', hidden: '' }, MSG.unavailable, ref.bOpen,
      h('button', { class: 'btn ghost', type: 'button', onclick: () => props.onHome?.() }, 'На головну'));

    ref.barWrap = h('div', { class: 'bar-wrap' }, ref.bar, ref.bReconn, ref.bMic, ref.bDelay, ref.bUnavail);

    // вхідний виклик
    ref.accept = h('button', { type: 'button', class: 'btn primary', onclick: () => props.onAccept?.() }, 'Прийняти', h('span', { class: 'kbd' }, 'Enter'));
    ref.micState = h('span', { class: 'mic-state' }, icon('mic', 16), MSG.incoming.micOk);
    ref.incoming = h('section', { class: 'panel incoming', 'aria-labelledby': 'inc-h', hidden: '' },
      h('div', null,
        h('div', { class: 'ring' }, icon('phone', 48)),
        h('h2', { id: 'inc-h' }, MSG.incoming.h), h('p', null, MSG.incoming.p),
        h('div', null, ref.micState), ref.accept));

    // картка
    ref.saveStatus = h('span', { class: 'save-status', role: 'status', 'data-state': 'idle' }, MSG.save.idle);
    ref.cardSk = skeletonBlock(['line w40', '', 'line w60', '', '', 'tall', '', '']);
    ref.panelCard = h('section', { class: 'panel panel-card', 'aria-labelledby': 'card-h' },
      h('div', { class: 'panel-head' }, h('h2', { class: 'panel-title', id: 'card-h' }, MSG.card.title), ref.saveStatus),
      ref.cardBody, ref.cardSk);

    // розмова
    ref.emotion = h('span', { class: 'emotion', hidden: '' });
    ref.utterance = h('p', { class: 'utterance', 'aria-live': 'polite', 'aria-atomic': 'true' });
    ref.caption = h('p', { class: 'caption', hidden: '' });
    ref.partial = h('p', { class: 'partial', 'aria-live': 'off' });
    ref.hint = h('div', { class: 'banner banner-info hint-box', hidden: '' });
    ref.voiceHint = h('p', { class: 'hint' }, MSG.talk.voiceHint);
    ref.replyInput = h('input', { id: 'reply', type: 'text', lang: 'uk', autocomplete: 'off', placeholder: 'Напишіть, що скажете заявнику', 'aria-label': MSG.talk.reply });
    ref.sendBtn = h('button', { type: 'submit', class: 'btn primary' }, icon('send'), MSG.talk.send);
    ref.composer = h('form', { class: 'composer', hidden: '', onsubmit: e => { e.preventDefault(); const v = ref.replyInput.value.trim(); if (v) { props.onSend?.(v); ref.replyInput.value = ''; } } },
      ref.replyInput, ref.sendBtn);
    ref.talkSk = skeletonBlock(['line w40', 'tall', 'line', 'line w60']);
    ref.talkBody = h('div', { class: 'panel-talk-body', style: 'display:grid;gap:var(--s-4)' },
      h('div', { class: 'caller-head' }, h('span', { class: 'avatar', 'aria-hidden': 'true' }, 'З'), h('span', null, h('span', { class: 'eyebrow', style: 'display:block' }, MSG.talk.last), h('strong', null, MSG.talk.caller)), ref.emotion),
      ref.utterance, ref.caption, ref.partial, ref.hint, ref.composer, ref.voiceHint);
    ref.panelTalk = h('section', { class: 'panel panel-talk', 'aria-label': MSG.talk.caller }, ref.talkBody, ref.talkSk);

    // журнал
    ref.log = h('div', { class: 'convo', role: 'log', 'aria-live': 'off', 'aria-label': MSG.talk.log, tabindex: '0' });
    ref.helpBtn = h('button', { type: 'button', class: 'btn ghost', 'aria-label': 'Гарячі клавіші', onclick: e => openHelp(e.currentTarget) }, icon('help'));
    ref.panelLog = h('section', { class: 'panel panel-log', 'aria-labelledby': 'log-h' },
      h('div', { class: 'panel-head' }, h('h2', { class: 'panel-title', id: 'log-h' }, MSG.talk.log), ref.helpBtn), ref.log);

    // діалог гарячих клавіш
    ref.dlg = h('dialog', { class: 'dlg', 'aria-labelledby': 'dlg-h' },
      h('h2', { id: 'dlg-h' }, 'Гарячі клавіші'),
      h('dl', { class: 'sc-list' },
        h('dt', null, h('span', { class: 'kbd' }, props.shortcut)), h('dd', null, 'Мікрофон, з будь-якого місця'),
        h('dt', null, h('span', { class: 'kbd' }, 'Ctrl+/')), h('dd', null, 'Перейти до поля відповіді'),
        h('dt', null, h('span', { class: 'kbd' }, 'Enter')), h('dd', null, 'Прийняти вхідний виклик'),
        h('dt', null, h('span', { class: 'kbd' }, 'Enter ×2')), h('dd', null, 'Завершити виклик без утримання'),
        h('dt', null, h('span', { class: 'kbd' }, '?')), h('dd', null, 'Ця підказка'),
        h('dt', null, h('span', { class: 'kbd' }, 'Esc')), h('dd', null, 'Закрити')),
      h('div', { class: 'dlg-actions' }, h('button', { class: 'btn primary', type: 'button', autofocus: '', onclick: () => ref.dlg.close() }, 'Зрозуміло')));
    ref.dlg.addEventListener('close', () => { opener?.focus?.(); opener = null; });

    ref.l = h('div', { class: 'l-call', 'data-phase': '' }, ref.barWrap, ref.incoming, ref.panelTalk, ref.panelCard, ref.panelLog);
    root.replaceChildren(ref.h1, ref.l, ref.dlg);
    buildChips();
  }

  function openHelp(btn) { opener = btn; ref.dlg.showModal(); }

  /* ---------- утримання «Завершити» ---------- */
  function holdStart() {
    if (ref.end.disabled || holdTimer) return;
    ref.end.dataset.holding = 'true';
    holdTimer = setTimeout(() => { holdStop(); props.onEnd?.(); }, HOLD_MS);
  }
  function holdStop() { clearTimeout(holdTimer); holdTimer = 0; delete ref.end.dataset.holding; }

  /* ---------- глобальні клавіші ---------- */
  const typing = t => t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT');
  function onKeyDown(e) {
    if (e.key === props.shortcut && props.phase === 'live' && props.connection === 'online' && props.mode === 'voice') {
      e.preventDefault();
      if (e.repeat) return;
      props.micMode === 'hold' ? props.onMicHold?.(true) : props.onToggleMic?.();
      return;
    }
    if ((e.ctrlKey || e.metaKey) && e.key === '/' && props.phase === 'live') { e.preventDefault(); ref.replyInput.focus(); return; }
    if (e.key === '?' && !typing(e.target) && !ref.dlg.open) { e.preventDefault(); openHelp(document.activeElement); return; }
    if (e.key === 'Enter' && !e.repeat) {
      if (props.phase === 'incoming' && e.target.tagName !== 'BUTTON' && !ref.dlg.open) { e.preventDefault(); props.onAccept?.(); return; }
      if (props.phase === 'live' && props.connection === 'online' && !typing(e.target) && e.target.tagName !== 'BUTTON') {
        const now = performance.now();
        if (now - lastEnter < 1000) { lastEnter = 0; props.onEnd?.(); } else lastEnter = now;
      }
    }
  }
  function onKeyUp(e) { if (e.key === props.shortcut && props.micMode === 'hold') props.onMicHold?.(false); }

  /* ---------- оновлення ---------- */
  function setHidden(el, v) { if (v) el.setAttribute('hidden', ''); else el.removeAttribute('hidden'); }
  function same(a, b) { return a === b; }

  function render() {
    const p = props, o = prev;
    const phase = p.phase, recon = p.connection === 'reconnecting' && phase === 'live';
    const liveOk = phase === 'live' && !recon;

    if (!same(phase, o.phase) || !same(p.connection, o.connection)) {
      ref.l.dataset.phase = phase; ref.bar.dataset.phase = phase; ref.bar.dataset.conn = p.connection;
      ref.statusText.textContent = recon ? MSG.status.reconnecting : MSG.status[phase] || '';
      const inc = phase === 'incoming', conn = phase === 'connecting';
      setHidden(ref.incoming, !inc);
      setHidden(ref.panelCard, inc); setHidden(ref.panelTalk, inc); setHidden(ref.panelLog, inc);
      setHidden(ref.cardBody, conn); setHidden(ref.talkBody, conn);
      setHidden(ref.cardSk, !conn); setHidden(ref.talkSk, !conn);
      clearTimeout(skTimer);
      [ref.cardSk, ref.talkSk].forEach(s => delete s.dataset.show);
      if (conn) skTimer = setTimeout(() => [ref.cardSk, ref.talkSk].forEach(s => s.dataset.show = 'true'), 150); // без блимання на швидких відповідях
      setHidden(ref.voiceHint, p.mode === 'text' || phase !== 'live');
      setHidden(ref.timer, !(phase === 'live' || phase === 'ending' || phase === 'reportDelayed'));
      setHidden(ref.mic, !(phase === 'live' && p.mode === 'voice'));
      setHidden(ref.textPill, !(phase === 'live' && p.mode === 'text'));
      setHidden(ref.end, !(phase === 'live'));
      setHidden(ref.bReconn, !recon);
      setHidden(ref.bDelay, phase !== 'reportDelayed');
      setHidden(ref.bUnavail, phase !== 'unavailable');
      ref.timer.dataset.paused = String(p.connection === 'reconnecting');
      ref.end.disabled = !liveOk;
      ref.replyInput.disabled = ref.sendBtn.disabled = !liveOk;
      ref.mic.disabled = !liveOk;
      if (phase === 'incoming') ref.accept.focus({ preventScroll: true });
    }
    if (!same(p.mode, o.mode)) {
      setHidden(ref.composer, phase === 'incoming');
      setHidden(ref.voiceHint, p.mode === 'text' || phase !== 'live');
      setHidden(ref.mic, !(phase === 'live' && p.mode === 'voice'));
      setHidden(ref.textPill, !(phase === 'live' && p.mode === 'text'));
      ref.micState.lastChild.textContent = p.mode === 'text' ? MSG.incoming.micText : MSG.incoming.micOk;
    }
    if (!same(phase, o.phase) && phase !== 'incoming') setHidden(ref.composer, false);
    if (!same(p.micError, o.micError)) setHidden(ref.bMic, !p.micError);
    if (!same(p.canOpenReport, o.canOpenReport)) setHidden(ref.bOpen, !p.canOpenReport);
    if (!same(p.elapsed, o.elapsed)) { ref.timer.textContent = formatTime(p.elapsed); ref.timer.setAttribute('datetime', `PT${Math.floor(p.elapsed || 0)}S`); }

    if (!same(p.micOn, o.micOn)) {
      ref.mic.setAttribute('aria-pressed', String(p.micOn));
      ref.micLabel.textContent = p.micOn ? 'Говоріть' : 'Мікрофон вимкнено';
    }
    if (!same(p.micLevel, o.micLevel) || !same(p.micOn, o.micOn)) {
      ref.micMeter.dataset.off = String(!p.micOn);
      [...ref.micMeter.children].forEach((b, i) => b.style.setProperty('--lv', (p.micOn ? Math.min(1, p.micLevel * METER_WEIGHTS[i]) : 0).toFixed(2)));
    }

    // картка: поле в фокусі ніколи не переписується ззовні
    const oc = o.card || {};
    for (const [key, el] of Object.entries(ref.fields)) {
      const v = p.card[key] ?? '';
      if (oc[key] !== p.card[key] && document.activeElement !== el && el.value !== String(v)) el.value = v;
      const d = !!p.dirty[key];
      if (d !== !!(o.dirty || {})[key]) { d ? el.setAttribute('data-dirty', 'true') : el.removeAttribute('data-dirty'); }
    }
    if (oc.incident_type !== p.card.incident_type || !same(p.incidentTypes, o.incidentTypes)) {
      if (!same(p.incidentTypes, o.incidentTypes) && o.incidentTypes) buildChips();
      [...ref.chips.children].forEach(c => {
        const on = c.dataset.value === p.card.incident_type;
        c.setAttribute('aria-checked', String(on));
        c.tabIndex = on || (!p.card.incident_type && c === ref.chips.firstChild) ? 0 : -1;
      });
    }
    if (!same(p.saveStatus, o.saveStatus)) { ref.saveStatus.dataset.state = p.saveStatus; ref.saveStatus.textContent = MSG.save[p.saveStatus] || ''; }

    // кнопки дій: після натискання неактивні, з часом виконання
    for (const id of ACTION_IDS) {
      const t = (p.actions || {})[id];
      const b = ref.actionBtns[id];
      b.disabled = !liveOk || t != null;
      const text = t != null ? `✓ ${MSG.actions[id]} · ${formatTime(t / 1000)}` : MSG.actions[id];
      if (b.textContent !== text) b.textContent = text;
    }

    // розмова
    if (p.utterance?.uid !== o.utterance?.uid) {
      ref.utterance.textContent = p.utterance?.text || '';
      ref.utterance.classList.remove('swap'); void ref.utterance.offsetWidth; ref.utterance.classList.add('swap');
    }
    if (!same(p.caption, o.caption)) { ref.caption.textContent = p.caption ? `Чути: ${p.caption}` : ''; setHidden(ref.caption, !p.caption); }
    if (!same(p.partial, o.partial)) ref.partial.textContent = p.partial;
    if (!same(p.emotion, o.emotion)) {
      setHidden(ref.emotion, !p.emotion);
      if (p.emotion) { ref.emotion.dataset.level = p.emotion.level; ref.emotion.textContent = p.emotion.label; }
    }
    if (!same(p.trainingHint, o.trainingHint)) {
      setHidden(ref.hint, !p.trainingHint);
      ref.hint.replaceChildren(icon('help'), h('span', null, h('strong', null, 'Підказка навчального режиму. '), p.trainingHint || ''));
    }

    // журнал: лише нові репліки (ідемпотентно за uid)
    const stick = ref.log.scrollHeight - ref.log.scrollTop - ref.log.clientHeight < 60;
    let added = false;
    for (const m of p.transcript) {
      if (rendered.has(m.uid)) continue;
      rendered.add(m.uid); added = true;
      ref.log.append(h('div', { class: 'turn', 'data-who': m.who }, h('span', { class: 'turn-who' }, MSG.who[m.who] || ''), h('span', { class: 'turn-bubble' }, m.text)));
    }
    if (added && stick) ref.log.scrollTop = ref.log.scrollHeight;

    prev = { ...p, card: { ...p.card }, dirty: { ...p.dirty } };
  }

  /* ---------- старт ---------- */
  build();
  ref.mic.addEventListener('click', () => { if (props.micMode !== 'hold') props.onToggleMic?.(); });
  ref.mic.addEventListener('pointerdown', () => { if (props.micMode === 'hold') props.onMicHold?.(true); });
  ['pointerup', 'pointerleave', 'pointercancel'].forEach(t => ref.mic.addEventListener(t, () => { if (props.micMode === 'hold' && props.micOn) props.onMicHold?.(false); }));
  ref.end.addEventListener('pointerdown', holdStart);
  ['pointerup', 'pointerleave', 'pointercancel', 'blur'].forEach(t => ref.end.addEventListener(t, holdStop));
  ref.end.addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && !e.repeat) {
    e.preventDefault();
    const now = performance.now();
    if (e.key === 'Enter' && now - lastEnter < 1000) { lastEnter = 0; props.onEnd?.(); return; }
    if (e.key === 'Enter') lastEnter = now;
    holdStart();
  } });
  ref.end.addEventListener('keyup', e => { if (e.key === 'Enter' || e.key === ' ') holdStop(); });
  document.addEventListener('keydown', onKeyDown);
  document.addEventListener('keyup', onKeyUp);
  render();

  return {
    update(next) { props = { ...props, ...next }; render(); },
    focusTitle() { ref.h1.focus(); },
    destroy() {
      document.removeEventListener('keydown', onKeyDown);
      document.removeEventListener('keyup', onKeyUp);
      clearTimeout(skTimer); clearTimeout(holdTimer);
      root.replaceChildren();
    },
  };
}
