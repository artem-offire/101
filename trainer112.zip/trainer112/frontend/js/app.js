// Маршрутизатор, верхня панель, вхід за ролями, кабінет курсанта.
import { api, session, h, clear, ic, icon, initials, fmtDate, fmtT, plural, toast, theme, CATEGORY, CATEGORY_META, DIFFICULTY, ROLE_TITLES, dots, tok } from "./core.js";
import { friendly, LEAVE_CALL } from "./messages.js";
import { renderCall } from "./call.js";
import { renderReport } from "./report.js";
import { renderConsole } from "./console.js";
import { renderCabinet } from "./cabinet.js";
import { renderMethodist } from "./methodist.js";
import { sparkline } from "./charts.js";

const app = document.getElementById("app");
const top = document.getElementById("topbar");
let cleanup = null;
theme.apply();
theme.watch(() => { renderTop(session.get()); });
document.getElementById("skip").addEventListener("click", () => app.focus());
let lastHash = location.hash;
const MAIN_CLASS = { console: "wide", cabinet: "wide" };

const NAV = {
  trainee: [["#/home", "Тренування"]],
  instructor: [["#/console", "Живий пульт"], ["#/cabinet", "Кабінет"], ["#/home", "Сценарії"]],
  methodist: [["#/methodist", "Сценарії і протокол"], ["#/cabinet", "Аналітика"], ["#/home", "Спробувати"]],
};
const HOME = { trainee: "#/home", instructor: "#/console", methodist: "#/methodist" };

function renderTop(user) {
  clear(top);
  top.append(h("a.brand", { href: user ? HOME[user.role] : "#/login" }, h("span.brand-badge", "101"), "Тренажер оператора ПЗЧ"));
  if (!user) return;
  const hash = location.hash.split("/").slice(0, 2).join("/");
  top.append(h("nav.nav", NAV[user.role].map(([href, t]) => h("a", { href, class: hash === href ? "active" : null }, t))));
  top.append(h("div.userchip", h("div.text-right", h("div", user.name), h("div.tiny.muted", ROLE_TITLES[user.role])),
    h("div.avatar", initials(user.name)),
    themeButton(),
    h("button.btn.ghost.icon", { title: "Вийти", "aria-label": "Вийти", on: { click: () => { session.clear(); location.hash = "#/login"; } } }, ic("logout"))));
}

function themeButton() {
  const b = h("button.btn.ghost.icon.theme-toggle", { type: "button", on: { click: () => { theme.toggle(); sync(); } } });
  const sync = () => { const dark = theme.isDark(); b.innerHTML = icon[dark ? "sun" : "moon"]; b.title = dark ? "Увімкнути світлу тему" : "Увімкнути темну тему"; b.setAttribute("aria-label", b.title); };
  sync();
  return b;
}

// Захист від випадкового виходу з активного дзвінка
function guard() {
  if (cleanup && cleanup.isActive && cleanup.isActive()) {
    const target = (location.hash || "#/").split("/")[1];
    if (target !== "call" && target !== "report" && !confirm(LEAVE_CALL)) { history.replaceState(null, "", lastHash); return false; }
  }
  return true;
}

async function route() {
  if (!guard()) return;
  lastHash = location.hash;
  if (cleanup) { try { cleanup(); } catch { /* */ } cleanup = null; }
  const user = session.get();
  const [, page, arg] = (location.hash || "#/").split("/");
  if (!user && page !== "login") { location.hash = "#/login"; return; }
  renderTop(user);
  clear(app);
  app.className = MAIN_CLASS[page] || "";
  try {
    switch (page) {
      case "login": renderLogin(); break;
      case "home": await renderHome(user); break;
      case "call": cleanup = await renderCall(app, user, arg); break;
      case "report": await renderReport(app, user, arg); break;
      case "console": cleanup = await renderConsole(app, user, arg); break;
      case "cabinet": cleanup = await renderCabinet(app, user, arg); break;
      case "methodist": await renderMethodist(app, user, arg); break;
      default: location.hash = user ? HOME[user.role] : "#/login";
    }
  } catch (e) {
    console.error(e);
    app.append(h("div.panel.l-page", h("h2", "Не вдалося відкрити сторінку"), h("p.muted", friendly(e)), h("div.row", h("button.btn.primary", { on: { click: route } }, "Спробувати ще раз"), h("a.btn", { href: user ? HOME[user.role] : "#/login" }, "На головну"))));
  }
}
window.addEventListener("hashchange", route);
// Помилки дій (вхід, збереження, команди) не мають зникати мовчки
window.addEventListener("unhandledrejection", (e) => {
  const msg = String((e.reason && e.reason.message) || e.reason || "");
  toast(friendly(e.reason), 5000);
});
route();

// ── Вхід ───────────────────────────────────────────────
function renderLogin() {
  let role = "trainee";
  const roles = [
    ["trainee", "headset", "Курсант", "Приймає повідомлення на пункті зв'язку частини, отримує розбір"],
    ["instructor", "ear", "Інструктор", "Слухає наживо, керує Режисером, призначає сесії"],
    ["methodist", "book", "Методист", "Сценарії, протокол, ваги і пороги, калібрування"],
  ];
  const tiles = roles.map(([id, icn, t, d]) => {
    const b = h("button.role", { type: "button", role: "radio", "aria-checked": String(id === role), on: { click: () => { role = id; tiles.forEach((x) => { const on = x === b; x.classList.toggle("sel", on); x.setAttribute("aria-checked", String(on)); }); } } },
      ic(icn), h("span.role-text", h("b", t), h("span", d)));
    if (id === role) b.classList.add("sel");
    return b;
  });
  const name = h("input", { placeholder: "Наприклад, Коваленко Олена", autocomplete: "name", class: "input-lg" });
  const submit = async (e) => {
    e.preventDefault();
    if (!name.value.trim()) { name.focus(); return; }
    const u = await api.post("/api/login", { name: name.value.trim(), role });
    session.set(u);
    location.hash = HOME[u.role];
  };
  app.append(h("div.login", h("div.login-card",
    h("h1", "Тренажер оператора ПЗЧ"),
    h("p.muted", "Прийом повідомлень про пожежу та інші події. Навчальна пожежно-рятувальна частина ЛДУБЖД."),
    h("form.col", { on: { submit } },
      h("div.roles", { role: "radiogroup", "aria-label": "Роль" }, tiles),
      h("label.field", "Прізвище та ім'я", name),
      h("button.btn.primary.big.w-full", { type: "submit" }, "Увійти"),
      h("p.tiny.muted.mb-0", "Демо-вхід без пароля. Усі сценарії та голоси синтетичні.")))));
  name.focus();
}

// ── Кабінет курсанта: призначення, бібліотека, історія ──
async function renderHome(user) {
  const [scs, mine, assigns] = await Promise.all([
    api.get("/api/scenarios"), api.get(`/api/sessions?trainee=${encodeURIComponent(user.name)}`),
    api.get(`/api/assignments?trainee=${encodeURIComponent(user.name)}`)]);
  const byId = Object.fromEntries(scs.map((s) => [s.id, s]));
  const open = assigns.filter((a) => a.status !== "done");

  app.append(h("div.section",
    h("div.row.between", h("div", h("h1", user.role === "trainee" ? `Вітаю, ${user.name.split(" ")[0]}` : "Сценарії"),
      h("p.muted.m-0", "Почніть тренування або оберіть ситуацію в бібліотеці нижче.")),
    progressCard(mine))));

  app.append(h("section.section.panel",
    h("h2", "Почати тренування"),
    h("p.muted", "Система сама обере ситуацію. Яку саме, ви дізнаєтеся після завершення дзвінка."),
    h("div.row",
      h("button.btn.primary.big", { type: "button", on: { click: (e) => startRandom(user, e.currentTarget) } }, ic("phone"), "Почати тренування"),
      h("button.btn.big", { type: "button", on: { click: () => { const el = document.getElementById("library"); if (el) el.scrollIntoView({ behavior: "smooth" }); } } }, "Обрати ситуацію"))));

  if (open.length) {
    app.append(h("div.section", h("div.section-title", h("h2", "Призначено вам"), h("span.chip.red", open.length)),
      h("div.grid.cards.library", open.map((a) => scenarioCard(byId[a.scenario_id] || { id: a.scenario_id, title: a.scenario_id, category: "", brief: a.note || "", steps: 0, difficulty: a.difficulty }, a)))));
  }

  const valid = scs.filter((s) => s.valid);
  const cats = ["все", ...new Set(valid.map((s) => s.category))];
  let active = "все";
  const grid = h("div.grid.cards.library");

  function scenarioCard(s, assignment = null) {
    const meta = CATEGORY_META[s.category] || { icon: "alert", tint: "#f1f1f1", label: s.category };
    const start = h("button.btn.small.stretch-link", {
      type: "button", "aria-label": `Почати: ${s.title}`,
      on: { click: (e) => startCall(user, s, assignment, e.currentTarget) },
    }, ic("phone"), "Почати");
    return h("article.card.stretch", { title: (s.skills || []).join(" · ") },
      h("div.cover", { style: { background: meta.tint }, "aria-hidden": "true" },
        h("span.cover-ico", { html: icon[meta.icon] }),
        assignment ? h("span.badge", assignment.due ? `Призначено · до ${assignment.due}` : "Призначено") : null),
      h("div.row.between.nowrap", h("h3.title.m-0", s.title), h("span.small.nowrap", DIFFICULTY[s.difficulty] || "")),
      h("p.small.muted.m-0.clamp-2.grow", s.brief),
      h("div.row.between", h("span.small.muted", `${meta.label} · ${plural(s.steps, ["крок", "кроки", "кроків"])}`), start));
  }

  function renderGrid() {
    grid.replaceChildren(...valid.filter((s) => active === "все" || s.category === active).map((s) => scenarioCard(s)));
  }

  const catBar = h("div.catbar", { role: "tablist", "aria-label": "Категорії" }, cats.map((c) => {
    const meta = c === "все" ? { icon: "grid", label: "Усі" } : (CATEGORY_META[c] || { icon: "alert", label: c });
    const b = h("button.cat", { type: "button", role: "tab", "aria-selected": String(c === active),
      on: { click: () => {
        active = c;
        catBar.querySelectorAll(".cat").forEach((x) => x.setAttribute("aria-selected", String(x === b)));
        renderGrid();
      } } }, h("span", { html: icon[meta.icon] }), meta.label);
    return b;
  }));

  app.append(h("div.section", { id: "library" },
    h("div.section-title", h("h2", "Бібліотека ситуацій"), h("span.muted.small", plural(valid.length, ["ситуація", "ситуації", "ситуацій"]))),
    catBar, grid));
  renderGrid();

  if (mine.length) {
    app.append(h("div.section", h("h2", "Історія тренувань"), h("div.panel.table-wrap", h("table",
      h("thead", h("tr", ["Дата", "Сценарій", "Бал", "Результат", "До адреси", ""].map((t) => h("th", t)))),
      h("tbody", mine.map((s) => h("tr",
        h("td.mono.small", fmtDate(s.created)),
        h("td", s.scenario_id === "random" ? "Випадкова ситуація" : (byId[s.scenario_id] || {}).title || s.scenario_id, s.parent_id ? h("span.chip.violet", "переграш") : null),
        h("td.mono", s.score != null ? Math.round(s.score) : "—"),
        h("td", s.status !== "done" ? h("span.chip.amber", "не завершено") : s.passed ? h("span.chip.green", "зараховано") : h("span.chip.red", "не зараховано")),
        h("td.mono.small", s.summary && s.summary.time_to && s.summary.time_to.address_asked != null ? `${s.summary.time_to.address_asked} с` : "—"),
        h("td", s.status === "done" ? h("a.btn.link", { href: `#/report/${s.id}` }, "Звіт →") : null))))))));
  }
}

function progressCard(mine) {
  const done = mine.filter((s) => s.status === "done").reverse();
  if (!done.length) return h("div");
  const addr = done.map((s) => s.summary && s.summary.time_to ? s.summary.time_to.address_asked : null).filter((v) => v != null);
  const avg = Math.round(done.reduce((a, s) => a + (s.score || 0), 0) / done.length);
  return h("div.row",
    h("div.stat", h("div.k", "Сесій"), h("div.v", done.length)),
    h("div.stat", h("div.k", "Середній бал"), h("div.v", avg)),
    h("div.stat", h("div.k", "Час до адреси"), h("div.row.tight", h("div.v", addr.length ? `${addr[addr.length - 1]}с` : "—"), sparkline(addr, { color: tok("--green") }))));
}

// Старт без проміжного діалогу: параметри беремо зі сценарію чи призначення, індикатори і адаптивний режисер увімкнені.
let starting = false;
export async function startCall(user, s, assignment = null, btn = null) {
  if (starting) return;
  starting = true; if (btn) btn.disabled = true;
  try {
    const r = await api.post("/api/calls", { trainee: user.name, scenario_id: s.id, level: assignment ? assignment.difficulty : s.difficulty,
      assignment_id: assignment ? assignment.id : null, options: { show_indicators: false, adaptive: true } });
    location.hash = `#/call/${r.call_id}`;
  } catch (e) { toast(friendly(e), 5000); if (btn) btn.disabled = false; } finally { starting = false; }
}
export async function startRandom(user, btn = null) {
  if (starting) return;
  starting = true; if (btn) btn.disabled = true;
  try {
    const r = await api.post("/api/calls", { trainee: user.name, scenario_id: "random", options: { show_indicators: false, adaptive: true } });
    location.hash = `#/call/${r.call_id}`;
  } catch (e) { toast(friendly(e), 5000); if (btn) btn.disabled = false; } finally { starting = false; }
}
export { toast, fmtT };
