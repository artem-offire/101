// Єдине місце для текстів, що не належать конкретному екрану: повідомлення про помилки та підказки.
// Правило для помилок: що сталося, що робити далі. Без кодів і технічних подробиць.

export const ERR = {
  network: "Немає зв’язку із сервером. Перевірте інтернет і повторіть.",
  server: "Сервер не відповів. Спробуйте ще раз за хвилину.",
  notFound: "Такого запису вже немає. Поверніться до списку й оберіть інший.",
  forbidden: "Для цієї дії бракує прав. Увійдіть під іншою роллю.",
  invalid: "Перевірте введені дані й спробуйте ще раз.",
  unknown: "Не вдалося виконати дію. Повторіть її ще раз.",
};

export function friendly(err) {
  const status = err && err.status;
  if (status === 404) return ERR.notFound;
  if (status === 403 || status === 401) return ERR.forbidden;
  if (status === 400 || status === 422) return ERR.invalid;
  if (status >= 500) return ERR.server;
  if (err && /Failed to fetch|NetworkError|Load failed/i.test(String(err.message))) return ERR.network;
  return ERR.unknown;
}

export const LEAVE_CALL = "Виклик триває. Якщо піти зараз, дзвінок обірветься. Піти?";
export const LEAVE_PAGE = "Виклик ще триває. Закрити сторінку?";
