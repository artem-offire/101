// Спільні утиліти інтерфейсу: API, сесія користувача, DOM-хелпери, іконки.

export class ApiError extends Error {
  constructor(status, body) { super(`${status} ${body}`); this.status = status; this.body = body; }
}
async function request(url, opts) {
  const r = await fetch(url, opts);
  if (!r.ok) throw new ApiError(r.status, await r.text());
  return r.json();
}
export const api = {
  get: (url) => request(url),
  post: (url, body) => request(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) }),
};

export function wsUrl(path) {
  return `${location.protocol === "https:" ? "wss" : "ws"}://${location.host}${path}`;
}

const KEY = "t112.user";
export const session = {
  get() { try { return JSON.parse(localStorage.getItem(KEY)); } catch { return null; } },
  set(u) { try { localStorage.setItem(KEY, JSON.stringify(u)); } catch { /* приватний режим */ } },
  clear() { try { localStorage.removeItem(KEY); } catch { /* */ } },
};

// h("div.cls#id", {attrs, on:{click}}, ...children)
export function h(sel, attrs, ...children) {
  const m = sel.match(/^([a-z0-9]+)?((?:[.#][\w-]+)*)$/i);
  const el = document.createElement(m && m[1] ? m[1] : "div");
  if (m && m[2]) {
    for (const part of m[2].match(/[.#][\w-]+/g)) {
      if (part[0] === ".") el.classList.add(part.slice(1)); else el.id = part.slice(1);
    }
  }
  if (attrs !== null && attrs !== undefined && attrs !== false && (typeof attrs !== "object" || attrs instanceof Node || Array.isArray(attrs))) {
    children.unshift(attrs); attrs = null;
  }
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === "on") for (const [ev, fn] of Object.entries(v)) el.addEventListener(ev, fn);
    else if (k === "html") el.innerHTML = v;
    else if (k === "class") el.classList.add(...String(v).split(/\s+/).filter(Boolean));
    else if (k === "style" && typeof v === "object") Object.assign(el.style, v);
    else if (k in el && typeof v !== "string") el[k] = v;
    else el.setAttribute(k, v === true ? "" : v);
  }
  append(el, children);
  return el;
}
function append(el, children) {
  for (const c of children.flat(Infinity)) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
}
export const clear = (el) => { while (el.firstChild) el.removeChild(el.firstChild); return el; };

// Українська множина: 1 сценарій, 2 сценарії, 5 сценаріїв
export function plural(n, [one, few, many]) {
  const a = Math.abs(n) % 100, b = a % 10;
  return `${n} ${a > 10 && a < 20 ? many : b === 1 ? one : b >= 2 && b <= 4 ? few : many}`;
}

export function fmtT(ms) {
  if (ms === null || ms === undefined) return "—";
  const s = Math.max(0, Math.floor(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}
export function fmtDate(ts) {
  if (!ts) return "—";
  return new Date(ts * 1000).toLocaleString("uk-UA", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
}
export function initials(name) {
  return (name || "?").split(/\s+/).map((p) => p[0]).slice(0, 2).join("").toUpperCase();
}

// Токени дизайн-системи для SVG-графіків: одне джерело правди — CSS-змінні
export const tok = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();

export function toast(text, ms = 2600) {
  const t = h("div.toast", { role: "status" }, text);
  document.body.append(t);
  setTimeout(() => { t.classList.add("leaving"); setTimeout(() => t.remove(), 140); }, ms);
}

// Кнопка небезпечної дії: утримувати 0.7 с. Повільно, поки людина вирішує, і миттєво, коли відпускає.
export function holdButton(label, onConfirm, { cls = "danger", iconName = null, ms = 700, disabled = false } = {}) {
  const b = h(`button.btn.hold.${cls}`, { type: "button", disabled, title: "Утримуйте, щоб підтвердити" }, h("span.fill"),
    h("span.row.tight.nowrap", iconName ? ic(iconName) : null, label));
  let timer = null;
  const start = (e) => { if (b.disabled || (e.type === "keydown" && (e.repeat || (e.key !== " " && e.key !== "Enter")))) return; b.classList.add("holding"); timer = setTimeout(() => { b.classList.remove("holding"); onConfirm(); }, ms); };
  const stop = () => { clearTimeout(timer); b.classList.remove("holding"); };
  b.addEventListener("pointerdown", start); b.addEventListener("keydown", start);
  ["pointerup", "pointerleave", "pointercancel", "keyup", "blur"].forEach((ev) => b.addEventListener(ev, stop));
  return b;
}

// Модальне вікно на нативному <dialog>: фокус-пастка, Esc і повернення фокуса дає браузер.
export function modal(title, body, actions = []) {
  const opener = document.activeElement;
  const dlg = h("dialog.dlg", { "aria-label": title }, h("h2", title), h("div.modal-body", body), h("div.dlg-actions", actions));
  const close = HTMLDialogElement.prototype.close.bind(dlg);
  dlg.remove = () => { try { close(); } catch { /* */ } setTimeout(() => { Node.prototype.remove.call(dlg); if (opener && opener.focus) opener.focus(); }, 0); };
  dlg.addEventListener("cancel", (e) => { e.preventDefault(); dlg.remove(); });
  dlg.addEventListener("click", (e) => { if (e.target === dlg) dlg.remove(); });
  document.body.append(dlg);
  dlg.showModal();
  const first = dlg.querySelector("input, select, button.primary, button");
  if (first) first.focus();
  return dlg;
}

// Тема: за замовчуванням системна, вибір користувача зберігається.
const THEME_KEY = "t112.theme";
const sysDark = matchMedia("(prefers-color-scheme: dark)");
export const theme = {
  stored() { try { return localStorage.getItem(THEME_KEY); } catch { return null; } },
  current() { return this.stored() || (sysDark.matches ? "dark" : "light"); },
  isDark() { return this.current() === "dark"; },
  apply() { document.documentElement.dataset.theme = this.current(); },
  toggle() { try { localStorage.setItem(THEME_KEY, this.isDark() ? "light" : "dark"); } catch { /* */ } this.apply(); },
  // поки користувач нічого не обрав, тема йде за системою
  watch(onChange) { sysDark.addEventListener("change", () => { if (!this.stored()) { this.apply(); if (onChange) onChange(); } }); },
};

export const CATEGORY = {
  "газ": "amber", "пожежа": "red", "ДТП": "blue", "медична": "green", "утоплення": "blue",
  "насильство": "violet", "отруєння": "amber", "обстріл": "red", "рятування": "blue",
};
export const CATEGORY_META = {
  "медична":    { icon: "heart",  tint: "#fde8ec", label: "Медицина" },
  "пожежа":     { icon: "flame",  tint: "#fdebe1", label: "Пожежа" },
  "газ":        { icon: "wind",   tint: "#fff3d6", label: "Газ" },
  "отруєння":   { icon: "flask",  tint: "#f3ecff", label: "Отруєння" },
  "ДТП":        { icon: "car",    tint: "#e6f0fb", label: "ДТП" },
  "утоплення":  { icon: "waves",  tint: "#e3f4f8", label: "Вода" },
  "насильство": { icon: "shield", tint: "#efeafd", label: "Насильство" },
  "обстріл":    { icon: "alert",  tint: "#f1f1f1", label: "Обстріл" },
  "рятування":  { icon: "shield", tint: "#e3f4f8", label: "Рятування" },
};
export const DIFFICULTY = ["", "Легкий", "Середній", "Складний"];
export const ROLE_TITLES = { trainee: "Курсант", instructor: "Інструктор", methodist: "Методист" };

export function dots(n, max = 3) {
  return h("span.dots", { title: `Складність ${n} з ${max}` }, Array.from({ length: max }, (_, i) => h(i < n ? "i.on" : "i")));
}

const P = (d) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
export const icon = {
  phone: P('<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>'),
  phoneOff: P('<path d="M10.7 13.3a16 16 0 0 0 3.4 2.6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2v3a2 2 0 0 1-2.2 2A19.8 19.8 0 0 1 3.1 6.2"/><path d="M5.2 10.6A19.4 19.4 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9"/><line x1="23" y1="1" x2="1" y2="23"/>'),
  mic: P('<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M19 10v1a7 7 0 0 1-14 0v-1"/><line x1="12" y1="19" x2="12" y2="22"/>'),
  micOff: P('<line x1="2" y1="2" x2="22" y2="22"/><path d="M18.9 13.2A7 7 0 0 0 19 11v-1M5 10v1a7 7 0 0 0 12 5"/><path d="M15 9.3V5a3 3 0 0 0-5.7-1.3M9 9v2a3 3 0 0 0 5.1 2.1"/><line x1="12" y1="19" x2="12" y2="22"/>'),
  user: P('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'),
  headset: P('<path d="M3 14v-2a9 9 0 0 1 18 0v2"/><path d="M21 15a2 2 0 0 1-2 2h-1v-5h1a2 2 0 0 1 2 2zM3 15a2 2 0 0 0 2 2h1v-5H5a2 2 0 0 0-2 2z"/><path d="M19 17v1a3 3 0 0 1-3 3h-3"/>'),
  sliders: P('<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>'),
  book: P('<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V2H6.5A2.5 2.5 0 0 0 4 4.5z"/><path d="M4 19.5V22h16"/>'),
  send: P('<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>'),
  play: P('<polygon points="6 3 20 12 6 21 6 3"/>'),
  replay: P('<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><polyline points="3 3 3 8 8 8"/>'),
  ear: P('<path d="M6 8.5a6.5 6.5 0 1 1 13 0c0 6-6 6-6 10a3.5 3.5 0 1 1-7 0"/><path d="M15 8.5a2.5 2.5 0 0 0-5 0v1a2 2 0 1 1 0 4"/>'),
  sun: P('<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>'),
  moon: P('<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>'),
  heart: P('<path d="M19 14c1.5-1.5 3-3.2 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.8 0-3 .5-4.5 2-1.5-1.5-2.7-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4 3 5.5l7 7Z"/>'),
  flame: P('<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.4-.5-2-1-3-1.1-2.1-.2-4 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.2.4-2.3 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>'),
  wind: P('<path d="M17.7 7.7a2.5 2.5 0 1 1 1.8 4.3H2"/><path d="M9.6 4.6A2 2 0 1 1 11 8H2"/><path d="M12.6 19.4A2 2 0 1 0 14 16H2"/>'),
  flask: P('<path d="M9 3h6M10 3v6L4.5 18.5A2 2 0 0 0 6.2 21.5h11.6a2 2 0 0 0 1.7-3L14 9V3"/>'),
  car: P('<path d="M3 17v-5l2.2-5.2A2 2 0 0 1 7 5.5h10a2 2 0 0 1 1.8 1.3L21 12v5"/><path d="M3 12h18"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/>'),
  waves: P('<path d="M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/><path d="M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/><path d="M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/>'),
  shield: P('<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>'),
  alert: P('<path d="m21.7 18-8-14a2 2 0 0 0-3.5 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.7-3"/><path d="M12 9v4M12 17h.01"/>'),
  grid: P('<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>'),
  check: P('<polyline points="20 6 9 17 4 12"/>'),
  info: P('<circle cx="12" cy="12" r="9"/><path d="M12 16v-4M12 8h.01"/>'),
  logout: P('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>'),
};
export const ic = (name) => h("span.row.tight", { html: icon[name] });
