// Живий пульт інструктора (E6-04): список дзвінків, транскрипт наживо (включно з блоками Сторожа),
// чек-лист з цитатами, графік паніки, журнал Режисера, команди для Режисера.
import { h, clear, ic, icon, wsUrl, fmtT, toast, CATEGORY, tok, holdButton } from "./core.js";
import { emotionChart } from "./charts.js";
import { CallerVoice, playSound } from "./voice.js";

export async function renderConsole(app, user, callId) {
  const list = h("div.col");
  const left = h("div.panel", h("div.panel-head", h("h3", "Активні дзвінки"), h("span.pulse-dot")), list);
  const mid = h("div.col");
  const right = h("div.col");
  app.append(h("div.console-layout", left, mid, right));
  let listWs = null, callWs = null, closed = false;

  function renderList(calls) {
    clear(list);
    if (!calls.length) {
      list.append(h("div.empty", "Зараз немає живих дзвінків.", h("br"), h("span.small", "Коли курсант почне дзвінок, він з'явиться тут.")));
      return;
    }
    for (const c of calls) {
      list.append(h("div.callitem", { class: c.call_id === callId ? "sel" : null, on: { click: () => { location.hash = `#/console/${c.call_id}`; } } },
        h("div.row.between", h("b", c.trainee), c.started ? h("span.mono.small", fmtT(c.t)) : h("span.chip.amber", "очікує")),
        h("div.small.muted", c.title),
        h("div.row.tight", h("span.chip.red", `паніка ${(+c.panic).toFixed(1)}`), h("span.chip.green", `${c.steps_done}/${c.steps_total}`))));
    }
  }
  function connectList() {
    listWs = new WebSocket(wsUrl("/ws/calls"));
    listWs.onmessage = (m) => { const ev = JSON.parse(m.data); if (ev.type === "calls.list") renderList(ev.payload); };
    listWs.onclose = () => { if (!closed) setTimeout(connectList, 1500); };
  }
  connectList();

  if (!callId) {
    mid.append(h("div.empty-state",
      h("span.empty-ico", { html: icon.headset }),
      h("h2", "Поки немає активних дзвінків"),
      h("p.muted", "Коли курсант прийме виклик, дзвінок з'явиться ліворуч. Ви зможете слухати, бачити чек-лист і керувати Режисером."),
      h("a.btn.ghost", { href: "#/cabinet" }, "Призначити сесію")));
    return () => { closed = true; if (listWs) listWs.close(); };
  }

  // ── Обраний дзвінок ──────────────────────────────────
  let st = null;
  const head = h("div.panel.tight");
  const tr = h("div.transcript.rows-sm");
  const chartBox = h("div");
  const stepsBox = h("div");
  const logBox = h("div.log.rows-sm");
  const listen = h("input", { type: "checkbox" });
  const voice = new CallerVoice({});
  mid.append(head,
    h("div.panel.transcript-panel", h("div.transcript-head", h("b", "Розмова наживо"), h("label.switch", listen, ic("ear"), "Слухати заявника")), tr),
    h("div.panel", h("h3", "Паніка і довіра"), chartBox));

  const evSel = h("select");
  const cmd = (c, arg) => { if (callWs && callWs.readyState === 1) { callWs.send(JSON.stringify({ type: "instructor.command", payload: { cmd: c, arg } })); toast("Команду передано Режисеру"); } };
  const endCall = holdButton("Утримуйте, щоб завершити дзвінок", () => callWs.send(JSON.stringify({ type: "call.end", payload: {} })), { iconName: "phoneOff" });
  endCall.classList.add("w-full");
  const controls = h("div.panel", h("h3", "Команди Режисеру"),
    h("div.ctrls",   // найчастіші дії — найбільші й зверху
      h("button.btn.primary.wide", { on: { click: () => cmd("harder") } }, "⬆ Ускладнити"),
      h("button.btn", { on: { click: () => cmd("silence", 8) } }, "🤐 Замовкне 8 с"),
      h("button.btn", { on: { click: () => cmd("easier") } }, "⬇ Спростити"),
      h("button.btn", { on: { click: () => cmd("line_drop") } }, "📵 Обрив зв'язку"),
      h("button.btn", { on: { click: () => cmd("panic", 2) } }, "＋ Паніка"),
      h("button.btn", { on: { click: () => cmd("hysteria") } }, "😱 Істерика")),
    h("div.row.nowrap.mt-3", evSel, h("button.btn.primary", { on: { click: () => evSel.value && cmd("inject", evSel.value) } }, "Вкинути")),
    h("div.mt-6", endCall));
  right.append(controls, h("div.panel", h("div.panel-head", h("h3", "Чек-лист наживо"), h("span.tiny.faint", "з цитатами")), stepsBox),
    h("div.panel", h("h3", "Журнал Режисера і Сторожа"), logBox));

  const msgs = new Map();
  function addMsg(id, who, t, text, extra = {}) {
    if (msgs.has(id)) return;
    const el = h(`div.msg.${who}`, { class: extra.blocked ? "blocked" : null },
      h("div.meta", h("span", fmtT(t)), h("span", who === "caller" ? "Заявник" : "Курсант"), extra.emotion ? h(`span.emo.${extra.emotion}`, extra.emotion) : null,
        extra.facts && extra.facts.length ? h("span.chip.blue", extra.facts.join(", ")) : null, extra.blocked ? h("span.chip.red", `Сторож: ${extra.blocked}`) : null),
      h("div.bubble", text));
    msgs.set(id, el); tr.append(el); tr.scrollTop = tr.scrollHeight;
  }
  function log(t, html) { logBox.prepend(h("div", h("span.faint", fmtT(t) + " "), h("span", { html }))); }
  function renderHead() {
    clear(head).append(h("div.row.between",
      h("div", h("div.row.tight", h("b", st.scenario_title), h(`span.chip.${CATEGORY[st.category] || "blue"}`, st.category),
        h("span.chip", `гілка: ${st.branch}`), h("span.chip.mono", `seed ${st.scenario ? st.scenario.seed : "—"}`), h("span.chip.violet", `складність ${(+st.director.difficulty).toFixed(2)}`)),
      h("div.small.muted", `Легенда: ${st.legend.name}, ${st.legend.age} р. · ${st.legend.location}`)),
      h("div.timer", { id: "ctimer" }, fmtT(st.t_now))));
  }
  function renderSteps() {
    clear(stepsBox);
    for (const s of st.steps) {
      const m = st.checklist[s.id];
      const overdue = !m && s.deadline_s && st.t_now > s.deadline_s * 1000;
      stepsBox.append(h("div.steprow", h("div.ic", m ? h("span.check-ok", "✓") : overdue ? h("span.check-no", "!") : h("span.faint", "○")),
        h("div.grow", h("div.row.tight", h("span", s.title), s.critical ? h("span.chip.red", "крит.") : null,
          s.deadline_s ? h(`span.chip${overdue ? ".red" : ""}`, `≤${s.deadline_s}с`) : null),
          m ? h("div.q", h("span.mono", fmtT(m.t)), ` «${m.quote}»`, m.needs_review ? h("span.chip.violet", "перевірити") : null) : null)));
    }
  }
  function renderChart() { clear(chartBox).append(emotionChart(st.emotion_series, st.t_now + 5000, st.scene.map((x) => ({ x: x.t, label: x.title || x.caption, color: tok("--amber") })))); }
  let t0 = performance.now();
  const tick = setInterval(() => { if (st && st.started && !st.finished) { st.t_now += performance.now() - t0; t0 = performance.now(); const el = document.getElementById("ctimer"); if (el) el.textContent = fmtT(st.t_now); } else t0 = performance.now(); }, 500);

  function connectCall() {
    callWs = new WebSocket(wsUrl(`/ws/call/${callId}?role=instructor&name=${encodeURIComponent(user.name)}`));
    callWs.onmessage = (m) => {
      const ev = JSON.parse(m.data); const p = ev.payload || {};
      if (ev.type === "error") { clear(mid).append(h("div.panel.empty", h("h2", "Дзвінок завершено"), h("p", p.message))); return; }
      if (ev.type === "call.snapshot") {
        st = p; t0 = performance.now();
        renderHead(); renderSteps(); renderChart();
        clear(evSel).append(h("option", { value: "" }, "— подія сценарію —"), st.events_catalog.map((e) => h("option", { value: e.id }, e.title)));
        st.transcript.forEach((u) => addMsg(u.id, u.who, u.t, u.text, { emotion: u.emotion, facts: u.facts }));
        return;
      }
      if (!st) return;
      switch (ev.type) {
        case "call.started": case "phase.changed": st.started = true; if (p.phase === "debrief") st.finished = true; break;
        case "operator.final": addMsg(p.uid, "operator", ev.t, p.text); break;
        case "caller.utterance": addMsg(p.uid, "caller", ev.t, p.text, { emotion: p.emotion, facts: p.facts }); break;
        case "caller.sentence_blocked": addMsg(ev.id, "caller", ev.t, p.text, { blocked: p.reason }); log(ev.t, `<b>Сторож</b> заблокував: ${p.reason}`); break;
        case "tts.say": if (listen.checked && !p.filler) voice.say({ ...p, uid: "l" + p.uid }); break;
        case "tts.stop": voice.stop(); log(ev.t, "<b>Barge-in</b>: курсант перебив заявника"); break;
        case "barge_in.ignored": log(ev.t, "Заявник в істериці — договорює поверх курсанта"); break;
        case "checklist.step":
          if (p.override && !p.done) st.checklist[p.step_id] = null; else st.checklist[p.step_id] = p;
          renderSteps(); break;
        case "caller.emotion":
          if (p.panic !== undefined) { st.emotion_series.push({ t: ev.t, panic: p.panic, trust: p.trust, reason: p.reason }); st.caller.panic = p.panic; renderChart(); }
          if (p.reason) log(ev.t, `<b>Емоції</b> ${p.panic !== undefined ? `паніка ${(+p.panic).toFixed(1)}, довіра ${(+p.trust).toFixed(1)}` : ""} — ${p.reason}`);
          break;
        case "director.directive": if (p.text) log(ev.t, `<b>Директива</b>: ${p.text}`); break;
        case "director.state": if (p.difficulty !== undefined) { st.director.difficulty = p.difficulty; renderHead(); } break;
        case "scene.event": st.scene.push({ t: ev.t, ...p }); log(ev.t, `<b>Подія</b>: ${p.title}${p.by ? ` (${p.by})` : ""}`); if (listen.checked && p.sound) playSound(p.sound); renderChart(); break;
        case "instructor.command": log(ev.t, `<b>Інструктор</b> ${p.by || ""}: ${p.cmd} ${p.arg || ""}`); break;
        case "entities.updated": if (p.entities && p.entities.address && p.entities.address.confirmed) log(ev.t, "<b>Нормалізатор</b>: адресу підтверджено"); break;
        case "call.end": st.finished = true; log(ev.t, `<b>Кінець дзвінка</b>: ${p.reason}`); break;
        case "report.ready": mid.prepend(h("div.panel", h("div.row.between", h("b", `Звіт готовий: ${p.score} балів`), h("a.btn.primary.small", { href: `#/report/${callId}` }, "Відкрити звіт")))); break;
        default: break;
      }
    };
    callWs.onclose = () => { if (!closed && !(st && st.finished)) setTimeout(connectCall, 1500); };
  }
  connectCall();
  return () => { closed = true; clearInterval(tick); voice.stop(); if (listWs) listWs.close(); if (callWs) callWs.close(); };
}
