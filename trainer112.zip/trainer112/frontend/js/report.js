// Звіт після сесії: бал, критичні кроки, рекомендації з цитатами, графік паніки, таймлайн,
// чек-лист з доказами (+ калібрування інструктором), картка, мовлення, реплей і «переграти з моменту».
import { api, h, clear, ic, icon, plural, fmtT, fmtDate, toast, tok } from "./core.js";
import { emotionChart, scoreRing } from "./charts.js";

const STEP_KEYS = { address_asked: "До адреси", address_confirmed: "Підтвердження адреси", safety_advice: "Інструкція з безпеки", breathing_check: "Перевірка дихання", alarm: "До сигналу «Тривога»", people: "Загроза людям" };

export async function renderReport(app, user, sid) {
  const s = await api.get(`/api/sessions/${sid}`);
  const r = s.report;
  if (!r) { app.append(h("div.panel", h("h2", "Звіт ще не готовий"), h("p.muted", "Сесія не завершена."))); return; }
  const canCalibrate = user.role !== "trainee";
  const calib = Object.fromEntries((s.calibrations || []).map((c) => [c.step_id, c]));

  const replay = async (t) => {
    const res = await api.post("/api/calls", { trainee: s.trainee === user.name ? user.name : s.trainee, from_session: sid, from_t: Math.max(0, Math.round(t)) });
    location.hash = `#/call/${res.call_id}`;
  };

  // ── Шапка ─────────────────────────────────────────
  const passed = r.passed_instructor ?? r.passed;
  const headline = r.missed_critical.length
    ? `Пропущено ${plural(r.missed_critical.length, ["критичний крок", "критичні кроки", "критичних кроків"])}`
    : "Усі критичні кроки виконано";
  app.append(h("section.report-hero.section",
    scoreRing(r.score_instructor ?? r.score, passed),
    h("div.col",
      h("div.row.tight", h("span", { class: `chip ${passed ? "green" : "red"} self-start` }, passed ? "Зараховано" : "Не зараховано"),
        s.options && s.options.blind ? h("span.chip", "Випадкова ситуація") : null),
      h("h1.m-0", r.scenario_title),
      h("p.lead.m-0", headline),
      r.pass_reason ? h("p.small.m-0", r.pass_reason) : null,
      h("p.small.muted.m-0", `${s.trainee} · ${fmtDate(s.created)} · тривалість ${fmtT(r.duration_s * 1000)} · ${endReason(r.end_reason)}`)),
    h("div.report-actions",
      r.replay_t != null ? h("button.btn.primary", { on: { click: () => replay(r.replay_t) } }, ic("replay"), `Переграти з ${fmtT(r.replay_t)}`) : null,
      h("button.btn.ghost", { on: { click: () => replay(0) } }, "Пройти знову"),
      h("a.btn.link", { href: user.role === "trainee" ? "#/home" : "#/cabinet" }, "Назад"))));

  // ── Ключові метрики ─────────────────────────────────
  const stats = Object.entries(r.time_to).map(([k, v]) => {
    const row = r.checklist.find((c) => c.step_id === k);
    const bad = v == null || (row && row.late);
    return h(`div.stat.${bad ? "bad" : "good"}`, h("div.k", STEP_KEYS[k] || (row ? row.title : k)),
      h("div.v", v == null ? "—" : `${v}`, v == null ? null : h("small", " с"), row && row.deadline_s ? h("small", ` / ${row.deadline_s} с`) : null));
  });
  stats.push(h("div.stat", h("div.k", "Картка виклику"), h("div.v", r.card_score != null ? `${r.card_score}` : "—", h("small", "%"))));
  stats.push(h("div.stat", h("div.k", "Паніка в кінці"), h("div.v", (+r.final_emotion.panic).toFixed(1), h("small", " /10"))));
  app.append(h("div.grid.stats.section.stagger", stats));

  // ── Рекомендації ─────────────────────────────────────
  const PRIO = { 0: ["alert", "danger"], 9: ["check", "ok"] };   // усе інше: ["info", "warn"]
  app.append(h("div.section", h("h2", "Що покращити"), h("div.grid.two", r.recommendations.map((rec) => {
    const [ico, tone] = PRIO[rec.prio] || ["info", "warn"];
    const showReplay = rec.replay_t != null && rec.replay_t !== r.replay_t && rec.replay_t > 0;
    return h("article.rec-card",
      h("span", { class: `rec-ico tone-${tone}`, html: icon[ico] }),
      h("div.col",
        h("h3.m-0", rec.title),
        h("p.small.m-0", rec.text),
        rec.quote ? h("blockquote.quote", h("div.who", `${rec.quote_who === "operator" ? "Ви" : "Заявник"} · ${fmtT(rec.t)}`), `«${rec.quote}»`) : null,
        showReplay ? h("button.btn.link.self-start", { on: { click: () => replay(rec.replay_t) } }, `Переграти з ${fmtT(rec.replay_t)}`) : null));
  }))));

  // ── Графік паніки ─────────────────────────────────────
  const xMax = Math.max(r.duration_s * 1000, ...r.emotion_series.map((e) => e.t));
  const markers = r.timeline.filter((x) => x.kind === "scene").map((x) => ({ x: x.t, label: x.text, color: tok("--amber") }))
    .concat(r.timeline.filter((x) => x.kind === "missed").map((x) => ({ x: x.t, label: x.text, color: tok("--red") })));
  app.append(h("div.panel.section",
    h("div.panel-head", h("h3", "Паніка і довіра заявника"), h("div.legend", h("span", h("i", { style: { background: "var(--red)" } }), "паніка"),
      h("span", h("i", { style: { background: "var(--blue)" } }), "довіра"), h("span", h("i", { style: { background: "var(--amber)" } }), "події сюжету"))),
    emotionChart(r.emotion_series, xMax, markers, (t) => { slider.value = t; showAt(t); }),
    h("p.tiny.faint.mt-2.mb-0", "Наведіть, щоб побачити причину зміни з журналу Режисера. Клікніть, щоб перемотати реплей.")));

  // ── Чек-лист і таймлайн ───────────────────────────────
  const checklist = h("div.panel", h("div.panel-head", h("h3", "Чек-лист протоколу"), canCalibrate ? h("span.tiny.muted", "Калібрування: підтвердіть або виправте") : null),
    r.checklist.map((c) => {
      const cal = calib[c.step_id];
      const done = cal ? !!cal.instructor_done : c.done;
      const icon = !c.done ? h("span.check-no", "✗") : c.late ? h("span.check-late", "◔") : h("span.check-ok", "✓");
      return h("div.steprow",
        h("div.ic", icon),
        h("div.grow",
          h("div.row.tight", h("b", c.title), c.critical ? h("span.chip.red", "критичний") : null,
            c.deadline_s ? h("span.chip", `≤ ${c.deadline_s} с`) : null, c.late ? h("span.chip.amber", "запізно") : null,
            c.basis === "методична" ? h("span.chip", "методична вимога") : null,
            c.basis === "потребує підтвердження" ? h("span.chip.amber", "потребує підтвердження") : null,
            c.needs_review ? h("span.chip.violet", "перевірити") : null,
            cal ? h(`span.chip.${cal.instructor_done ? "green" : "red"}`, `інструктор: ${cal.instructor_done ? "виконано" : "не виконано"}`) : null),
          c.source ? h("div.tiny.muted", "Підстава: " + c.source) : null,
          c.done ? h("div.q", h("span.mono", fmtT(c.t)), ` «${c.quote}»`, c.confidence != null ? h("span.faint", ` · впевненість ${Math.round(c.confidence * 100)}%`) : null)
            : h("div.q", "Приклад: ", h("i", c.example))),
        canCalibrate ? h("div.row.tight.nowrap",
          h("button.btn.icon", { title: "Виконано", "aria-label": "Виконано", class: done ? "primary" : null, on: { click: () => calibrateStep(sid, c.step_id, true, user) } }, "✓"),
          h("button.btn.icon", { title: "Не виконано", "aria-label": "Не виконано", class: !done ? "danger" : null, on: { click: () => calibrateStep(sid, c.step_id, false, user) } }, "✗")) : null);
    }));
  const tl = h("div.timeline", r.timeline.map((x) => h(`div.tl.${x.kind}`, h("span.t", fmtT(x.t)),
    h("span", x.kind === "operator" ? h("b", "Ви: ") : x.kind === "caller" ? h("b.muted", "Заявник: ") : x.kind === "emotion" ? "↯ " : x.kind === "scene" ? "🔊 " : x.kind === "step" ? "✓ " : x.kind === "missed" ? "⏱ " : "",
      x.text, x.kind === "emotion" ? ` (паніка ${(+x.panic).toFixed(1)})` : ""))));
  app.append(h("div.grid.two.section", checklist, h("div.panel", h("h3", "Таймлайн"), tl)));

  // ── Картка і мовлення ───────────────────────────────
  const sp = r.speech;
  app.append(h("div.grid.two.section",
    h("div.panel", h("h3", "Картка виклику"), h("table", h("thead", h("tr", h("th", "Поле"), h("th", "Ви записали"), h("th", "Факт"))),
      h("tbody", r.card.map((c) => h("tr", h("td", c.label), h("td", { class: c.ok ? "check-ok" : "check-no" }, c.got == null || c.got === "" ? "—" : String(c.got)), h("td.muted", String(c.expected))))))),
    h("div.panel", h("h3", "Мовлення"), h("div.grid.stats",
      h("div.stat", h("div.k", "Темп"), h("div.v", sp.wpm, h("small", " сл/хв"))),
      h("div.stat", h("div.k", "Найдовша пауза"), h("div.v", (sp.longest_pause_ms / 1000).toFixed(1), h("small", " с"))),
      h("div.stat", h("div.k", "Паузи > 3 с"), h("div.v", sp.pauses_over_threshold)),
      h("div.stat", h("div.k", "Перебивання"), h("div.v", sp.interruptions)),
      h("div.stat", h("div.k", "Слова-паразити"), h("div.v", sp.fillers)),
      h("div.stat", h("div.k", "Блоків Сторожа"), h("div.v", r.guard_blocked))))));

  // ── Реплей ──────────────────────────────────────────
  const slider = h("input", { type: "range", min: 0, max: xMax, step: 500, value: xMax });
  const tLabel = h("span.mono", fmtT(xMax));
  const replayBox = h("div.col.rows-sm");
  let timerId = null;
  async function showAt(t) {
    tLabel.textContent = fmtT(t);
    clearTimeout(timerId);
    timerId = setTimeout(async () => {
      const st = await api.get(`/api/sessions/${sid}/state?t=${Math.round(t)}`);
      clear(replayBox).append(
        h("div.row.tight", h("span.chip.red", `паніка ${(+st.caller.panic).toFixed(1)}`), h("span.chip.blue", `довіра ${(+st.caller.trust).toFixed(1)}`),
          h("span.chip.green", `кроків: ${Object.values(st.checklist).filter(Boolean).length}/${Object.keys(st.checklist).length}`),
          h("span.chip", `факти: ${st.facts.revealed.join(", ") || "—"}`)),
        ...st.transcript.slice(-6).map((u) => h(`div.msg.${u.who}`, h("div.meta", fmtT(u.t)), h("div.bubble", u.text))));
    }, 120);
  }
  slider.addEventListener("input", () => showAt(+slider.value));
  app.append(h("div.panel.section", h("div.panel-head", h("h3", "Реплей: стан дзвінка на будь-яку секунду"),
    h("div.row", tLabel, h("button.btn.ghost", { on: { click: () => replay(+slider.value) } }, ic("replay"), "Переграти з цього моменту"))),
  slider, replayBox));
  showAt(xMax);

  // ── Технічні деталі (службові дані, які курсанту зайві на першому екрані) ──
  app.append(h("details.fold", { open: canCalibrate },
    h("summary", "Технічні деталі"),
    h("div.fold-body", h("dl.kv",
      h("dt", "Категорія"), h("dd", r.category),
      h("dt", "Гілка сценарію"), h("dd.mono", r.branch),
      h("dt", "Seed"), h("dd.mono", String(r.seed)),
      r.score_instructor != null ? [h("dt", "Бал після калібрування"), h("dd", String(r.score_instructor))] : null))));
}

function endReason(r) {
  return { operator: "завершив оператор", timeout: "час вичерпано", instructor: "завершив інструктор", plot: "сюжетний фінал" }[r] || r || "";
}

async function calibrateStep(sid, step, done, user) {
  const res = await api.post(`/api/sessions/${sid}/calibrate`, { step_id: step, done, by: user.name });
  toast(`Збережено. Бал після калібрування: ${res.score_instructor}`);
  window.dispatchEvent(new HashChangeEvent("hashchange"));
}
