// Кабінет методиста: бібліотека сценаріїв, чотири шари картки (E2-02), YAML-редактор зі схемою і
// валідацією (E2-05), створення з шаблону без програміста + автопрогін ботом-курсантом (E2-03).
import { api, h, clear, toast, dots, CATEGORY } from "./core.js";

const TEMPLATE = `id: new-scenario-01
title: Новий сценарій
category: інше
difficulty: 1
brief: Короткий опис для курсанта.
skills: [адреса]
max_duration_s: 300
silence_threshold_s: 4
legend:
  name: Ім'я
  age: 40
  gender: female
  location: де знаходиться заявник
  sees: що бачить
  manner: як говорить
  fillers: ["ну", "ой"]
  voice: female_40
  opening: ["Алло! Допоможіть!"]
initial: {panic: 6, trust: 4}
facts:
  - id: what
    say: ["Опис події."]
    reveal: {asked: [what, greeting], volunteer: true}
    truth: {incident_type: інше}
  - id: street
    say: ["Вулиця Зелена!"]
    reveal: {asked: [address]}
    critical: true
  - id: house
    say: ["Будинок три."]
    reveal: {asked: [house]}
    critical: true
  - id: people
    say: ["Я тут сама."]
    reveal: {asked: [people]}
    truth: {victims: 1}
  - id: name
    say: ["Ольга Зінчук."]
    reveal: {asked: [name]}
    truth: {caller_name: Зінчук}
  - id: phone
    say: ["Нуль дев'яносто, сто, двадцять, тридцять."]
    reveal: {asked: [phone]}
events:
  - id: panic_up
    title: Паніка зростає
    trigger: {after_s: 40, unless_step: address_asked}
    effects: {panic: 2, say: "Ну чого ви мовчите?!"}
complications: []
branches:
  - {id: main, weight: 1, title: Стандарт}
protocol:
  base: standard
  steps:
    - id: safety_advice
      title: "Безпека: конкретна інструкція"
      deadline_s: 120
      rule: {keywords: ["не заходьте", "вийдіть"]}
      example: "Вийдіть з приміщення і не заходьте назад."
card_truth: {address: ["Зелена", "3"], incident_type: інше, victims: 1, caller_name: Зінчук}
`;

export async function renderMethodist(app, user, sid) {
  const scs = await api.get("/api/scenarios");
  const list = h("div.col");
  for (const s of scs) {
    list.append(h("div.callitem", { class: s.id === sid ? "sel" : null, on: { click: () => { location.hash = `#/methodist/${s.id}`; } } },
      h("div.row.between", h("b", s.title), s.valid ? dots(s.difficulty) : h("span.chip.red", "помилка")),
      h("div.row.tight", s.valid ? h(`span.chip.${CATEGORY[s.category] || "blue"}`, s.category) : null, s.valid ? h("span.tiny.muted", `${s.branches.length} гілок · ${s.steps} кроків`) : h("span.tiny.muted", (s.errors || [])[0]))));
  }
  const main = h("div.col");
  app.append(h("div.row.between.section", h("div", h("h1", "Сценарії і протокол"),
    h("p.muted.m-0", "Кожен сценарій має чотири шари; кожен агент бачить лише свій. Зміни проходять валідацію схеми і автоматичний прогін ботом-курсантом.")),
  h("button.btn.primary", { on: { click: () => { location.hash = "#/methodist/new"; } } }, "+ Новий з шаблону")),
  h("div.layout-2col", h("div.panel", list), main));

  if (!sid) { main.append(h("div.panel.empty", h("h2", "Оберіть сценарій"), h("p", "Тут видно легенду, факти з умовами розкриття, сюжетні події та протокол з вагами."))); return; }
  let data = null, yaml = TEMPLATE;
  if (sid !== "new") { data = await api.get(`/api/scenarios/${sid}?role=methodist`); yaml = data.yaml; }

  const tabsEl = h("div.tabs");
  const view = h("div");
  const tabs = data ? [["legend", "Легенда (Абонент)"], ["facts", "Факти (Абонент + Режисер)"], ["plot", "Події і гілки (Режисер)"], ["protocol", "Протокол (Оцінювач)"], ["yaml", "YAML"]] : [["yaml", "YAML"]];
  let cur = data ? "legend" : "yaml";
  const draw = () => {
    clear(tabsEl).append(...tabs.map(([id, t]) => h("button", { class: id === cur ? "active" : null, on: { click: () => { cur = id; draw(); } } }, t)));
    clear(view).append(renderLayer(cur, data, yaml, user, (y) => { yaml = y; }));
  };
  main.append(h("div.panel", data ? h("div.row.between", h("h2", data.title), h("div.row", h("button.btn.small", { on: { click: () => botcheck(sid, view) } }, "▶ Прогнати ботом-курсантом"))) : h("h2", "Новий сценарій"), tabsEl, view));
  draw();
}

function renderLayer(id, d, yaml, user, setYaml) {
  if (id === "yaml") return yamlEditor(yaml, user, setYaml);
  const L = d.layers;
  if (id === "legend") {
    const g = L.caller.legend;
    return h("dl.kv", ...[["Ім'я", g.name], ["Вік", g.age], ["Де", g.location], ["Бачить", g.sees], ["Манера", g.manner], ["Слова-паразити", g.fillers.join(", ")],
      ["Голос", g.voice], ["Перша фраза", g.opening.join(" / ")], ["Коли не знає", g.unknown.join(" / ")]].flatMap(([k, v]) => [h("dt", k), h("dd", String(v))]));
  }
  if (id === "facts") {
    return h("table", h("thead", h("tr", ["Факт", "Що каже", "Умова розкриття", "Картка"].map((t) => h("th", t)))),
      h("tbody", L.caller.facts.map((f) => h("tr", h("td", h("b.mono", f.id), f.critical ? h("div", h("span.chip.red", "критичний")) : null),
        h("td.small", f.say.join(" / ")),
        h("td.small", cond(f.reveal)), h("td.small.muted", Object.entries(f.truth || {}).map(([k, v]) => `${k}: ${v}`).join(", "))))));
  }
  if (id === "plot") {
    const ev = (e) => h("tr", h("td", h("b", e.title), h("div.tiny.mono.faint", e.id)), h("td.small", trig(e.trigger)), h("td.small", eff(e.effects)));
    return h("div.col",
      h("h3", "Сюжетні події"), h("table", h("tbody", d.layers.director.events.map(ev))),
      h("h3", "Ускладнення (адаптивний режисер і пульт інструктора)"), h("table", h("tbody", d.layers.director.complications.map(ev))),
      h("h3", "Гілки"), h("div.row", d.branches.map((b) => h("span.chip.violet", `${b.id} · вага ${b.weight}${b.title ? ` · ${b.title}` : ""}`))));
  }
  if (id === "protocol") {
    const P = d.layers.evaluator.protocol;
    const total = P.reduce((a, s) => a + s.weight, 0);
    return h("div.col", h("table", h("thead", h("tr", ["#", "Крок", "Вага", "Дедлайн", "Правило", "Приклад для бота"].map((t) => h("th", t)))),
      h("tbody", P.map((s, i) => h("tr", h("td.mono", i + 1), h("td", h("b", s.title), s.critical ? h("div", h("span.chip.red", "критичний")) : null),
        h("td.mono", `${s.weight} (${Math.round((s.weight / total) * 100)}%)`), h("td.mono", s.deadline_s ? `${s.deadline_s} с` : "—"),
        h("td.small.mono", rule(s.rule)), h("td.small.muted", s.example))))),
    h("p.small.muted", "Пороги дедлайнів і ваги — чернетка методики (E8-05), остаточно затверджує методист. Бал рахує код, а не LLM."));
  }
  return h("div");
}

function cond(r) {
  const p = [];
  if (r.asked && r.asked.length) p.push(`коли питають: ${r.asked.join(", ")}`);
  if (r.volunteer) p.push("може сказати сам");
  if (r.after_s != null) p.push(`сам після ${r.after_s} с`);
  if (r.min_trust) p.push(`довіра ≥ ${r.min_trust}`);
  if (r.max_panic < 10) p.push(`паніка ≤ ${r.max_panic}`);
  if (r.after_fact) p.push(`після факту ${r.after_fact}`);
  return p.join("; ");
}
function trig(t) {
  if (t.manual) return "вручну / ускладнення";
  const p = [];
  if (t.at_s != null) p.push(`на ${t.at_s} с`);
  if (t.after_s != null) p.push(`після ${t.after_s} с`);
  if (t.unless_step) p.push(`якщо не виконано «${t.unless_step}»`);
  if (t.if_step) p.push(`якщо виконано «${t.if_step}»`);
  if (t.after_fact) p.push(`через ${t.delay_s} с після факту ${t.after_fact}`);
  return p.join(", ");
}
function eff(e) {
  const p = [];
  if (e.panic) p.push(`паніка ${e.panic > 0 ? "+" : ""}${e.panic}`);
  if (e.trust) p.push(`довіра ${e.trust > 0 ? "+" : ""}${e.trust}`);
  if (e.say) p.push(`каже: «${e.say}»`);
  if (e.sound) p.push(`звук: ${e.sound}`);
  if (e.silent_s) p.push(`мовчить ${e.silent_s} с`);
  return p.join("; ");
}
function rule(r) {
  if (r.entity_confirmed) return `сутність «${r.entity_confirmed}» підтверджена повтором`;
  if (r.all_groups && r.all_groups.length) return r.all_groups.map((g) => `(${g.join(" | ")})`).join(" І ");
  if (r.keywords && r.keywords.length) return r.keywords.join(" | ");
  if (r.intent) return `питання типу «${r.intent}»`;
  if (r.semantic) return `LLM: ${r.semantic}`;
  return "—";
}

function yamlEditor(yaml, user, setYaml) {
  const ta = h("textarea.code", { spellcheck: false }); ta.value = yaml;
  ta.addEventListener("input", () => setYaml(ta.value));
  ta.addEventListener("keydown", (e) => { if (e.key === "Tab") { e.preventDefault(); const s = ta.selectionStart; ta.setRangeText("  ", s, s, "end"); } });
  const out = h("div.col");
  const validate = async () => {
    const r = await api.post("/api/scenarios/validate", { yaml: ta.value });
    clear(out).append(r.ok ? h("div.quote.ok", h("b.check-ok", "✓ Схема валідна. "), `Кроків протоколу: ${r.steps.length}`)
      : h("div.quote.err", h("b.check-no", "Помилки:"), h("ul", r.errors.map((e) => h("li.mono.small", e)))));
    return r.ok;
  };
  const save = async () => {
    if (!(await validate())) return;
    clear(out).append(h("div.row", h("div.spinner.inline"), "Зберігаю і проганяю ботом-курсантом…"));
    const r = await api.post("/api/scenarios", { yaml: ta.value, by: user.name });
    if (!r.ok) { clear(out).append(h("div.quote", r.errors.join("; "))); return; }
    toast("Сценарій збережено");
    clear(out).append(botResult(r.bot_check));
  };
  return h("div.col", h("div.row", h("button.btn", { on: { click: validate } }, "Перевірити схему"), h("button.btn.primary", { on: { click: save } }, "Зберегти і прогнати ботом"),
    h("a.btn.small.ghost", { href: "/api/schema", target: "_blank" }, "JSON-схема сценарію")), ta, out);
}

async function botcheck(sid, view) {
  clear(view).append(h("div.row", h("div.spinner.inline"), "Бот-курсант проходить сценарій усіма гілками…"));
  const r = await api.post(`/api/scenarios/${sid}/botcheck`, {});
  clear(view).append(botResult(r));
}

function botResult(r) {
  return h("div.col", h("div.row", r.ok ? h("span.chip.green", "Автоперевірка пройдена") : h("span.chip.red", "Автоперевірка не пройдена"),
    h("span.small.muted", `ідеальний ≥ 90 і зараховано: ${r.ideal_ok ? "так" : "ні"} · «забуває адресу» валить критичний крок: ${r.forgets_address_fails ? "так" : "ні"}`)),
  h("div.table-wrap", h("table", h("thead", h("tr", ["Стиль", "Гілка", "Seed", "Бал", "Зараховано", "Пропущено", ""].map((t) => h("th", t)))),
    h("tbody", r.runs.map((x) => h("tr", h("td", x.style === "ideal" ? "Ідеальний" : "Забуває адресу"), h("td", x.branch), h("td.mono", x.seed), h("td.mono", x.score),
      h("td", x.passed ? "✓" : "✗"), h("td.small.muted", x.missed.join(", ")), h("td.text-right", h("a.btn.small.ghost", { href: `#/report/${x.session_id}` }, "Звіт →"))))))));
}
