// Кабінет інструктора: призначення сесій (E6-01), результати, аналітика групи (E6-02),
// калібрування (E5-04), спостережуваність (крок 8), аудит (E1-04), експорт CSV (E6-03).
import { api, h, clear, fmtDate, fmtT, toast, dots, tok } from "./core.js";
import { lineChart, sparkline } from "./charts.js";

const TABS = [["assign", "Призначення"], ["results", "Результати"], ["group", "Аналітика групи"],
  ["calib", "Калібрування"], ["obs", "Спостережуваність"], ["audit", "Аудит"]];

export async function renderCabinet(app, user, tab) {
  tab = tab || (user.role === "methodist" ? "group" : "assign");
  const body = h("div");
  app.append(h("div.row.between.section", h("h1", user.role === "methodist" ? "Аналітика і якість" : "Кабінет інструктора"),
    h("a.btn", { href: "/api/sessions.csv", download: "sessions.csv" }, "Експорт CSV")),
  h("div.tabs", TABS.map(([id, t]) => h("button", { class: id === tab ? "active" : null, on: { click: () => { location.hash = `#/cabinet/${id}`; } } }, t))), body);
  const fn = { assign: tabAssign, results: tabResults, group: tabGroup, calib: tabCalib, obs: tabObs, audit: tabAudit }[tab];
  return fn ? fn(body, user) : null;
}

async function tabAssign(body, user) {
  const [scs, trainees, as] = await Promise.all([api.get("/api/scenarios"), api.get("/api/users?role=trainee"), api.get("/api/assignments")]);
  const byId = Object.fromEntries(scs.map((s) => [s.id, s]));
  const name = h("input", { list: "trainees", placeholder: "Прізвище та ім'я курсанта" });
  const dl = h("datalist#trainees", trainees.map((t) => h("option", { value: t.name })));
  const sc = h("select", scs.filter((s) => s.valid).map((s) => h("option", { value: s.id }, `${s.title} (${s.category})`)));
  const lvl = h("select", [1, 2, 3].map((n) => h("option", { value: n, selected: n === 2 }, ["", "Базова", "Середня", "Висока"][n])));
  const due = h("input", { type: "date" });
  const note = h("input", { placeholder: "Коментар (необов'язково), напр. «зверни увагу на час до адреси»" });
  const submit = async (e) => {
    e.preventDefault();
    if (!name.value.trim()) { name.focus(); return; }
    await api.post("/api/assignments", { trainee: name.value.trim(), scenario_id: sc.value, difficulty: +lvl.value, due: due.value || null, note: note.value, by: user.name });
    toast("Сесію призначено"); location.hash = "#/cabinet/assign"; window.dispatchEvent(new HashChangeEvent("hashchange"));
  };
  body.append(h("form.panel.section", { on: { submit } }, h("h3", "Призначити сесію"),
    h("div.grid.two",
      h("label.field", "Курсант", name, dl), h("label.field", "Сценарій", sc), h("label.field", "Складність", lvl), h("label.field", "Термін", due)),
    h("div.row.mt-3", h("div.grow", note), h("button.btn.primary", { type: "submit" }, "Призначити"))));
  body.append(h("div.panel.table-wrap", h("table", h("thead", h("tr", ["Курсант", "Сценарій", "Складність", "Термін", "Статус", ""].map((t) => h("th", t)))),
    h("tbody", as.length ? as.map((a) => h("tr", h("td", a.trainee), h("td", (byId[a.scenario_id] || {}).title || a.scenario_id), h("td", dots(a.difficulty)),
      h("td.small", a.due || "—"), h("td", { done: h("span.chip.green", "виконано"), in_progress: h("span.chip.amber", "в процесі"), assigned: h("span.chip.blue", "призначено") }[a.status]),
      h("td", a.session_id && a.status === "done" ? h("a.btn.small.ghost", { href: `#/report/${a.session_id}` }, "Звіт →") : null))) : h("tr", h("td", { colspan: 6, class: "muted" }, "Поки що немає призначень."))))));
}

async function tabResults(body) {
  const [ss, scs] = await Promise.all([api.get("/api/sessions"), api.get("/api/scenarios")]);
  const byId = Object.fromEntries(scs.map((s) => [s.id, s]));
  const q = h("input", { placeholder: "Фільтр за курсантом або сценарієм" });
  const tbody = h("tbody");
  const draw = () => {
    const f = q.value.toLowerCase();
    clear(tbody).append(...ss.filter((s) => !f || s.trainee.toLowerCase().includes(f) || ((byId[s.scenario_id] || {}).title || "").toLowerCase().includes(f)).map((s) =>
      h("tr.click", { on: { click: () => { if (s.status === "done") location.hash = `#/report/${s.id}`; } } },
        h("td.mono.small", fmtDate(s.created)), h("td", s.trainee), h("td", (byId[s.scenario_id] || {}).title || s.scenario_id),
        h("td.small", s.branch), h("td.mono", s.score != null ? Math.round(s.score) : "—"),
        h("td", s.status !== "done" ? h("span.chip.amber", "в процесі") : s.passed ? h("span.chip.green", "зараховано") : h("span.chip.red", "ні")),
        h("td.small.muted", s.summary ? (s.summary.missed_critical || []).join(", ") : ""))));
  };
  q.addEventListener("input", draw); draw();
  body.append(h("div.panel", h("div.row", q), h("div.table-wrap", h("table",
    h("thead", h("tr", ["Дата", "Курсант", "Сценарій", "Гілка", "Бал", "Результат", "Пропущене критичне"].map((t) => h("th", t)))), tbody))));
}

async function tabGroup(body) {
  const a = await api.get("/api/analytics");
  const trainees = Object.entries(a.trainees);
  body.append(h("div.grid.stats.section",
    h("div.stat", h("div.k", "Сесій"), h("div.v", a.sessions)),
    h("div.stat", h("div.k", "Курсантів"), h("div.v", trainees.length)),
    h("div.stat", h("div.k", "Найслабший крок"), h("div.v.text", a.steps[0] ? a.steps[0].title : "—"))));
  body.append(h("div.grid.two",
    h("div.panel", h("h3", "Виконання кроків вчасно (вся група)"), a.steps.length ? h("div.bars", a.steps.map((s) => h("div.b",
      h("span", s.title), h("div.track", h("span", { style: { width: `${s.rate * 100}%`, background: s.rate < .6 ? "var(--red)" : s.rate < .85 ? "var(--amber)" : "var(--green)" } })),
      h("span.mono.small", `${Math.round(s.rate * 100)}%`)))) : h("p.muted", "Даних ще немає.")),
    h("div.panel", h("h3", "Прогрес курсантів"), trainees.length ? h("table", h("thead", h("tr", ["Курсант", "Сесій", "Бал (динаміка)", "Час до адреси", "Останній"].map((t) => h("th", t)))),
      h("tbody", trainees.map(([n, xs]) => h("tr", h("td", n), h("td.mono", xs.length), h("td", sparkline(xs.map((x) => x.score), { max: 100 })),
        h("td", sparkline(xs.map((x) => x.address_s || 0), { color: tok("--green") })), h("td.mono", Math.round(xs[xs.length - 1].score)))))) : h("p.muted", "Даних ще немає."))));
}

async function tabCalib(body) {
  const c = await api.get("/api/calibration");
  body.append(h("div.grid.stats.section",
    h("div.stat", h("div.k", "Перевірених кроків"), h("div.v", c.n)),
    h(`div.stat.${c.agreement != null && c.agreement < .9 ? "bad" : "good"}`, h("div.k", "Збіг з інструктором"), h("div.v", c.agreement != null ? `${Math.round(c.agreement * 100)}%` : "—", h("small", " / ціль 90%")))),
  h("div.panel.table-wrap", h("h3", "Розбіжності (набір для налаштування Оцінювача)"), h("table", h("thead", h("tr", ["Сесія", "Крок", "Система", "Інструктор", "Хто"].map((t) => h("th", t)))),
    h("tbody", c.rows.filter((r) => r.system_done !== r.instructor_done).map((r) => h("tr", h("td", h("a.btn.small.ghost.mono", { href: `#/report/${r.session_id}` }, r.session_id)), h("td", r.step_id),
      h("td", r.system_done ? "✓" : "✗"), h("td", r.instructor_done ? "✓" : "✗"), h("td.small", r.instructor)))))),
  h("p.small.muted", "Калібрування робиться у звіті сесії: кнопки ✓/✗ біля кожного кроку чек-листа."));
}

async function tabObs(body) {
  const box = h("div");
  body.append(box);
  const draw = async () => {
    const m = await api.get("/api/metrics");
    const ok = (v) => (v <= 1200 ? "good" : "bad");
    clear(box).append(h("div.grid.stats.section",
      h(`div.stat.${ok(m.e2e.p90)}`, h("div.k", "Відповідь заявника p90 (клієнт)"), h("div.v", Math.round(m.e2e.p90), h("small", " мс / ціль 1200"))),
      h("div.stat", h("div.k", "p50 (клієнт)"), h("div.v", Math.round(m.e2e.p50), h("small", " мс"))),
      h("div.stat", h("div.k", "Гарячий контур p90 (сервер)"), h("div.v", m.hot.p90, h("small", " мс"))),
      h("div.stat", h("div.k", "Блоки Сторожа"), h("div.v", `${(m.guard.blocked_share * 100).toFixed(2)}%`, h("small", ` з ${m.guard.approved + m.guard.blocked}`))),
      h("div.stat", h("div.k", "Черга холодного контуру"), h("div.v", m.cold.queue, h("small", ` макс ${m.cold.queue_max}`))),
      h("div.stat", h("div.k", "Активні дзвінки"), h("div.v", m.active_calls))),
    h("div.grid.two",
      h("div.panel", h("h3", "Затримка гарячого контуру (останні відповіді)"),
        m.series.length > 1 ? lineChart({ series: [{ name: "мс", color: tok("--blue"), points: m.series.map((p, i) => ({ x: i * 1000, y: p.hot_ms })) }],
          xMax: (m.series.length - 1) * 1000, yMax: Math.max(50, ...m.series.map((p) => p.hot_ms)) * 1.2, height: 180 }) : h("p.muted", "Ще немає даних.")),
      h("div.panel", h("h3", "Етапи"), h("table", h("thead", h("tr", ["Етап", "p50, мс", "p90, мс", "N"].map((t) => h("th", t)))),
        h("tbody", Object.entries(m.stages).map(([k, v]) => h("tr", h("td", k), h("td.mono", v.p50), h("td.mono", v.p90), h("td.mono", v.n))))),
      Object.keys(m.guard.reasons).length ? h("div", h("h3.mt-4", "Причини блоків Сторожа"), Object.entries(m.guard.reasons).map(([k, v]) => h("span.chip.red", { style: { marginRight: "6px" } }, `${k}: ${v}`))) : null)));
  };
  await draw();
  const iv = setInterval(draw, 3000);
  return () => clearInterval(iv);
}

async function tabAudit(body) {
  const rows = await api.get("/api/audit");
  body.append(h("div.panel.table-wrap", h("table", h("thead", h("tr", ["Час", "Хто", "Дія", "Деталі"].map((t) => h("th", t)))),
    h("tbody", rows.map((r) => h("tr", h("td.mono.small", fmtDate(r.ts)), h("td", r.actor), h("td", h("span.chip", r.action)), h("td.small.muted.mono", JSON.stringify(r.details).slice(0, 160))))))));
}
export { fmtT };
