// Голос у браузері: TTS абонента (Web Speech API), розпізнавання мови оператора (uk-UA),
// синтезовані звуки сцени (WebAudio). На закритому сервері TTS/ASR замінюються серверними адаптерами,
// а інтерфейс подій (tts.playing / tts.stopped / operator.*) лишається тим самим.

const STAGE = /\([^)]*\)/g;

export class CallerVoice {
  constructor({ onStart, onEnd } = {}) {
    this.onStart = onStart; this.onEnd = onEnd;
    this.queue = []; this.current = null; this.muted = false;
    this.synth = window.speechSynthesis || null;
    this.voice = null;
    this.serverTts = false;   // озвучка Gemini через /api/tts (вмикається, якщо на сервері є ключ)
    this.fails = 0;
    fetch("/api/config").then((r) => (r.ok ? r.json() : null)).then((c) => { this.serverTts = !!(c && c.tts); }).catch(() => {});
    if (this.synth) {
      const pick = () => {
        const vs = this.synth.getVoices();
        this.voice = vs.find((v) => /^uk/i.test(v.lang)) || vs.find((v) => /^ru/i.test(v.lang) && false) || null;
      };
      pick();
      this.synth.onvoiceschanged = pick;
    }
  }
  get hasVoice() { return !!(this.synth && this.voice); }

  say(item) {
    // готуємо аудіо наперед, поки грає попередня фраза: так затримка Gemini TTS непомітна
    if (this._useServer(item)) item._audio = this._fetchAudio(item);
    this.queue.push(item);
    if (!this.current) this._next();
  }

  _useServer(item) {
    return this.serverTts && !this.muted && !item.silent && this.fails < 3 && item.text.replace(STAGE, "").trim();
  }

  _fetchAudio(item) {
    const ctl = new AbortController();
    item._ctl = ctl;
    const timer = setTimeout(() => ctl.abort(), 12000);
    return fetch("/api/tts", {
      method: "POST", headers: { "Content-Type": "application/json" }, signal: ctl.signal,
      body: JSON.stringify({ text: item.text, emotion: item.emotion, voice: item.voice }),
    }).then((r) => { if (!r.ok) throw new Error(r.status); return r.blob(); })
      .then((b) => { this.fails = 0; return URL.createObjectURL(b); })
      .catch(() => { this.fails++; return null; })
      .finally(() => clearTimeout(timer));
  }

  async _playServer(item, cur, text, finish) {
    const url = await item._audio;
    if (cur.done) { if (url) URL.revokeObjectURL(url); return; }
    if (!url) return this._playLocal(item, cur, text, finish);   // відкат: браузерний голос / імітація
    const a = new Audio(url);
    cur.audio = a;
    a.playbackRate = Math.max(.8, Math.min(1.3, item.rate || 1));
    const tick = setInterval(() => { if (a.duration) cur.chars = Math.floor((a.currentTime / a.duration) * item.text.length); }, 80);
    const end = (ok) => { clearInterval(tick); URL.revokeObjectURL(url); finish(ok); };
    a.onended = () => end(true);
    a.onerror = () => end(false);
    a.play().catch(() => { clearInterval(tick); URL.revokeObjectURL(url); this._playLocal(item, cur, text, finish); });
  }

  _next() {
    const item = this.queue.shift();
    if (!item) { this.current = null; return; }
    const text = item.text.replace(STAGE, "").trim();
    const cur = { item, chars: 0, done: false, timer: null };
    this.current = cur;
    const finish = (completed) => {
      if (cur.done) return;
      cur.done = true;
      clearTimeout(cur.timer);
      this.onEnd && this.onEnd(item, completed ? item.text.length : cur.chars, completed);
      if (this.current === cur) this._next();
    };
    cur.finish = finish;
    this.onStart && this.onStart(item);
    if (!text || item.silent) { cur.timer = setTimeout(() => finish(true), 600); return; }
    if (item._audio) { this._playServer(item, cur, text, finish); return; }
    this._playLocal(item, cur, text, finish);
  }

  _playLocal(item, cur, text, finish) {
    if (cur.done) return;
    if (this.hasVoice && !this.muted) {
      const u = new SpeechSynthesisUtterance(text);
      u.voice = this.voice; u.lang = this.voice.lang;
      u.rate = Math.max(.6, Math.min(1.6, item.rate || 1));
      u.pitch = Math.max(.5, Math.min(1.8, item.pitch || 1));
      u.onboundary = (e) => { cur.chars = e.charIndex; };
      u.onend = () => finish(true);
      u.onerror = () => finish(false);
      this.synth.speak(u);
      // страховка, якщо onend не прийде
      cur.timer = setTimeout(() => finish(true), 1500 + text.length * 120);
    } else {
      // без голосу: імітуємо тривалість мовлення, щоб barge-in і паузи працювали так само
      const dur = 400 + text.length * 55 / (item.rate || 1);
      const t0 = performance.now();
      const tick = () => { cur.chars = Math.floor(((performance.now() - t0) / dur) * item.text.length); };
      cur.iv = setInterval(tick, 80);
      cur.timer = setTimeout(() => { clearInterval(cur.iv); finish(true); }, dur);
    }
  }

  stop() {
    // перебивання: зупинити поточну фразу і викинути чергу
    this.queue.forEach((i) => i._ctl && i._ctl.abort());
    this.queue = [];
    const cur = this.current;
    if (this.synth) this.synth.cancel();
    if (cur && cur.audio) { cur.audio.pause(); cur.audio = null; }
    if (cur) { clearInterval(cur.iv); cur.finish && cur.finish(false); }
    this.current = null;
  }
  get speaking() { return !!this.current; }
}

export class OperatorASR {
  constructor({ onStart, onPartial, onFinal, onState, onLevel }) {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    this.supported = !!SR;
    this.cb = { onStart, onPartial, onFinal, onState, onLevel };
    this.on = false;
    if (!SR) return;
    this.rec = new SR();
    this.rec.lang = "uk-UA"; this.rec.continuous = true; this.rec.interimResults = true;
    this.speechT0 = null; this.startSent = false; this.vadTimer = null;
    this.rec.onresult = (e) => {
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const r = e.results[i];
        if (r.isFinal) {
          const text = r[0].transcript.trim();
          const dur = this.speechT0 ? performance.now() - this.speechT0 : 0;
          this._ensureStart();
          if (text) this.cb.onFinal && this.cb.onFinal(text, Math.round(dur));
          this.speechT0 = null; this.startSent = false; clearTimeout(this.vadTimer);
        } else interim += r[0].transcript;
      }
      if (interim) {
        if (!this.speechT0) {
          this.speechT0 = performance.now();
          // VAD: мовлення довше за 300 мс — сигнал для barge-in
          this.vadTimer = setTimeout(() => this._ensureStart(), 300);
        }
        this.cb.onPartial && this.cb.onPartial(interim);
      }
    };
    this.rec.onend = () => { if (this.on) { try { this.rec.start(); } catch { /* */ } } };
    this.rec.onerror = (e) => { if (e.error === "not-allowed") { this.on = false; this.cb.onState && this.cb.onState(false, "Немає доступу до мікрофона"); } };
  }
  _ensureStart() { if (!this.startSent) { this.startSent = true; this.cb.onStart && this.cb.onStart(); } }
  async toggle() {
    if (!this.supported) return false;
    this.on = !this.on;
    if (this.on) { try { this.rec.start(); } catch { /* вже запущено */ } this._meter(); }
    else { this.rec.stop(); this._stopMeter(); }
    this.cb.onState && this.cb.onState(this.on);
    return this.on;
  }
  async _meter() {
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.ctx = new AudioContext();
      const src = this.ctx.createMediaStreamSource(this.stream);
      const an = this.ctx.createAnalyser(); an.fftSize = 256; src.connect(an);
      const buf = new Uint8Array(an.frequencyBinCount);
      const loop = () => {
        if (!this.on) return;
        an.getByteTimeDomainData(buf);
        let s = 0; for (const v of buf) s += (v - 128) ** 2;
        this.cb.onLevel && this.cb.onLevel(Math.min(1, Math.sqrt(s / buf.length) / 40));
        requestAnimationFrame(loop);
      };
      loop();
    } catch { /* рівень гучності необов'язковий */ }
  }
  _stopMeter() {
    if (this.stream) this.stream.getTracks().forEach((t) => t.stop());
    if (this.ctx) this.ctx.close();
    this.stream = null; this.ctx = null;
    this.cb.onLevel && this.cb.onLevel(0);
  }
}

// Синтезовані звуки сцени (scene.event.sound) — без аудіофайлів.
let actx = null;
function ctx() { if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)(); return actx; }
function tone(f, t0, dur, type = "sine", gain = .15, f2 = null) {
  const c = ctx(); const o = c.createOscillator(); const g = c.createGain();
  o.type = type; o.frequency.setValueAtTime(f, c.currentTime + t0);
  if (f2) o.frequency.linearRampToValueAtTime(f2, c.currentTime + t0 + dur);
  g.gain.setValueAtTime(0, c.currentTime + t0);
  g.gain.linearRampToValueAtTime(gain, c.currentTime + t0 + .02);
  g.gain.linearRampToValueAtTime(0, c.currentTime + t0 + dur);
  o.connect(g).connect(c.destination); o.start(c.currentTime + t0); o.stop(c.currentTime + t0 + dur + .05);
}
function noise(t0, dur, gain = .25, freq = 800) {
  const c = ctx(); const n = c.sampleRate * dur; const b = c.createBuffer(1, n, c.sampleRate);
  const d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
  const s = c.createBufferSource(); s.buffer = b; const f = c.createBiquadFilter(); f.type = "lowpass"; f.frequency.value = freq;
  const g = c.createGain(); g.gain.value = gain; s.connect(f).connect(g).connect(c.destination); s.start(c.currentTime + t0);
}
export function playSound(name) {
  try {
    switch (name) {
      case "beeps": [0, .35, .7].forEach((t) => tone(425, t, .2, "sine", .12)); break;
      case "siren": tone(600, 0, 1.2, "sawtooth", .06, 1100); tone(1100, 1.2, 1.2, "sawtooth", .06, 600); break;
      case "doorbell": tone(880, 0, .4, "sine", .15); tone(660, .4, .6, "sine", .15); break;
      case "banging": case "knock": [0, .25, .5, .9].forEach((t) => noise(t, .12, .5, 300)); break;
      case "glass": noise(0, .6, .35, 6000); tone(2400, 0, .3, "triangle", .05, 3000); break;
      case "crash": case "explosion": noise(0, 1.4, .6, 400); break;
      case "child_cry": tone(700, 0, .7, "triangle", .07, 900); tone(900, .8, .9, "triangle", .07, 650); break;
      case "splash": noise(0, .7, .3, 1500); break;
      case "crowd": case "truck": case "hiss": noise(0, 1.5, .15, name === "hiss" ? 5000 : 500); break;
      default: break;
    }
  } catch { /* аудіо недоступне */ }
}
