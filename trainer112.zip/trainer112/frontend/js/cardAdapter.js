// Перетворення картки виклику між полями інтерфейсу (місто, вулиця, будинок…) і контрактом бекенда
// (одне поле address, тип події малими літерами). Додаткові ключі ui_* бекенд ігнорує, а звіряння
// з фактами сценарію працює по складеній адресі.

export const INCIDENT_TO_WIRE = {
  "Пожежа": "пожежа", "ДТП": "ДТП", "Газ, загазованість": "газ", "Рятування людей": "рятування",
  "Обстріл, руйнування": "обстріл", "Інша подія": "інше",
};
const FROM_WIRE = Object.fromEntries(Object.entries(INCIDENT_TO_WIRE).map(([k, v]) => [v, k]));

export const EXPLOSION_TO_WIRE = { "Невідомо": "невідомо", "Немає": "ні", "Є": "так" };
const EXPLOSION_FROM_WIRE = Object.fromEntries(Object.entries(EXPLOSION_TO_WIRE).map(([k, v]) => [v, k]));

const clean = (v) => String(v ?? "").trim();

// ціле число не менше нуля або порожній рядок
function intOrEmpty(v) {
  const n = clean(v);
  return n === "" || Number.isNaN(Number(n)) ? "" : Math.max(0, Math.trunc(Number(n)));
}

export function composeAddress(c) {
  const street = clean(c.street), house = clean(c.house), flat = clean(c.flat);
  const parts = [clean(c.city), street, house, flat ? `кв. ${flat}` : "", clean(c.landmark)];
  return parts.filter(Boolean).join(", ");
}

export function toWire(ui) {
  const out = {
    incident_type: INCIDENT_TO_WIRE[ui.incident_type] || "",
    address: composeAddress(ui),
    victims: intOrEmpty(ui.victims),
    explosion: EXPLOSION_TO_WIRE[ui.explosion] || "",
    floors: intOrEmpty(ui.floors),
    access: clean(ui.access),
    caller_name: clean(ui.caller_name),
    phone: clean(ui.phone),
    notes: clean(ui.notes),
  };
  for (const k of ["city", "street", "house", "flat", "landmark"]) out[`ui_${k}`] = clean(ui[k]);
  return out;
}

export function fromWire(card) {
  const w = card || {};
  const hasUi = ["city", "street", "house", "flat", "landmark"].some((k) => w[`ui_${k}`] !== undefined);
  const ui = {
    incident_type: FROM_WIRE[w.incident_type] || "",
    victims: w.victims === undefined || w.victims === null ? "" : String(w.victims),
    explosion: EXPLOSION_FROM_WIRE[w.explosion] || "Невідомо",
    floors: w.floors === undefined || w.floors === null ? "" : String(w.floors),
    access: w.access || "",
    caller_name: w.caller_name || "",
    phone: w.phone || "",
    notes: w.notes || "",
  };
  for (const k of ["city", "street", "house", "flat", "landmark"]) ui[k] = hasUi ? (w[`ui_${k}`] || "") : "";
  if (!hasUi && w.address) ui.city = w.address;
  return ui;
}
