// Браузерна версія: той самий Python-бекенд (агенти, оркестратор, SQLite) працює в Pyodide.
// Перехоплює fetch("/api/...") і WebSocket("/ws/...") і віддає їх у bridge.py. Сервер не потрібен.
(function () {
  const PYODIDE = "https://cdn.jsdelivr.net/pyodide/v0.27.2/full/";
  const DB = "/t112/data/trainer.db";
  const FILES = window.__T112_FILES || {};
  const realFetch = window.fetch.bind(window);

  // ── екран завантаження ─────────────────────────────────
  const boot = document.createElement("div");
  boot.className = "boot";
  boot.setAttribute("role", "status");
  boot.innerHTML = '<div class="boot-card"><span class="brand-badge">101</span><b>Тренажер оператора ПЗЧ</b>' +
    '<div class="boot-bar"><i></i></div><span class="boot-msg">Завантажую рушій симуляції…</span>' +
    '<span class="boot-note">Перший запуск потребує інтернету (≈15 МБ), далі браузер бере з кешу.</span></div>';
  document.addEventListener("DOMContentLoaded", () => document.body.append(boot));
  const step = (msg, p) => {
    const m = boot.querySelector(".boot-msg"); if (m) m.textContent = msg;
    const i = boot.querySelector(".boot-bar i"); if (i) i.style.transform = `scaleX(${p})`;
  };

  // ── збереження бази між відкриттями (IndexedDB) ─────────
  const idb = () => new Promise((res, rej) => {
    const r = indexedDB.open("trainer112", 1);
    r.onupgradeneeded = () => r.result.createObjectStore("kv");
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  });
  const idbGet = async (k) => { try { const d = await idb(); return await new Promise((res) => { const q = d.transaction("kv").objectStore("kv").get(k); q.onsuccess = () => res(q.result); q.onerror = () => res(null); }); } catch { return null; } };
  const idbPut = async (k, v) => { try { const d = await idb(); d.transaction("kv", "readwrite").objectStore("kv").put(v, k); } catch { /* приватний режим */ } };

  let py = null, bridge = null, dirty = false;
  const loadScript = (src) => new Promise((res, rej) => { const s = document.createElement("script"); s.src = src; s.onload = res; s.onerror = () => rej(new Error("Не вдалося завантажити " + src)); document.head.append(s); });

  const ready = (async () => {
    step("Завантажую рушій Python…", 0.1);
    await loadScript(PYODIDE + "pyodide.js");
    py = await window.loadPyodide({ indexURL: PYODIDE });
    step("Підключаю pydantic, YAML і SQLite…", 0.45);
    await py.loadPackage(["pydantic", "pyyaml", "sqlite3"]);
    step("Розгортаю агентів і сценарії…", 0.75);
    for (const [path, text] of Object.entries(FILES)) {
      const full = "/t112/" + path;
      py.FS.mkdirTree(full.slice(0, full.lastIndexOf("/")));
      py.FS.writeFile(full, text);
    }
    py.FS.mkdirTree("/t112/data");
    const saved = await idbGet("db");
    if (saved) py.FS.writeFile(DB, saved);
    py.runPython("import sys, os\nsys.path[:0] = ['/t112/standalone/py', '/t112/backend']\nos.environ['TRAINER_DATA'] = '/t112/data'");
    step("Запускаю оркестратор…", 0.9);
    await py.runPythonAsync("import bridge");
    bridge = py.pyimport("bridge");
    step("Готово", 1);
    boot.classList.add("leaving"); setTimeout(() => boot.remove(), 200);
    setInterval(() => { if (dirty) { dirty = false; try { idbPut("db", py.FS.readFile(DB)); } catch { /* */ } } }, 3000);
    window.addEventListener("pagehide", () => { try { idbPut("db", py.FS.readFile(DB)); } catch { /* */ } });
  })().catch((e) => {
    console.error(e);
    step("Не вдалося запустити: " + (e.message || e) + ". Перевірте інтернет і відкрийте файл ще раз.", 0);
    boot.classList.add("failed");
    throw e;
  });

  // ── fetch("/api/...") ─────────────────────────────────
  const apiPath = (url) => { const s = String(url && url.url ? url.url : url); return s.startsWith("/api/") ? s : null; };
  async function callApi(url, opts = {}) {
    await ready;
    const u = new URL(url, "http://local/");
    const r = JSON.parse(await bridge.http((opts.method || "GET").toUpperCase(), u.pathname, u.search.slice(1), opts.body || ""));
    if ((opts.method || "GET").toUpperCase() !== "GET") dirty = true;
    const body = r.type === "json" ? JSON.stringify(r.body) : r.body;
    return new Response(body, { status: r.status, headers: { "Content-Type": r.type === "json" ? "application/json" : (r.media || "text/plain") } });
  }
  // ── Голос Gemini без сервера ──────────────────────────
  // Ключ вводить користувач (кнопка «Голос Gemini»); він лежить лише в localStorage цього браузера, у файл не вшивається.
  const KEY_STORE = "trainer112.geminiKey";
  const getKey = () => { try { return localStorage.getItem(KEY_STORE) || ""; } catch { return ""; } };
  const TTS_MODEL = "gemini-3.8-flash-tts";
  const STYLE = {
    "спокійно": "in a tired, worried but calm voice",
    "напружено": "in a tense, anxious voice, slightly fast, like a frightened person on the phone",
    "плач": "in a trembling, tearful voice, sobbing between phrases",
    "крик": "in a panicked, breathless, loud voice, almost screaming",
  };
  const pickVoice = (spec) => {
    const m = /^(male|female)(?:_(\d+))?/.exec(spec || "");
    const sex = m ? m[1] : "female", age = m && m[2] ? +m[2] : 40;
    if (sex === "male") return age < 25 ? "Puck" : age < 55 ? "Orus" : "Charon";
    return age < 30 ? "Leda" : age < 55 ? "Kore" : "Aoede";
  };
  const b64ToBytes = (b64) => Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
  const pcmToWav = (pcm, rate = 24000) => {
    const h = new DataView(new ArrayBuffer(44)), w = (o, s) => { for (let i = 0; i < s.length; i++) h.setUint8(o + i, s.charCodeAt(i)); };
    w(0, "RIFF"); h.setUint32(4, 36 + pcm.length, true); w(8, "WAVEfmt "); h.setUint32(16, 16, true); h.setUint16(20, 1, true);
    h.setUint16(22, 1, true); h.setUint32(24, rate, true); h.setUint32(28, rate * 2, true); h.setUint16(32, 2, true); h.setUint16(34, 16, true);
    w(36, "data"); h.setUint32(40, pcm.length, true);
    return new Blob([h, pcm], { type: "audio/wav" });
  };
  const ttsCache = new Map();
  async function geminiTts(body) {
    const text = String(body.text || "").replace(/\([^)]*\)/g, "").trim().slice(0, 600);
    if (!text) return new Response("порожній текст", { status: 422 });
    const voice = pickVoice(body.voice), ck = voice + "|" + body.emotion + "|" + text;
    if (ttsCache.has(ck)) return new Response(ttsCache.get(ck), { status: 200, headers: { "Content-Type": "audio/wav" } });
    const r = await realFetch(`https://generativelanguage.googleapis.com/v1beta/models/${TTS_MODEL}:generateContent`, {
      method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": getKey() },
      body: JSON.stringify({
        contents: [{ parts: [{ text: `Say ${STYLE[body.emotion] || STYLE["напружено"]}: ${text}` }] }],
        generationConfig: { responseModalities: ["AUDIO"], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } } } },
      }),
    });
    if (!r.ok) return new Response("TTS недоступний", { status: 502 });
    const part = (await r.json()).candidates[0].content.parts[0].inlineData;
    const bytes = b64ToBytes(part.data);
    const blob = /wav/i.test(part.mimeType || "") || String.fromCharCode(...bytes.slice(0, 4)) === "RIFF"
      ? new Blob([bytes], { type: "audio/wav" })
      : pcmToWav(bytes, +((/rate=(\d+)/.exec(part.mimeType || "") || [])[1] || 24000));
    ttsCache.set(ck, blob);
    return new Response(blob, { status: 200, headers: { "Content-Type": "audio/wav" } });
  }
  const json = (o) => new Response(JSON.stringify(o), { status: 200, headers: { "Content-Type": "application/json" } });
  const voiceBtn = document.createElement("button");
  voiceBtn.type = "button";
  voiceBtn.style.cssText = "position:fixed;left:12px;bottom:12px;z-index:90;padding:6px 12px;border-radius:999px;border:1px solid var(--border,#ccc);background:var(--surface,#fff);color:var(--text,#111);font:inherit;font-size:13px;cursor:pointer;opacity:.9";
  const paintBtn = () => { voiceBtn.textContent = getKey() ? "🔊 Голос Gemini: увімкнено" : "🔈 Голос Gemini: вимкнено"; };
  voiceBtn.onclick = () => {
    const k = window.prompt("Ключ Gemini API для озвучки (зберігається лише в цьому браузері). Порожнє поле вимкне голос Gemini:", getKey());
    if (k === null) return;
    try { k.trim() ? localStorage.setItem(KEY_STORE, k.trim()) : localStorage.removeItem(KEY_STORE); } catch { /* */ }
    paintBtn();
    window.alert("Готово. Оновіть сторінку (F5), щоб голос Gemini почав працювати.");
  };
  paintBtn();
  if (document.body) document.body.appendChild(voiceBtn);
  else document.addEventListener("DOMContentLoaded", () => document.body.appendChild(voiceBtn));

  window.fetch = (url, opts) => {
    const p = apiPath(url);
    if (p === "/api/config") return Promise.resolve(json({ tts: !!getKey(), llm: false }));
    if (p === "/api/tts") { let b = {}; try { b = JSON.parse((opts && opts.body) || "{}"); } catch { /* */ } return geminiTts(b); }
    return p ? callApi(p, opts) : realFetch(url, opts);
  };

  // посилання на /api/... (експорт CSV, JSON-схема)
  document.addEventListener("click", async (e) => {
    const a = e.target.closest && e.target.closest('a[href^="/api/"]');
    if (!a) return;
    e.preventDefault();
    const res = await callApi(a.getAttribute("href"));
    const blob = new Blob([await res.text()], { type: res.headers.get("Content-Type") || "text/plain" });
    const href = URL.createObjectURL(blob);
    if (a.hasAttribute("download")) { const d = document.createElement("a"); d.href = href; d.download = a.getAttribute("download") || "export"; d.click(); }
    else window.open(href, "_blank");
    setTimeout(() => URL.revokeObjectURL(href), 60000);
  });

  // ── WebSocket("/ws/...") ──────────────────────────────
  class LocalSocket {
    constructor(url) {
      this.url = url; this.readyState = 0; this.conn = null;
      this.onopen = this.onmessage = this.onclose = this.onerror = null;
      const path = String(url).replace(/^wss?:\/\/[^/]*/, "");
      const [p, q = ""] = path.split("?");
      ready.then(() => {
        if (this.readyState === 3) return;
        this.conn = bridge.ws_open(p, q,
          (text) => { if (this.readyState === 1) { dirty = true; this.onmessage && this.onmessage({ data: text }); } },
          () => this._closed());
        if (!this.conn) return;
        this.readyState = 1;
        this.onopen && this.onopen({});
      }, () => this._closed());
    }
    send(text) { if (this.readyState === 1 && this.conn) this.conn.push(String(text)); }
    close() { if (this.readyState >= 2) return; if (this.conn) this.conn.disconnect(); this._closed(); }
    _closed() { if (this.readyState === 3) return; this.readyState = 3; setTimeout(() => this.onclose && this.onclose({ code: 1000 }), 0); }
  }
  LocalSocket.CONNECTING = 0; LocalSocket.OPEN = 1; LocalSocket.CLOSING = 2; LocalSocket.CLOSED = 3;
  window.WebSocket = LocalSocket;
})();
