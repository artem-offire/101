class PlainTextResponse:
    def __init__(self, content: str = "", media_type: str = "text/plain", **_):
        self.content, self.media_type = content, media_type


class FileResponse:
    def __init__(self, path, **_):
        self.path = path
