"""Мінімальна заміна FastAPI для браузерної версії (Pyodide).

Реєструє маршрути з app/main.py без змін у ньому; виклик іде з JS через bridge.py.
"""
from __future__ import annotations

import inspect
import re
from typing import Any, Callable


class HTTPException(Exception):
    def __init__(self, status_code: int = 500, detail: Any = None) -> None:
        super().__init__(detail)
        self.status_code = status_code
        self.detail = detail


class WebSocketDisconnect(Exception):
    pass


def Body(default: Any = None, **_: Any) -> Any:  # noqa: N802
    return default


def Query(default: Any = None, **_: Any) -> Any:  # noqa: N802
    return default


class WebSocket:
    """Сокет, що з'єднує корутину маршруту з об'єктом FakeWebSocket у JS."""

    def __init__(self, send: Callable[[str], None], close: Callable[[], None]) -> None:
        import asyncio
        self._send, self._close = send, close
        self.inbox: asyncio.Queue = asyncio.Queue()
        self.closed = False

    async def accept(self) -> None:
        return None

    async def send_json(self, data: Any) -> None:
        import json
        if self.closed:
            raise WebSocketDisconnect()
        self._send(json.dumps(data, ensure_ascii=False, default=str))

    async def receive_json(self) -> Any:
        import json
        msg = await self.inbox.get()
        if msg is None:
            raise WebSocketDisconnect()
        return json.loads(msg)

    async def close(self) -> None:
        if not self.closed:
            self.closed = True
            self._close()


class Route:
    def __init__(self, method: str, path: str, fn: Callable) -> None:
        self.method, self.path, self.fn = method, path, fn
        self.rx = re.compile("^" + re.sub(r"\{(\w+)\}", r"(?P<\1>[^/]+)", path) + "$")
        self.sig = inspect.signature(fn)


class FastAPI:
    def __init__(self, **_: Any) -> None:
        self.routes: list[Route] = []

    def _reg(self, method: str, path: str):
        def deco(fn: Callable) -> Callable:
            self.routes.append(Route(method, path, fn))
            return fn
        return deco

    def get(self, path: str, **_: Any):
        return self._reg("GET", path)

    def post(self, path: str, **_: Any):
        return self._reg("POST", path)

    def websocket(self, path: str):
        return self._reg("WS", path)

    def mount(self, *_: Any, **__: Any) -> None:
        return None

    def match(self, method: str, path: str):
        for r in self.routes:
            if r.method != method:
                continue
            m = r.rx.match(path)
            if m:
                return r, m.groupdict()
        return None, None
