class StaticFiles:
    def __init__(self, **_):
        pass
