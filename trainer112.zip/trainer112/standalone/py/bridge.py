"""Міст JS ↔ app.main для браузерної версії: HTTP-запити і веб-сокети без мережі."""
from __future__ import annotations

import asyncio
import json
import typing
from urllib.parse import parse_qsl

from fastapi import HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import PlainTextResponse

from app import main

APP = main.app


def _cast(val: str, ann) -> typing.Any:
    t = str(ann)
    if "bool" in t:
        return val.lower() in ("1", "true", "yes")
    if "int" in t:
        try:
            return int(float(val))
        except ValueError:
            return None
    return val


def _kwargs(route, params: dict, query: str, body):
    q = dict(parse_qsl(query or ""))
    hints = typing.get_type_hints(route.fn)
    kw = {}
    for name in route.sig.parameters:
        if name in params:
            kw[name] = _cast(params[name], hints.get(name, str))
        elif name == "body":
            kw[name] = body if body is not None else {}
        elif name in q:
            kw[name] = _cast(q[name], hints.get(name, str))
    return kw


async def http(method: str, path: str, query: str, body_json: str) -> str:
    route, params = APP.match(method, path)
    if not route:
        return json.dumps({"status": 404, "type": "json", "body": {"detail": "Not Found"}})
    body = json.loads(body_json) if body_json else None
    try:
        res = route.fn(**_kwargs(route, params, query, body))
        if asyncio.iscoroutine(res):
            res = await res
    except HTTPException as e:
        return json.dumps({"status": e.status_code, "type": "json", "body": {"detail": e.detail}}, ensure_ascii=False)
    except Exception as e:  # noqa: BLE001
        import traceback
        traceback.print_exc()
        return json.dumps({"status": 500, "type": "json", "body": {"detail": str(e)}}, ensure_ascii=False)
    if isinstance(res, PlainTextResponse):
        return json.dumps({"status": 200, "type": "text", "media": res.media_type, "body": res.content}, ensure_ascii=False)
    return json.dumps({"status": 200, "type": "json", "body": res}, ensure_ascii=False, default=str)


class Conn:
    def __init__(self, ws: WebSocket, task: asyncio.Task) -> None:
        self.ws, self.task = ws, task

    def push(self, text: str) -> None:
        self.ws.inbox.put_nowait(text)

    def disconnect(self) -> None:
        self.ws.closed = True
        self.ws.inbox.put_nowait(None)


def ws_open(path: str, query: str, send, close):
    route, params = APP.match("WS", path)
    ws = WebSocket(send, close)
    if not route:
        close()
        return None
    kw = _kwargs(route, params, query, None)

    async def run():
        try:
            await route.fn(ws, **kw)
        except WebSocketDisconnect:
            pass
        except Exception:  # noqa: BLE001
            import traceback
            traceback.print_exc()
        finally:
            await ws.close()

    return Conn(ws, asyncio.ensure_future(run()))
