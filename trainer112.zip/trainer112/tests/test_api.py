"""Наскрізний тест API: вхід, старт дзвінка, WebSocket-цикл, ролі, звіт, калібрування, призначення."""
import os
import tempfile

os.environ["TRAINER_DATA"] = tempfile.mkdtemp()

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402


def recv_until(ws, type_, limit=200):
    seen = []
    for _ in range(limit):
        m = ws.receive_json()
        seen.append(m["type"])
        if m["type"] == type_:
            return m, seen
    raise AssertionError(f"{type_} не прийшло: {seen}")


def test_full_call_over_websocket():
    c = TestClient(app)
    assert c.post("/api/login", json={"name": "Тест", "role": "trainee"}).status_code == 200
    cid = c.post("/api/calls", json={"trainee": "Тест", "scenario_id": "gas-leak-03", "seed": 5}).json()["call_id"]
    with c.websocket_connect(f"/ws/call/{cid}?role=trainee") as ws:
        snap = ws.receive_json()
        assert snap["type"] == "call.snapshot" and "checklist" not in snap["payload"]
        ws.send_json({"type": "call.accept"})
        recv_until(ws, "tts.say")
        ws.send_json({"type": "operator.speech_start"})
        ws.send_json({"type": "operator.final", "payload": {"text": "Пожежно-рятувальна частина, оператор курсант Тест. Що сталося? Назвіть адресу.", "duration_ms": 2000}})
        m, seen = recv_until(ws, "caller.utterance")
        assert "checklist.step" not in seen and "director.directive" not in seen   # курсант не бачить оцінку
        ws.send_json({"type": "card.updated", "payload": {"fields": {"incident_type": "газ"}}})
        ws.send_json({"type": "call.end", "payload": {"reason": "operator"}})
        recv_until(ws, "report.ready")
    s = c.get(f"/api/sessions/{cid}").json()
    assert s["report"]["checklist"] and s["status"] == "done"
    step = s["report"]["checklist"][0]["step_id"]
    r = c.post(f"/api/sessions/{cid}/calibrate", json={"step_id": step, "done": False, "by": "Інструктор"}).json()
    assert r["ok"]
    assert c.get("/api/calibration").json()["n"] == 1
    assert c.get(f"/api/sessions/{cid}/state?t=1000").status_code == 200
    assert c.post("/api/assignments", json={"trainee": "Тест", "scenario_id": "drowning-01"}).status_code == 200
    assert c.get("/api/assignments?trainee=Тест").json()
    assert "hot" in c.get("/api/metrics").json()
    assert c.get("/api/sessions.csv").status_code == 200


def test_instructor_sees_everything_and_commands():
    with TestClient(app) as c:   # один event loop для обох з'єднань
        cid = c.post("/api/calls", json={"trainee": "Т2", "scenario_id": "house-fire-01", "seed": 3}).json()["call_id"]
        with c.websocket_connect(f"/ws/call/{cid}?role=trainee") as tw, c.websocket_connect(f"/ws/call/{cid}?role=instructor&name=I") as iw:
            tw.receive_json()
            snap = iw.receive_json()
            assert "steps" in snap["payload"] and "legend" in snap["payload"]
            tw.send_json({"type": "call.accept"})
            recv_until(iw, "tts.say")
            iw.send_json({"type": "instructor.command", "payload": {"cmd": "harder"}})
            m, _ = recv_until(iw, "scene.event")
            assert m["payload"]["by"] == "instructor"
            iw.send_json({"type": "call.end"})
            recv_until(iw, "report.ready")


def test_validate_and_botcheck():
    c = TestClient(app)
    r = c.post("/api/scenarios/validate", json={"yaml": "id: x\ntitle: y"}).json()
    assert not r["ok"] and r["errors"]
    r = c.post("/api/scenarios/gas-leak-03/botcheck").json()
    assert r["ok"], r


def test_random_call_hides_scenario():
    with TestClient(app) as c:
        cid = c.post("/api/calls", json={"trainee": "Т", "scenario_id": "random"}).json()["call_id"]
        with c.websocket_connect(f"/ws/call/{cid}?role=trainee") as ws:
            snap = ws.receive_json()["payload"]
            for k in ("scenario_title", "scenario_brief", "category", "scenario"):
                assert k not in snap, k
            rows = c.get("/api/sessions?trainee=Т").json()
            assert [x for x in rows if x["id"] == cid][0]["scenario_id"] == "random"
            ws.send_json({"type": "call.accept"})
            recv_until(ws, "tts.say")
            ws.send_json({"type": "call.end", "payload": {"reason": "operator"}})
            recv_until(ws, "report.ready")
    s = c.get(f"/api/sessions/{cid}").json()
    assert s["report"]["scenario_title"]
    assert s["scenario_id"] != "random"


def test_action_alarm_marks_step():
    with TestClient(app) as c:
        cid = c.post("/api/calls", json={"trainee": "Т3", "scenario_id": "house-fire-01", "seed": 2}).json()["call_id"]
        with c.websocket_connect(f"/ws/call/{cid}?role=trainee") as ws:
            ws.receive_json()
            ws.send_json({"type": "call.accept"})
            recv_until(ws, "tts.say")
            ws.send_json({"type": "operator.action", "payload": {"action": "alarm"}})
            ws.send_json({"type": "call.end", "payload": {"reason": "operator"}})
            recv_until(ws, "report.ready")
    s = c.get(f"/api/sessions/{cid}").json()
    step = [x for x in s["report"]["checklist"] if x["step_id"] == "alarm"][0]
    assert step["done"] is True
    assert step["quote"].startswith("Дія:")
