"""Браузерна версія: міст bridge.py поверх підмінного fastapi обслуговує ті самі маршрути.

Запускається в окремому процесі, бо підмінний пакет fastapi не має змішуватися зі справжнім.
"""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

SCRIPT = r"""
import asyncio, json, os, sys, tempfile
sys.path[:0] = [sys.argv[1] + '/standalone/py', sys.argv[1] + '/backend']
os.environ['TRAINER_DATA'] = tempfile.mkdtemp()
import bridge

async def main():
    out = {}
    out['scenarios'] = json.loads(await bridge.http('GET', '/api/scenarios', '', ''))
    out['login'] = json.loads(await bridge.http('POST', '/api/login', '', json.dumps({'name': 'Т', 'role': 'trainee'})))
    out['missing'] = json.loads(await bridge.http('GET', '/api/sessions/nope', '', ''))
    out['csv'] = json.loads(await bridge.http('GET', '/api/sessions.csv', '', ''))
    call = json.loads(await bridge.http('POST', '/api/calls', '', json.dumps({'trainee': 'Т', 'scenario_id': 'gas-leak-03'})))
    got = []
    conn = bridge.ws_open('/ws/call/' + call['body']['call_id'], 'role=trainee&name=T', got.append, lambda: None)
    await asyncio.sleep(0.05)
    conn.push(json.dumps({'type': 'call.accept', 'payload': {}}))
    await asyncio.sleep(0.5)
    conn.disconnect()
    await asyncio.sleep(0.05)
    out['ws_types'] = [json.loads(m)['type'] for m in got]
    print(json.dumps(out, ensure_ascii=False))

asyncio.run(main())
"""


def test_bridge_routes_and_socket():
    r = subprocess.run([sys.executable, "-c", SCRIPT, str(ROOT)], capture_output=True, text=True, timeout=60)
    assert r.returncode == 0, r.stderr
    out = json.loads(r.stdout.strip().splitlines()[-1])
    assert out["scenarios"]["status"] == 200 and len(out["scenarios"]["body"]) >= 10
    assert out["login"]["body"] == {"name": "Т", "role": "trainee"}
    assert out["missing"]["status"] == 404
    assert out["csv"]["type"] == "text" and "курсант" in out["csv"]["body"]
    assert out["ws_types"][0] == "call.snapshot"
    assert "caller.utterance" in out["ws_types"] or "tts.say" in out["ws_types"]
