"""Gemini: перетворення повідомлень, вибір голосу, WAV. Без мережі і без ключа."""
import wave
import io

from app.agents.llm import _gemini_payload, _gemini_text, LLMClient
from app import tts


def test_payload_merges_roles_and_system():
    msgs = [{"role": "system", "content": "Ти заявник"}, {"role": "user", "content": "Алло"},
            {"role": "user", "content": "Що сталося?"}, {"role": "assistant", "content": "[напружено] Горить!"}]
    b = _gemini_payload(msgs, 100, 0.5, json_mode=True)
    assert b["systemInstruction"]["parts"][0]["text"] == "Ти заявник"
    assert [c["role"] for c in b["contents"]] == ["user", "model"]
    assert "Що сталося?" in b["contents"][0]["parts"][0]["text"]
    assert b["generationConfig"]["responseMimeType"] == "application/json"


def test_payload_starts_with_user():
    b = _gemini_payload([{"role": "assistant", "content": "x"}], 50, 0.1)
    assert b["contents"][0]["role"] == "user"


def test_text_skips_thoughts():
    d = {"candidates": [{"content": {"parts": [{"text": "думка", "thought": True}, {"text": "Алло!"}]}}]}
    assert _gemini_text(d) == "Алло!"


def test_client_enabled_by_key(monkeypatch):
    monkeypatch.delenv("LLM_BASE_URL", raising=False)
    monkeypatch.setenv("GEMINI_API_KEY", "k")
    c = LLMClient("caller")
    assert c.enabled and c.is_gemini
    monkeypatch.delenv("GEMINI_API_KEY")
    assert not LLMClient("caller").enabled


def test_pick_voice():
    assert tts.pick_voice("male_14") == "Puck"
    assert tts.pick_voice("female_60_tremble") == "Aoede"
    assert tts.pick_voice("female_40") == "Kore"
    assert tts.pick_voice("щось") == "Kore"


def test_pcm_to_wav():
    w = wave.open(io.BytesIO(tts.pcm_to_wav(b"\x00\x00" * 2400)))
    assert (w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()) == (1, 2, 24000, 2400)
    assert tts._audio_to_wav("audio/wav", b"RIFFxxxx") == b"RIFFxxxx"
