import os
import sys
from pathlib import Path

# тести детерміновані: порожнє значення не дає main._load_env() підхопити ключ із .env
for _k in ("GEMINI_API_KEY", "LLM_BASE_URL", "LLM_MODEL"):
    os.environ[_k] = ""

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
