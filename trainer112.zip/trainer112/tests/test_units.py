"""Модульні тести: схема сценаріїв, нормалізатор, Сторож, власники полів, реплей."""
import copy

import pytest
import yaml

from app.agents.caller import Sentence
from app.agents.guard import Guard
from app.agents.evaluator import compare_card
from app.agents.normalizer import Normalizer, extract, words_to_numbers
from app.models import CallState, Event, OwnershipError
from app.nlu import intents
from app.scenarios import SCENARIO_DIR, Library, ScenarioError, parse_scenario, prepare


def test_library_has_10_valid_scenarios():
    lib = Library()
    assert lib.errors == {}
    assert len(lib.items) >= 10


def test_schema_rejects_bad_references():
    data = yaml.safe_load((SCENARIO_DIR / "gas-leak-03.yaml").read_text(encoding="utf-8"))
    bad = copy.deepcopy(data)
    bad["facts"][0]["reveal"] = {"asked": ["unknown_intent"]}
    with pytest.raises(ScenarioError):
        parse_scenario(bad)
    bad = copy.deepcopy(data)
    bad["events"][0]["trigger"]["unless_step"] = "no_such_step"
    with pytest.raises(ScenarioError) as e:
        parse_scenario(bad)
    assert any("no_such_step" in x for x in e.value.errors)


def test_seed_is_reproducible():
    sc = Library().get("gas-leak-03")
    a, b = prepare(sc, 4172), prepare(sc, 4172)
    assert (a.branch, a.initial) == (b.branch, b.initial)


@pytest.mark.parametrize("text,exp", [
    ("Київська, сімнадцять... ні, сімнадцять а!", {"street": "Київська", "house": "17а"}),
    ("траса М-06, сорок п'ятий кілометр", {"highway": "М-06", "km": "45"}),
    ("Бровари, вулиця Садова, двадцять три", {"street": "Садова", "settlement": "Бровари", "house": "23"}),
])
def test_normalizer_addresses(text, exp):
    got = extract(text)["address"]
    for k, v in exp.items():
        assert got[k] == v


def test_normalizer_phone_and_confirm():
    assert extract("мій номер 067 123 45 67")["phone"] == "0671234567"
    n, e = Normalizer(), {}
    e.update(n.run("Київська, сімнадцять а!", "caller", e))
    assert n.run("Київська 17а, правильно?", "operator", e)["address"]["confirmed"] is True
    assert n.run("Київська 15, правильно?", "operator", e)["address"]["confirmed"] is False
    assert words_to_numbers("сорок п'ять") == "45"


def test_intents_require_question():
    assert "address" in intents("Яка ваша адреса?")
    assert "address" not in intents("Виходьте з квартири.")


def test_every_protocol_step_has_source():
    from app.scenarios import resolve_steps
    lib = Library()
    assert lib.errors == {}
    for sid, sc in lib.items.items():
        for s in resolve_steps(sc.protocol):
            assert s.source, (sid, s.id)
            assert s.basis in ("норма", "методична", "потребує підтвердження"), (sid, s.id, s.basis)


def test_nlu_floors_vs_people():
    got = intents("Скільки поверхів у будівлі?")
    assert "floors" in got and "people" not in got and "address" not in got
    assert "people" in intents("Скільки людей у квартирі?")


def test_nlu_access_and_danger():
    assert "access" in intents("Чи може пожежна машина під'їхати до будинку?")
    assert "access" in intents("Там є шлагбаум або ворота?")
    assert "danger" in intents("Чи є поруч газовий балон?")
    assert "danger" in intents("Чи є загроза вибуху?")


def test_nlu_greeting_of_fire_unit():
    assert "greeting" in intents("Пожежно-рятувальна частина, черговий слухає. Що сталося?")


def test_compare_card_modes():
    truth = {"phone": "0631112233", "floors": 9, "access": ["шлагбаум", "ворота"]}
    card = {"phone": "+38 (063) 111-22-33", "floors": "9", "access": "шлагбаум на в'їзді"}
    res = {r["field"]: r["ok"] for r in compare_card(card, truth)}
    assert res == {"floors": True, "access": True, "phone": True}
    bad = {"phone": "0631112200", "floors": "8", "access": "гараж"}
    res = {r["field"]: r["ok"] for r in compare_card(bad, truth)}
    assert res == {"floors": False, "access": False, "phone": False}


def test_normalizer_lviv_addresses():
    assert extract("Сихівська, шістнадцять")["address"] == {"street": "Сихівська", "house": "16"}
    got = extract("Брюховичі, вулиця Польова, п'ятнадцять")["address"]
    assert got["settlement"] == "Брюховичі" and got["house"] == "15"


def test_archive_scenarios_are_not_loaded():
    lib = Library()
    for sid in ("cardiac-arrest-01", "child-choking-01", "domestic-violence-01"):
        assert sid not in lib.items
        assert (SCENARIO_DIR / "archive" / f"{sid}.yaml").exists()


def test_guard_blocks_out_of_role_and_invented_facts():
    prep = prepare(Library().get("gas-leak-03"), 1)
    g, st = Guard(prep), CallState(call_id="x")
    st.facts["pending"] = list(prep.facts)
    ok = lambda text, facts=(): g.check(Sentence(text, "напружено", list(facts)), st, "Яка адреса?")
    assert ok("Київська вулиця!", ["street"])[0]
    assert ok("Я лише мовна модель і не можу")[1] == "out_of_role_ai"
    assert ok("Вам варто запитати адресу за протоколом")[1] == "protocol_hint"
    assert ok("Будинок 99")[1] == "invented_number"
    assert ok("OK, sure")[1] == "latin"
    assert ok("Онук у кімнаті", ["people_inside"])[1] == "fact_not_allowed"


def test_ownership_enforced():
    st = CallState(call_id="x")
    with pytest.raises(OwnershipError):
        st.apply(Event(call_id="x", t=0, type="checklist.step", source="caller", payload={"step_id": "a", "done": True, "t": 0, "quote": ""}))
    with pytest.raises(OwnershipError):
        st.apply(Event(call_id="x", t=0, type="caller.emotion", source="evaluator", payload={"panic": 1}))


def test_replay_rebuilds_state_until_t():
    evs = [
        Event(call_id="x", t=0, type="caller.utterance", source="guard", payload={"uid": "c1", "text": "Алло"}),
        Event(call_id="x", t=1000, type="caller.emotion", source="director", payload={"panic": 8, "trust": 3}),
        Event(call_id="x", t=5000, type="operator.final", source="bot", payload={"uid": "o1", "text": "112"}),
    ]
    st = CallState.replay("x", evs, until_t=2000)
    assert len(st.transcript) == 1 and st.caller.panic == 8
    assert len(CallState.replay("x", evs).transcript) == 2
