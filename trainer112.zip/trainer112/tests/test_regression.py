"""Регресійні тести (крок 7): бот-курсант проходить КОЖЕН сценарій КОЖНОЮ гілкою.

Очікування з розділу 7: ідеальний ≥ 90% і зараховано; «забуває адресу» валить критичний крок;
грубий втрачає довіру абонента; повільний отримує запізнення. Запускаються на кожну зміну
сценарію, промпту або моделі.
"""
import asyncio
import statistics

import pytest

from app.bot import run_bot_call
from app.metrics import Metrics
from app.service import Trainer

TR = None


def trainer():
    global TR
    if TR is None:
        TR = Trainer(db_path=":memory:")
    return TR


CASES = [(sid, b.id) for sid, sc in sorted(trainer().library.items.items()) for b in sc.branches]


async def run(sid, branch, style, seed=7):
    o = await trainer().start_call("bot", sid, seed=seed, branch=branch, sim=True)
    return o, await run_bot_call(o, style)


@pytest.mark.parametrize("sid,branch", CASES)
async def test_ideal_operator_passes(sid, branch):
    _, rep = await run(sid, branch, "ideal")
    assert rep["passed"], rep["missed_critical"]
    assert rep["score"] >= 90
    assert rep["guard_blocked"] == 0


@pytest.mark.parametrize("sid,branch", CASES)
async def test_forgetting_address_fails_critical(sid, branch):
    _, rep = await run(sid, branch, "forgets_address")
    assert not rep["passed"]
    assert any("адрес" in m.lower() or "місце" in m.lower() for m in rep["missed_critical"])


@pytest.mark.parametrize("sid", sorted(trainer().library.items))
async def test_rude_operator_loses_trust(sid):
    _, good = await run(sid, None, "ideal")
    _, bad = await run(sid, None, "rude")
    assert bad["final_emotion"]["trust"] < good["final_emotion"]["trust"]
    assert any(r["title"] == "Тон розмови" for r in bad["recommendations"])


@pytest.mark.parametrize("sid", sorted(trainer().library.items))
async def test_slow_operator_is_late(sid):
    _, good = await run(sid, None, "ideal")
    _, slow = await run(sid, None, "slow")
    assert slow["score"] < good["score"]
    assert any(r["late"] or not r["done"] for r in slow["checklist"])


async def test_evidence_on_every_mark():
    _, rep = await run("gas-leak-03", "main", "ideal")
    for r in rep["checklist"]:
        if r["done"]:
            assert r["quote"] and r["t"] is not None


async def test_replay_from_moment():
    o, rep = await run("gas-leak-03", "main", "forgets_address")
    t = rep["replay_t"]
    assert t is not None
    o2 = await trainer().start_call("bot", "gas-leak-03", from_session=o.call_id, from_t=t, sim=True)
    assert o2.state.transcript and all(u.t <= t for u in o2.state.transcript)
    assert o2.prep.seed == o.prep.seed and o2.prep.branch == o.prep.branch
    rep2 = await run_bot_call(o2, "ideal")
    assert rep2["score"] > rep["score"]


async def test_load_15_parallel_calls():
    """Навантажувальний тест: 15 одночасних бот-дзвінків (розмір групи пілоту)."""
    import app.orchestrator as orch_mod
    m = Metrics()
    tr = trainer()
    sids = sorted(tr.library.items)
    orchs = []
    for i in range(15):
        o = await tr.start_call("bot", sids[i % len(sids)], seed=100 + i, sim=True)
        o.metrics = m
        orchs.append(o)
    reps = await asyncio.gather(*(run_bot_call(o, "ideal") for o in orchs))
    assert all(r["passed"] for r in reps)
    p90 = statistics.quantiles(list(m.hot_latency), n=10)[-1]
    assert p90 < 1200, p90   # бюджет гарячого контуру (без моделей — запас для ASR/LLM/TTS)
