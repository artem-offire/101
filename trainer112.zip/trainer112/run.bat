@echo off
cd /d %~dp0
python -m pip install -q -r requirements.txt
cd backend
python -m uvicorn app.main:app --host 0.0.0.0 --port 8112
