"""Бот-курсант (крок 7, E9-06): грає оператора за стилем і проганяє дзвінок у віртуальному часі.

Стилі:
  ideal            — виконує протокол за прикладами методиста, вчасно;
  forgets_address  — ніколи не питає і не підтверджує адресу (має валити критичний крок);
  rude             — грубить, повторює питання, не заспокоює;
  slow             — усе робить правильно, але з довгими паузами (запізнення).
Кроки-дії (`rule.action`) бот виконує натисканням кнопки, кроки за карткою (`rule.card_fields`) —
надсиланням картки. Очікування задаються в tests/test_regression.py і використовуються для автоперевірки сценаріїв.
"""
from __future__ import annotations

from typing import Any, Optional

from .models import CallState
from .orchestrator import CallOrchestrator, SimClock
from .nlu import words

STYLES = {
    "ideal": {"think_ms": 1500, "skip_tags": set(), "rude": False, "card": True, "reassure_early": True},
    "forgets_address": {"think_ms": 1800, "skip_tags": {"address"}, "rude": False, "card": True,
                        "reassure_early": True},
    "rude": {"think_ms": 1200, "skip_tags": set(), "rude": True, "card": False, "reassure_early": False},
    "slow": {"think_ms": 9000, "skip_tags": set(), "rude": False, "card": True, "reassure_early": False},
}
STYLE_TITLES = {"ideal": "Ідеальний", "forgets_address": "Забуває адресу", "rude": "Грубий", "slow": "Повільний"}


def address_phrase(st: CallState) -> Optional[str]:
    h = st.entities.get("address_heard") or {}
    parts = []
    if h.get("settlement"):
        parts.append(h["settlement"])
    if h.get("highway"):
        parts.append(f"траса {h['highway']}")
    if h.get("km"):
        parts.append(f"{h['km']} кілометр")
    if h.get("street"):
        parts.append(h["street"])
    if h.get("house"):
        parts.append(str(h["house"]))
    return ", ".join(parts) if parts else None


async def run_bot_call(orch: CallOrchestrator, style: str = "ideal", max_turns: int = 30) -> dict[str, Any]:
    cfg = STYLES[style]
    clock: SimClock = orch.clock  # type: ignore[assignment]
    assert isinstance(clock, SimClock)
    steps = [s for s in orch.prep.steps if not (set(s.tags) & cfg["skip_tags"])]
    steps.sort(key=lambda s: s.order)
    st = orch.state

    async def wait_and_advance(ms: int) -> None:
        await orch.wait_caller()
        # абонент говорить: віртуальний час іде
        target = max(clock.now() + ms, orch.caller_speaking_until + ms)
        while clock.now() < target and not orch.finished:
            step = min(1000, target - clock.now())
            clock.advance(step)
            await orch.tick()
            await orch.wait_caller()

    async def say(text: str) -> None:
        if orch.finished:
            return
        await orch.handle("operator.speech_start", {}, source="bot")
        dur = len(words(text)) * 380
        clock.advance(dur)
        await orch.handle("operator.final", {"text": text, "duration_ms": dur}, source="bot")
        await wait_and_advance(cfg["think_ms"])

    async def send_card() -> None:
        truth = orch.prep.scenario.card_truth
        fields: dict[str, Any] = {}
        for k, v in truth.items():
            fields[k] = " ".join(map(str, v)) if isinstance(v, list) else v
        await orch.handle("card.updated", {"fields": fields}, source="bot")

    await wait_and_advance(cfg["think_ms"])   # абонент відкриває розмову
    rude_lines = ["Та кажіть вже нормально, що сталося!", "Не верещіть, скільки можна!"]
    turns = 0
    for s in steps:
        if orch.finished or turns >= max_turns:
            break
        if st.checklist.get(s.id) and not s.rule.entity_confirmed:
            continue                      # уже виконано попередньою реплікою
        text = s.example
        if s.id == "greeting" and cfg["rude"]:
            text = "Частина. " + rude_lines[0]
        if s.rule.action:
            # дія оператора: кнопка «Подати сигнал «Тривога»», «Доповісти про виїзд»
            await orch.handle("operator.action", {"action": s.rule.action}, source="bot")
            await wait_and_advance(cfg["think_ms"])
            turns += 1
            continue
        if s.rule.card_fields:
            # запис у картку: бот заповнює картку за правдою сценарію
            if cfg["card"]:
                await send_card()
            continue
        if s.rule.entity_confirmed:
            # підтвердження адреси повтором; якщо абонент виправив — перепитати ще раз
            for _ in range(3):
                ap = address_phrase(st)
                if not ap:
                    await say("Повторіть, будь ласка, адресу: вулиця і номер будинку?")
                    turns += 1
                    continue
                await say(f"Повторюю: {ap}, правильно?")
                turns += 1
                if (st.entities.get("address") or {}).get("confirmed"):
                    break
            continue
        if s.id == "address_asked":
            await say(text)
            turns += 1
            h = st.entities.get("address_heard") or {}
            tries = 0
            while not (h.get("house") or h.get("km") or h.get("settlement")) and tries < 3 and not orch.finished:
                tries += 1
                if cfg["reassure_early"]:
                    await say("Я вас чую, допомога вже в дорозі. Спокійно, назвіть номер будинку чи орієнтир?")
                elif cfg["rude"]:
                    await say(rude_lines[1] + " Адреса яка?")
                else:
                    await say("Який номер будинку?")
                turns += 1
                h = st.entities.get("address_heard") or {}
            continue
        if "{address}" in text:
            text = text.replace("{address}", address_phrase(st) or "адреса")
        await say(text)
        turns += 1
        if cfg["rude"] and s.id == "people":
            await say(rude_lines[1])
            turns += 1
        if s.id in ("what_happened", "greeting") and cfg["reassure_early"] and st.caller.panic >= 7 \
                and s.id == "what_happened":
            await say("Я вас чую, я з вами. Допомога вже виїхала, спокійно.")
            turns += 1
    if cfg["card"] and not orch.finished:
        await send_card()
    if not orch.finished:
        await wait_and_advance(2000)
        rep = await orch.finish("operator")
    else:
        await orch.done.wait()
        rep = orch.report
    return rep or {}
