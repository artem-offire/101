"""Контракт між агентами: спільний стан дзвінка, події шини, схема сценарію.

Будь-яка зміна стану відбувається лише через подію (event sourcing). Редуктор
`CallState.apply` перевіряє, що подію надіслав власник відповідного поля
(розділ 4.1). Завдяки цьому стан можна відновити до будь-якої секунди (реплей).
"""
from __future__ import annotations

import copy
import time
import uuid
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

# ---------------------------------------------------------------------------
# Події шини (розділ 4.2)
# ---------------------------------------------------------------------------

Source = Literal[
    "orchestrator", "asr", "operator_ui", "normalizer", "caller", "guard", "tts",
    "director", "evaluator", "speech", "reporter", "instructor", "client", "bot",
]


class Event(BaseModel):
    call_id: str
    t: int                         # мс від початку дзвінка
    type: str
    source: str
    payload: dict[str, Any] = Field(default_factory=dict)
    id: str = Field(default_factory=lambda: uuid.uuid4().hex[:12])
    wall: float = Field(default_factory=time.time)


# Хто має право надсилати подію, що змінює певне поле стану
OWNERSHIP: dict[str, set[str]] = {
    "call.started": {"orchestrator"},
    "phase.changed": {"orchestrator"},
    "turn.changed": {"orchestrator"},
    "operator.final": {"asr", "operator_ui", "bot"},
    "entities.updated": {"normalizer"},
    "caller.utterance": {"guard"},          # абонент пише в transcript лише після Сторожа
    "facts.revealed": {"caller"},
    "caller.emotion": {"director"},
    "director.directive": {"director"},
    "director.state": {"director"},
    "scene.event": {"director"},
    "checklist.step": {"evaluator"},
    "speech.metric": {"speech"},
    "card.updated": {"operator_ui", "bot"},
    "operator.action": {"operator_ui", "bot"},
    "tts.stopped": {"tts", "client", "orchestrator"},
    "call.end": {"orchestrator", "operator_ui", "bot", "director", "instructor"},
}


class OwnershipError(Exception):
    pass


# ---------------------------------------------------------------------------
# Спільний стан дзвінка (розділ 4.1)
# ---------------------------------------------------------------------------

class Utterance(BaseModel):
    id: str
    t: int
    who: Literal["operator", "caller", "scene"]
    text: str
    emotion: Optional[str] = None
    facts: list[str] = Field(default_factory=list)
    truncated: bool = False


class CallerState(BaseModel):
    panic: float = 5
    trust: float = 5
    voice: str = "female_40"
    hysteria: bool = False
    silent_until: int = 0


class DirectorState(BaseModel):
    pending_events: list[str] = Field(default_factory=list)
    fired_events: list[str] = Field(default_factory=list)
    difficulty: float = 0.5
    directive: Optional[str] = None
    directive_fact: Optional[str] = None
    complications_used: int = 0


class StepMark(BaseModel):
    done: bool
    t: int
    quote: str
    confidence: float = 1.0
    needs_review: bool = False
    utterance_id: Optional[str] = None


class SpeechState(BaseModel):
    wpm: float = 0
    longest_pause_ms: int = 0
    pauses_over_threshold: int = 0
    interruptions: int = 0
    fillers: int = 0
    words: int = 0
    speech_ms: int = 0


class ScenarioRef(BaseModel):
    id: str
    branch: str
    seed: int
    title: str = ""


class CallState(BaseModel):
    call_id: str
    version: int = 0
    scenario: Optional[ScenarioRef] = None
    phase: Literal["prepare", "live", "ended", "debrief"] = "prepare"
    turn: dict[str, Any] = Field(default_factory=lambda: {"holder": "caller", "since_ms": 0})
    transcript: list[Utterance] = Field(default_factory=list)
    entities: dict[str, Any] = Field(default_factory=dict)
    caller: CallerState = Field(default_factory=CallerState)
    facts: dict[str, list[str]] = Field(default_factory=lambda: {"revealed": [], "pending": []})
    checklist: dict[str, Optional[StepMark]] = Field(default_factory=dict)
    director: DirectorState = Field(default_factory=DirectorState)
    speech: SpeechState = Field(default_factory=SpeechState)
    card: dict[str, Any] = Field(default_factory=dict)
    emotion_series: list[dict[str, Any]] = Field(default_factory=list)
    scene: list[dict[str, Any]] = Field(default_factory=list)
    end_reason: Optional[str] = None
    last_t: int = 0
    tts_playing: Optional[str] = None
    last_operator_t: int = 0
    last_caller_t: int = 0
    actions: dict[str, int] = Field(default_factory=dict)   # дії оператора: id -> час, мс
    card_t: int = 0                                         # час останнього оновлення картки, мс

    def snapshot(self) -> "CallState":
        return self.model_copy(deep=True)

    # --- редуктор ------------------------------------------------------
    def apply(self, ev: Event, enforce: bool = True) -> None:
        owners = OWNERSHIP.get(ev.type)
        if enforce and owners is not None and ev.source not in owners:
            raise OwnershipError(f"{ev.source} не може писати {ev.type}")
        p = ev.payload
        self.last_t = max(self.last_t, ev.t)
        ty = ev.type
        if ty == "call.started":
            self.scenario = ScenarioRef(**p["scenario"])
            self.caller = CallerState(**p["caller"])
            self.facts = {"revealed": [], "pending": list(p.get("pending", []))}
            self.checklist = {s: None for s in p.get("steps", [])}
            self.director.difficulty = p.get("difficulty", 0.5)
            self.director.pending_events = list(p.get("pending_events", []))
            self.emotion_series.append({"t": ev.t, "panic": self.caller.panic, "trust": self.caller.trust})
        elif ty == "phase.changed":
            self.phase = p["phase"]
        elif ty == "turn.changed":
            self.turn = {"holder": p["holder"], "since_ms": ev.t}
        elif ty == "operator.final":
            self.transcript.append(Utterance(id=p.get("uid", ev.id), t=ev.t, who="operator", text=p["text"]))
            self.last_operator_t = ev.t
        elif ty == "entities.updated":
            for k, v in p.get("entities", {}).items():
                if isinstance(v, dict) and isinstance(self.entities.get(k), dict):
                    self.entities[k] = {**self.entities[k], **v}
                else:
                    self.entities[k] = v
        elif ty == "caller.utterance":
            self.transcript.append(Utterance(
                id=p.get("uid", ev.id), t=ev.t, who="caller", text=p["text"],
                emotion=p.get("emotion"), facts=p.get("facts", [])))
            self.last_caller_t = ev.t
        elif ty == "facts.revealed":
            for f in p.get("ids", []):
                if f not in self.facts["revealed"]:
                    self.facts["revealed"].append(f)
                if f in self.facts["pending"]:
                    self.facts["pending"].remove(f)
        elif ty == "caller.emotion":
            if "panic" in p:
                self.caller.panic = max(0.0, min(10.0, float(p["panic"])))
            if "trust" in p:
                self.caller.trust = max(0.0, min(10.0, float(p["trust"])))
            if "hysteria" in p:
                self.caller.hysteria = bool(p["hysteria"])
            if "silent_until" in p:
                self.caller.silent_until = int(p["silent_until"])
            self.emotion_series.append({"t": ev.t, "panic": self.caller.panic,
                                        "trust": self.caller.trust, "reason": p.get("reason")})
        elif ty == "director.directive":
            self.director.directive = p.get("text")
            self.director.directive_fact = p.get("fact")
        elif ty == "director.state":
            for k, v in p.items():
                setattr(self.director, k, v)
        elif ty == "scene.event":
            self.scene.append({"t": ev.t, **p})
            eid = p.get("id")
            if eid and eid not in self.director.fired_events:
                self.director.fired_events.append(eid)
            if eid in self.director.pending_events:
                self.director.pending_events.remove(eid)
        elif ty == "checklist.step":
            sid = p["step_id"]
            cur = self.checklist.get(sid)
            if p.get("override") and not p.get("done"):
                self.checklist[sid] = None
            elif cur is None or p.get("override"):
                self.checklist[sid] = StepMark(**{k: v for k, v in p.items() if k in StepMark.model_fields})
        elif ty == "speech.metric":
            self.speech = SpeechState(**{**self.speech.model_dump(), **p})
        elif ty == "card.updated":
            self.card.update(p.get("fields", {}))
            self.card_t = ev.t
        elif ty == "operator.action":
            self.actions.setdefault(p["action"], ev.t)
        elif ty == "tts.playing":
            self.tts_playing = p.get("uid")
        elif ty == "tts.stopped":
            uid = p.get("uid")
            if self.tts_playing == uid:
                self.tts_playing = None
            played = p.get("played_chars")
            if played is not None:
                for u in self.transcript:
                    if u.id == uid and played < len(u.text):
                        u.text = u.text[:played].rstrip() + "…"
                        u.truncated = True
        elif ty == "call.end":
            self.end_reason = p.get("reason", "operator")
            self.phase = "ended"
        self.version += 1

    @classmethod
    def replay(cls, call_id: str, events: list[Event], until_t: Optional[int] = None) -> "CallState":
        st = cls(call_id=call_id)
        for ev in events:
            if until_t is not None and ev.t > until_t:
                break
            if until_t is not None and ev.type in ("call.end", "report.ready"):
                continue
            st.apply(ev, enforce=False)
        return st


# ---------------------------------------------------------------------------
# Схема сценарію (розділ 2.2) — чотири шари
# ---------------------------------------------------------------------------

INTENTS = {
    "greeting", "what", "address", "house", "apartment", "people", "name", "phone",
    "condition", "reassure", "instruct", "confirm", "rude", "location_detail", "any",
    "floors", "access", "danger",
}

# Дії оператора після прийому повідомлення (кнопки на картці виклику)
ACTIONS = {"alarm": "Подано сигнал «Тривога»", "report": "Доповідь про виїзд караулу"}


class Legend(BaseModel):
    name: str
    age: int
    gender: Literal["male", "female"]
    location: str
    sees: str
    manner: str
    fillers: list[str] = Field(default_factory=list)
    voice: str
    opening: list[str]
    unknown: list[str] = Field(default_factory=lambda: ["Я не знаю!", "Не знаю я, не знаю…"])


class RevealCondition(BaseModel):
    asked: list[str] = Field(default_factory=list)    # інтенти питання оператора
    volunteer: bool = False                           # абонент може сказати сам
    after_s: Optional[int] = None                     # сам скаже після N с
    min_trust: float = 0
    max_panic: float = 10
    after_fact: Optional[str] = None

    @field_validator("asked")
    @classmethod
    def _intents(cls, v: list[str]) -> list[str]:
        bad = [i for i in v if i not in INTENTS]
        if bad:
            raise ValueError(f"невідомі інтенти: {bad}")
        return v


class Fact(BaseModel):
    id: str
    say: list[str]
    say_panic: list[str] = Field(default_factory=list)
    reveal: RevealCondition = Field(default_factory=RevealCondition)
    truth: dict[str, Any] = Field(default_factory=dict)   # поля картки виклику
    critical: bool = False


class Effects(BaseModel):
    panic: float = 0
    trust: float = 0
    say: Optional[str] = None
    sound: Optional[str] = None
    caption: Optional[str] = None
    hysteria: Optional[bool] = None
    silent_s: Optional[int] = None
    reveal: list[str] = Field(default_factory=list)
    end_call: Optional[str] = None


class Trigger(BaseModel):
    at_s: Optional[int] = None
    after_s: Optional[int] = None
    unless_step: Optional[str] = None
    if_step: Optional[str] = None
    after_fact: Optional[str] = None
    delay_s: int = 0
    manual: bool = False


class PlotEvent(BaseModel):
    id: str
    title: str
    trigger: Trigger = Field(default_factory=lambda: Trigger(manual=True))
    effects: Effects = Field(default_factory=Effects)


class Branch(BaseModel):
    id: str
    weight: float = 1
    title: str = ""
    facts: dict[str, dict[str, Any]] = Field(default_factory=dict)   # перевизначення фактів
    events: list[PlotEvent] = Field(default_factory=list)
    initial: dict[str, float] = Field(default_factory=dict)


class StepRule(BaseModel):
    keywords: list[str] = Field(default_factory=list)
    all_groups: list[list[str]] = Field(default_factory=list)
    intent: Optional[str] = None
    entity_confirmed: Optional[str] = None
    semantic: Optional[str] = None     # опис для LLM-оцінювача
    action: Optional[str] = None       # крок виконано, коли курсант натиснув кнопку дії з цим id
    card_fields: list[str] = Field(default_factory=list)   # виконано, якщо ці поля картки збігаються з card_truth


class ProtocolStep(BaseModel):
    id: str
    title: str
    weight: float = 1
    critical: bool = False
    deadline_s: Optional[int] = None
    order: int = 0
    rule: StepRule = Field(default_factory=StepRule)
    example: str = ""
    tags: list[str] = Field(default_factory=list)
    source: str = ""                   # документ, розділ, глава, пункт, абзац
    basis: Literal["норма", "методична", "потребує підтвердження"] = "норма"


class Protocol(BaseModel):
    base: Optional[str] = None
    steps: list[dict[str, Any]] = Field(default_factory=list)   # нові кроки або перевизначення базових
    remove: list[str] = Field(default_factory=list)


class Scenario(BaseModel):
    id: str
    title: str
    category: str
    difficulty: int = Field(ge=1, le=3)
    brief: str
    max_duration_s: int = 300
    silence_threshold_s: float = 4
    legend: Legend
    initial: dict[str, float] = Field(default_factory=lambda: {"panic": 6, "trust": 4})
    facts: list[Fact]
    events: list[PlotEvent] = Field(default_factory=list)
    complications: list[PlotEvent] = Field(default_factory=list)
    branches: list[Branch] = Field(default_factory=lambda: [Branch(id="main")])
    protocol: Protocol
    card_truth: dict[str, Any] = Field(default_factory=dict)
    skills: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def _check_refs(self) -> "Scenario":
        fids = {f.id for f in self.facts}
        if len(fids) != len(self.facts):
            raise ValueError("дубльовані id фактів")
        for f in self.facts:
            if f.reveal.after_fact and f.reveal.after_fact not in fids:
                raise ValueError(f"факт {f.id}: after_fact={f.reveal.after_fact} не існує")
            if not f.reveal.asked and not f.reveal.volunteer and f.reveal.after_s is None:
                raise ValueError(f"факт {f.id}: немає жодної умови розкриття")
        all_events = list(self.events) + list(self.complications) + [e for b in self.branches for e in b.events]
        for e in all_events:
            for r in e.effects.reveal:
                if r not in fids:
                    raise ValueError(f"подія {e.id}: reveal={r} не існує")
            if e.trigger.after_fact and e.trigger.after_fact not in fids:
                raise ValueError(f"подія {e.id}: after_fact не існує")
        for b in self.branches:
            for k in b.facts:
                if k not in fids:
                    raise ValueError(f"гілка {b.id}: факт {k} не існує")
        if not self.branches:
            raise ValueError("потрібна хоча б одна гілка")
        return self


def merge_fact(f: Fact, override: dict[str, Any]) -> Fact:
    d = f.model_dump()
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(d.get(k), dict):
            d[k] = {**d[k], **v}
        else:
            d[k] = v
    return Fact(**d)


def deep(o: Any) -> Any:
    return copy.deepcopy(o)
