"""HTTP + WebSocket API і роздача веб-інтерфейсу.

Запуск:  uvicorn app.main:app --reload --port 8112   (з каталогу backend)
"""
from __future__ import annotations

import asyncio
import csv
import io
import json
import os
import uuid
from pathlib import Path
from typing import Any, Optional

import yaml
from fastapi import Body, FastAPI, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

from .bot import STYLE_TITLES, run_bot_call
from .metrics import METRICS
from .models import CallState, Event
from .scenarios import ScenarioError, layer_view, parse_scenario, resolve_steps, scenario_schema
from .service import Trainer

FRONT = Path(__file__).resolve().parents[2] / "frontend"


def _load_env() -> None:
    """Підхоплює змінні з .env у корені проєкту (без залежності python-dotenv); справжні змінні мають пріоритет."""
    f = FRONT.parent / ".env"
    if not f.exists():
        return
    for line in f.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


_load_env()
from . import tts  # noqa: E402  (після _load_env, щоб ключ уже був у середовищі)

app = FastAPI(title="Тренажер оператора ПЗЧ", version="0.1.0")
TR: Trainer = Trainer()

# Що бачить курсант під час дзвінка (без чек-листа, фактів, причин Режисера)
TRAINEE_EVENTS = {"phase.changed", "turn.changed", "operator.final", "operator.partial", "caller.utterance",
                  "tts.say", "tts.stop", "scene.event", "caller.emotion", "call.end", "report.ready",
                  "card.updated", "operator.action", "call.restored", "barge_in.ignored"}


def visible(ev: Event, role: str, show_ind: bool) -> Optional[dict[str, Any]]:
    d = ev.model_dump()
    if role != "trainee":
        return d
    if ev.type not in TRAINEE_EVENTS:
        return None
    if ev.type == "caller.emotion":
        if not show_ind:
            return None
        d["payload"] = {k: v for k, v in ev.payload.items() if k in ("panic", "trust")}
    if ev.type == "scene.event":
        d["payload"] = {k: ev.payload.get(k) for k in ("sound", "caption")}
    return d


def public_state(st: CallState, role: str, orch) -> dict[str, Any]:
    d = json.loads(st.model_dump_json())
    d["t_now"] = orch.clock.now() if orch.started else 0
    d["started"] = orch.started
    d["finished"] = orch.finished
    d["options"] = orch.options
    d["scenario_brief"] = orch.prep.scenario.brief
    d["scenario_title"] = orch.prep.scenario.title
    d["category"] = orch.prep.scenario.category
    d["voice"] = orch.prep.voice
    if role == "trainee":
        for k in ("checklist", "facts", "director", "entities", "emotion_series"):
            d.pop(k, None)
        if orch.options.get("blind") and not orch.finished:
            # «Будь-яка ситуація»: назва і опис сценарію відкриваються лише після завершення дзвінка
            for k in ("scenario", "scenario_title", "scenario_brief", "category"):
                d.pop(k, None)
        if not orch.options.get("show_indicators", True):
            d.pop("caller", None)
    else:
        d["steps"] = [s.model_dump() for s in orch.prep.steps]
        d["events_catalog"] = [{"id": e.id, "title": e.title, "manual": e.trigger.manual}
                               for e in orch.prep.events + orch.prep.complications]
        d["branch"] = orch.prep.branch
        d["legend"] = orch.prep.scenario.legend.model_dump()
    return d


# ---------------------------------------------------------------- користувачі
@app.post("/api/login")
def login(body: dict = Body(...)):
    name = (body.get("name") or "").strip()
    role = body.get("role")
    if not name or role not in ("trainee", "instructor", "methodist"):
        raise HTTPException(400, "Вкажіть ім'я і роль")
    TR.store.upsert_user(name, role)
    TR.store.audit(name, "login", {"role": role})
    return {"name": name, "role": role}


@app.get("/api/users")
def users(role: Optional[str] = None):
    return TR.store.users(role)


# ---------------------------------------------------------------- сценарії
@app.get("/api/scenarios")
def scenarios():
    return TR.library.summary()


@app.get("/api/scenarios/{sid}")
def scenario(sid: str, role: str = "trainee"):
    if sid not in TR.library.items:
        raise HTTPException(404)
    sc = TR.library.get(sid)
    base = {"id": sc.id, "title": sc.title, "category": sc.category, "difficulty": sc.difficulty,
            "brief": sc.brief, "skills": sc.skills}
    if role == "trainee":
        return base
    return {**base, "layers": {k: layer_view(sc, k) for k in ("caller", "director", "evaluator")},
            "branches": [b.model_dump() for b in sc.branches], "yaml": TR.library.raw(sid)}


@app.get("/api/schema")
def schema():
    return scenario_schema()


@app.post("/api/scenarios/validate")
def validate(body: dict = Body(...)):
    try:
        data = yaml.safe_load(body.get("yaml", ""))
        sc = parse_scenario(data)
        return {"ok": True, "id": sc.id, "steps": [s.title for s in resolve_steps(sc.protocol)]}
    except ScenarioError as e:
        return {"ok": False, "errors": e.errors}
    except yaml.YAMLError as e:
        return {"ok": False, "errors": [f"YAML: {e}"]}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "errors": [str(e)]}


async def bot_check(sid: str, seeds=(1, 2)) -> dict[str, Any]:
    """Автопрогін ботом-курсантом (E2-03): ідеальний ≥90 і зараховано, «забуває адресу» має провалитись."""
    results = []
    sc = TR.library.get(sid)
    for style in ("ideal", "forgets_address"):
        for seed in seeds:
            for b in sc.branches:
                o = await TR.start_call(f"bot:{style}", sid, seed=seed, branch=b.id, sim=True)
                rep = await run_bot_call(o, style)
                results.append({"style": style, "seed": seed, "branch": b.id, "score": rep["score"],
                                "passed": rep["passed"], "missed": rep["missed_critical"], "session_id": o.call_id})
    ideal_ok = all(r["score"] >= 90 and r["passed"] for r in results if r["style"] == "ideal")
    bad_ok = all(not r["passed"] for r in results if r["style"] == "forgets_address")
    return {"ok": ideal_ok and bad_ok, "ideal_ok": ideal_ok, "forgets_address_fails": bad_ok, "runs": results}


@app.post("/api/scenarios")
async def save_scenario(body: dict = Body(...)):
    try:
        sc = TR.library.save(body.get("yaml", ""))
    except ScenarioError as e:
        return {"ok": False, "errors": e.errors}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "errors": [str(e)]}
    TR.store.audit(body.get("by", "methodist"), "scenario.save", {"id": sc.id})
    check = await bot_check(sc.id)
    return {"ok": True, "id": sc.id, "bot_check": check}


@app.post("/api/scenarios/{sid}/botcheck")
async def scenario_botcheck(sid: str):
    if sid not in TR.library.items:
        raise HTTPException(404)
    return await bot_check(sid)


# ---------------------------------------------------------------- дзвінки
@app.post("/api/calls")
async def start_call(body: dict = Body(...)):
    try:
        orch = await TR.start_call(
            body.get("trainee") or "курсант", body.get("scenario_id", ""), level=body.get("level"),
            seed=body.get("seed"), options=body.get("options"), assignment_id=body.get("assignment_id"),
            from_session=body.get("from_session"), from_t=body.get("from_t"), autostart=False,
            category=body.get("category"))
    except KeyError as e:
        raise HTTPException(404, f"Не знайдено: {e}")
    return {"call_id": orch.call_id}


@app.get("/api/calls/active")
def active_calls():
    return TR.active()


@app.post("/api/calls/{cid}/command")
async def command(cid: str, body: dict = Body(...)):
    orch = TR.calls.get(cid)
    if not orch:
        raise HTTPException(404)
    await orch.handle("instructor.command", body, source="instructor")
    return {"ok": True}


@app.websocket("/ws/call/{cid}")
async def ws_call(ws: WebSocket, cid: str, role: str = "trainee", name: str = ""):
    await ws.accept()
    orch = TR.calls.get(cid)
    if not orch:
        await ws.send_json({"type": "error", "payload": {"message": "Дзвінок не знайдено або завершено"}})
        await ws.close()
        return
    show = orch.options.get("show_indicators", True)
    q = TR.bus.queue(orch.channel)
    await ws.send_json({"type": "call.snapshot", "payload": public_state(orch.state, role, orch), "t": orch.clock.now()})
    if orch.finished and orch.report:
        await ws.send_json({"type": "report.ready", "payload": {"score": orch.report["score"]}, "t": 0})

    async def pump():
        while True:
            ev = await q.get()
            d = visible(ev, role, show)
            if d:
                await ws.send_json(d)

    pump_task = asyncio.create_task(pump())
    try:
        while True:
            msg = await ws.receive_json()
            ty, payload = msg.get("type"), msg.get("payload", {})
            if role == "trainee" and ty == "call.accept":
                await orch.start()
            elif role == "trainee" and ty in ("operator.speech_start", "operator.partial", "operator.final",
                                            "operator.speech_end", "tts.playing", "tts.stopped",
                                            "card.updated", "operator.action", "call.end"):
                src = "asr" if payload.get("asr") else "operator_ui"
                await orch.handle(ty, payload, source=src)
            elif role == "instructor" and ty == "instructor.command":
                payload["by"] = name or "instructor"
                await orch.handle(ty, payload, source="instructor")
            elif role == "instructor" and ty == "call.end":
                await orch.handle("call.end", {"reason": "instructor"}, source="instructor")
    except WebSocketDisconnect:
        pass
    finally:
        pump_task.cancel()
        TR.bus.unsubscribe(orch.channel, q)


@app.websocket("/ws/calls")
async def ws_calls(ws: WebSocket):
    """Пульт інструктора: живий список дзвінків."""
    await ws.accept()
    q = TR.bus.queue("calls")
    try:
        await ws.send_json({"type": "calls.list", "payload": TR.active()})
        while True:
            try:
                await asyncio.wait_for(q.get(), timeout=2)
            except asyncio.TimeoutError:
                pass
            await ws.send_json({"type": "calls.list", "payload": TR.active()})
    except (WebSocketDisconnect, RuntimeError):
        pass
    finally:
        TR.bus.unsubscribe("calls", q)


# ---------------------------------------------------------------- сесії і звіти
def _hide_blind(s: dict[str, Any]) -> dict[str, Any]:
    """Поки дзвінок «Будь-яка ситуація» не завершено, справжній id сценарію не показуємо."""
    if s.get("status") != "done" and (s.get("options") or {}).get("blind"):
        s["scenario_id"] = "random"
    return s


@app.get("/api/sessions")
def sessions(trainee: Optional[str] = None, include_bots: bool = False):
    out = TR.store.sessions(trainee)
    if not include_bots:
        out = [s for s in out if not str(s["trainee"]).startswith("bot")]
    return [_hide_blind(s) for s in out]


@app.get("/api/sessions/{sid}")
def session(sid: str):
    s = TR.store.session(sid)
    if not s:
        raise HTTPException(404)
    s["calibrations"] = TR.store.calibrations(sid)
    return _hide_blind(s)


@app.get("/api/sessions/{sid}/events")
def session_events(sid: str):
    return [e.model_dump() for e in TR.store.events(sid)]


@app.get("/api/sessions/{sid}/state")
def session_state(sid: str, t: Optional[int] = None):
    """Реплей: стан дзвінка на будь-яку мілісекунду (з журналу подій)."""
    st = CallState.replay(sid, TR.store.events(sid), until_t=t)
    return json.loads(st.model_dump_json())


@app.post("/api/sessions/{sid}/calibrate")
def calibrate(sid: str, body: dict = Body(...)):
    s = TR.store.session(sid)
    if not s or not s.get("report"):
        raise HTTPException(404)
    rep = s["report"]
    step = next((r for r in rep["checklist"] if r["step_id"] == body["step_id"]), None)
    if not step:
        raise HTTPException(400, "Невідомий крок")
    TR.store.calibrate(sid, body["step_id"], step["done"], bool(body["done"]), body.get("comment", ""),
                       body.get("by", "instructor"))
    TR.store.audit(body.get("by", "instructor"), "calibrate", {"session": sid, **body})
    # перерахунок балів з урахуванням рішення інструктора
    step["instructor_done"] = bool(body["done"])
    total = sum(r["weight"] for r in rep["checklist"]) or 1
    got = 0.0
    missed = []
    for r in rep["checklist"]:
        done = r.get("instructor_done", r["done"])
        credit = (0.5 if r["late"] else 1.0) if done else 0.0
        got += r["weight"] * credit
        if r["critical"] and not done:
            missed.append(r["title"])
    rep["score_instructor"] = round(100 * got / total, 1)
    rep["missed_critical_instructor"] = missed
    rep["passed_instructor"] = not missed and rep["score_instructor"] >= 60
    TR.store.update_report(sid, rep)
    return {"ok": True, "score_instructor": rep["score_instructor"], "passed_instructor": rep["passed_instructor"]}


@app.get("/api/calibration")
def calibration_summary():
    rows = TR.store.calibrations()
    n = len(rows)
    agree = sum(1 for r in rows if r["system_done"] == r["instructor_done"])
    return {"n": n, "agreement": round(agree / n, 3) if n else None, "rows": rows[-100:]}


@app.get("/api/sessions.csv", response_class=PlainTextResponse)
def sessions_csv():
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["id", "курсант", "сценарій", "гілка", "seed", "складність", "бал", "зараховано", "створено"])
    for s in TR.store.sessions():
        if str(s["trainee"]).startswith("bot"):
            continue
        w.writerow([s["id"], s["trainee"], s["scenario_id"], s["branch"], s["seed"], s["difficulty"],
                    s.get("score"), s.get("passed"), s["created"]])
    return PlainTextResponse(buf.getvalue(), media_type="text/csv; charset=utf-8")


# ---------------------------------------------------------------- призначення
@app.get("/api/assignments")
def assignments(trainee: Optional[str] = None):
    return TR.store.assignments(trainee)


@app.post("/api/assignments")
def add_assignment(body: dict = Body(...)):
    if body.get("scenario_id") not in TR.library.items or not body.get("trainee"):
        raise HTTPException(400, "Вкажіть курсанта і сценарій")
    aid = "a-" + uuid.uuid4().hex[:6]
    TR.store.add_assignment(id=aid, trainee=body["trainee"], scenario_id=body["scenario_id"],
                            difficulty=int(body.get("difficulty") or TR.library.get(body["scenario_id"]).difficulty),
                            due=body.get("due"), note=body.get("note", ""), created_by=body.get("by", "instructor"))
    TR.store.upsert_user(body["trainee"], "trainee")
    TR.store.audit(body.get("by", "instructor"), "assign", body)
    return {"id": aid}


# ---------------------------------------------------------------- аналітика і спостережуваність
@app.get("/api/analytics")
def analytics():
    ss = [s for s in TR.store.sessions(limit=2000) if s.get("summary") and not str(s["trainee"]).startswith("bot")]
    by_trainee: dict[str, list] = {}
    by_step: dict[str, list[int]] = {}
    for s in reversed(ss):
        by_trainee.setdefault(s["trainee"], []).append({
            "id": s["id"], "score": s["summary"]["score"], "passed": s["summary"]["passed"],
            "scenario": s["scenario_id"], "created": s["created"],
            "address_s": (s["summary"].get("time_to") or {}).get("address_asked")})
        full = TR.store.session(s["id"])
        for r in (full or {}).get("report", {}).get("checklist", []):
            by_step.setdefault(r["title"], []).append(1 if r["done"] and not r["late"] else 0)
    steps = sorted(({"title": k, "rate": round(sum(v) / len(v), 2), "n": len(v)} for k, v in by_step.items()),
                   key=lambda x: x["rate"])
    return {"trainees": by_trainee, "steps": steps, "sessions": len(ss)}


@app.get("/api/metrics")
def metrics():
    return {**METRICS.snapshot(), "active_calls": len(TR.active())}


@app.get("/api/audit")
def audit():
    return TR.store.audit_log()


@app.post("/api/bot/run")
async def bot_run(body: dict = Body(...)):
    style = body.get("style", "ideal")
    if style not in STYLE_TITLES:
        raise HTTPException(400)
    o = await TR.start_call(f"bot:{style}", body["scenario_id"], seed=body.get("seed"), sim=True,
                            level=body.get("level"))
    rep = await run_bot_call(o, style)
    return {"session_id": o.call_id, "score": rep["score"], "passed": rep["passed"]}


@app.get("/api/bot/styles")
def bot_styles():
    return STYLE_TITLES


@app.get("/api/config")
def config():
    return {"tts": tts.enabled(), "llm": bool(os.environ.get("GEMINI_API_KEY") or os.environ.get("LLM_BASE_URL"))}


@app.post("/api/tts")
async def speak(body: dict = Body(...)):
    """Озвучка репліки абонента Gemini TTS → audio/wav."""
    from fastapi import Response  # локально: у standalone-збірці (Pyodide) мінімальний fastapi без Response
    text = str(body.get("text", ""))[:600]
    if not tts.enabled():
        raise HTTPException(503, "TTS вимкнено: немає GEMINI_API_KEY")
    try:
        wav = await tts.synthesize(text, str(body.get("emotion", "напружено")), str(body.get("voice", "female_40")))
    except Exception as e:  # noqa: BLE001 — браузер відкотиться на Web Speech
        raise HTTPException(502, f"TTS недоступний: {type(e).__name__}")
    if not wav:
        raise HTTPException(422, "порожній текст")
    return Response(wav, media_type="audio/wav", headers={"Cache-Control": "private, max-age=3600"})


# ---------------------------------------------------------------- фронтенд
app.mount("/static", StaticFiles(directory=FRONT), name="static")


@app.get("/")
def index():
    return FileResponse(FRONT / "index.html")
