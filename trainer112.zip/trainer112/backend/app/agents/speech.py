"""Аналітик мовлення (E5-02): темп, паузи, перебивання, слова-паразити. Без LLM."""
from __future__ import annotations

from typing import Any

from ..nlu import count_fillers, words

PAUSE_THRESHOLD_MS = 3000   # поріг затверджує методист


class SpeechAnalyst:
    def __init__(self, pause_threshold_ms: int = PAUSE_THRESHOLD_MS) -> None:
        self.thr = pause_threshold_ms
        self.words = 0
        self.speech_ms = 0
        self.fillers = 0
        self.longest = 0
        self.over = 0
        self.interruptions = 0
        self.pauses: list[dict[str, Any]] = []

    def on_operator(self, text: str, duration_ms: int, response_delay_ms: int, t: int) -> dict[str, Any]:
        n = len(words(text))
        self.words += n
        self.speech_ms += max(duration_ms, 300)
        self.fillers += count_fillers(text)
        if response_delay_ms > 0:
            if response_delay_ms > self.longest:
                self.longest = response_delay_ms
            if response_delay_ms > self.thr:
                self.over += 1
                self.pauses.append({"t": t, "ms": response_delay_ms})
        return self.metric()

    def on_interrupt(self) -> dict[str, Any]:
        self.interruptions += 1
        return self.metric()

    def metric(self) -> dict[str, Any]:
        wpm = self.words / (self.speech_ms / 60000) if self.speech_ms else 0
        return {"wpm": round(wpm), "longest_pause_ms": self.longest, "pauses_over_threshold": self.over,
                "interruptions": self.interruptions, "fillers": self.fillers, "words": self.words,
                "speech_ms": self.speech_ms}
