"""Агент «Оцінювач протоколу» (крок 5, E5-01).

Бачить лише шар «протокол і ваги» та репліки оператора (не легенду!).
Кожна позначка має цитату, час і впевненість; confidence < 0.7 -> на перевірку інструктору.
Живий прохід (на кожну фразу) для пульта і фінальний прохід після дзвінка.
Кроки з `rule.action` (кнопки «Тривога», «Доповісти») і `rule.card_fields` (запис у картці)
не залежать від реплік: їх позначають дія оператора і картка.
"""
from __future__ import annotations

import re
from typing import Any, Optional

from ..models import ACTIONS, CallState, ProtocolStep, Utterance
from ..nlu import intents, keyword_hit, norm
from .llm import LLMClient, parse_json


class Evaluator:
    def __init__(self, steps: list[ProtocolStep], card_truth: Optional[dict[str, Any]] = None) -> None:
        self.steps = steps
        self.card_truth = card_truth or {}
        self.llm = LLMClient("evaluator")

    def check_step(self, s: ProtocolStep, u: Utterance, entities: dict[str, Any]) -> Optional[dict[str, Any]]:
        r = s.rule
        if r.action or r.card_fields:
            return None                   # ці кроки не виконуються репліками
        text = u.text
        if r.entity_confirmed:
            ent = entities.get(r.entity_confirmed) or {}
            if isinstance(ent, dict) and ent.get("confirmed") and ent.get("confirmed_uid", u.id) == u.id:
                return {"confidence": 0.95}
            return None
        if r.all_groups:
            if all(keyword_hit(text, g) for g in r.all_groups):
                return {"confidence": 0.9}
        if r.keywords:
            if keyword_hit(text, r.keywords):
                return {"confidence": 0.85}
        if r.intent and r.intent in intents(text):
            return {"confidence": 0.8}
        return None

    def on_utterance(self, st: CallState, u: Utterance) -> list[dict[str, Any]]:
        """Живий прохід: перевірити ще не виконані кроки на новій фразі оператора."""
        marks = []
        for s in self.steps:
            if st.checklist.get(s.id):
                continue
            hit = self.check_step(s, u, st.entities)
            if hit:
                conf = hit["confidence"]
                marks.append({"step_id": s.id, "done": True, "t": u.t, "quote": u.text,
                              "confidence": conf, "needs_review": conf < 0.7, "utterance_id": u.id})
        return marks

    def on_action(self, st: CallState, aid: str, t: int) -> list[dict[str, Any]]:
        """Курсант натиснув кнопку дії: позначити кроки з цією дією."""
        marks = []
        for s in self.steps:
            if s.rule.action == aid and not st.checklist.get(s.id):
                marks.append({"step_id": s.id, "done": True, "t": t, "quote": "Дія: " + ACTIONS[aid],
                              "confidence": 1.0, "needs_review": False, "utterance_id": None})
        return marks

    async def semantic(self, st: CallState, u: Utterance, pending: list[ProtocolStep]) -> list[dict[str, Any]]:
        """Смислові кроки через LLM (якщо налаштовано). Структурований JSON-вихід."""
        sem = [s for s in pending if s.rule.semantic and not s.rule.action and not s.rule.card_fields
               and not st.checklist.get(s.id)]
        if not sem or not self.llm.enabled:
            return []
        desc = "\n".join(f"- {s.id}: {s.rule.semantic}" for s in sem)
        msgs = [{"role": "system", "content":
                 "Ти оцінювач протоколу оператора пункту зв'язку пожежно-рятувальної частини. Дано кроки і "
                 'репліку оператора. Поверни JSON {"steps":[{"step_id":str,"done":bool,"confidence":0..1}]} '
                 "лише для виконаних кроків."},
                {"role": "user", "content": f"Кроки:\n{desc}\nРепліка: «{u.text}»"}]
        try:
            data = parse_json(await self.llm.complete(msgs, json_mode=True, max_tokens=200)) or {}
        except Exception:  # noqa: BLE001
            return []
        out = []
        for m in data.get("steps", []):
            if m.get("done") and any(s.id == m.get("step_id") for s in sem):
                c = float(m.get("confidence", 0.6))
                out.append({"step_id": m["step_id"], "done": True, "t": u.t, "quote": u.text,
                            "confidence": c, "needs_review": c < 0.7, "utterance_id": u.id})
        return out

    def final_pass(self, st: CallState) -> dict[str, dict[str, Any]]:
        """Офіційна оцінка на повному транскрипті. Підтвердження адреси беремо з живого проходу."""
        result: dict[str, dict[str, Any]] = {}
        ops = [u for u in st.transcript if u.who == "operator"]
        for s in self.steps:
            live = st.checklist.get(s.id)
            if s.rule.action:
                t = st.actions.get(s.rule.action)
                if t is not None:
                    result[s.id] = {"done": True, "t": t, "quote": "Дія: " + ACTIONS[s.rule.action],
                                    "confidence": 1.0, "needs_review": False, "utterance_id": None}
                continue
            if s.rule.card_fields:
                rows = compare_card(st.card, self.card_truth, s.rule.card_fields)
                if rows and all(x["ok"] for x in rows):
                    result[s.id] = {"done": True, "t": st.card_t,
                                    "quote": "Картка: " + str(st.card.get("address", "")),
                                    "confidence": 1.0, "needs_review": False, "utterance_id": None}
                continue
            if s.rule.entity_confirmed:
                ent = st.entities.get(s.rule.entity_confirmed) or {}
                if isinstance(ent, dict) and ent.get("confirmed"):
                    u = next((x for x in ops if x.id == ent.get("confirmed_uid")), None)
                    if u:
                        result[s.id] = {"done": True, "t": u.t, "quote": u.text, "confidence": 0.95,
                                        "needs_review": False, "utterance_id": u.id}
                continue
            for u in ops:
                hit = self.check_step(s, u, st.entities)
                if hit:
                    result[s.id] = {"done": True, "t": u.t, "quote": u.text, "confidence": hit["confidence"],
                                    "needs_review": hit["confidence"] < 0.7, "utterance_id": u.id}
                    break
            if s.id not in result and live:
                result[s.id] = live.model_dump()
        return result


# (ключ картки, підпис у звіті, режим порівняння з card_truth). Склад полів: СГП р. II гл. 15 п. 2;
# СНС р. III гл. 1 п. 8. Режими: all — усі частини списку є в записаному; any — хоча б одне слово зі списку;
# int — ціле число; eq — точний збіг після нормалізації; contains — правда міститься в записаному;
# digits — останні 9 цифр телефону.
CARD_FIELDS = [
    ("address", "Місце події", "all"),
    ("incident_type", "Подія", "contains"),
    ("victims", "Людей у небезпеці / постраждалих", "int"),
    ("explosion", "Загроза вибуху", "eq"),
    ("floors", "Поверхів у будівлі", "int"),
    ("access", "Особливості під'їзду", "any"),
    ("caller_name", "Прізвище заявника", "contains"),
    ("phone", "Телефон заявника", "digits"),
]


def _as_list(exp: Any) -> list[Any]:
    return exp if isinstance(exp, list) else [exp]


def _field_ok(mode: str, exp: Any, got: Any) -> bool:
    if mode == "all":
        return all(norm(str(x)) in norm(str(got)) for x in _as_list(exp))
    if mode == "any":
        return any(norm(str(x)) in norm(str(got)) for x in _as_list(exp))
    if mode == "int":
        try:
            return int(str(got).strip()) == int(exp)
        except (TypeError, ValueError):
            return False
    if mode == "eq":
        return norm(str(got)) == norm(str(exp))
    if mode == "digits":
        dg, de = re.sub(r"\D", "", str(got)), re.sub(r"\D", "", str(exp))
        return len(dg) >= 9 and len(de) >= 9 and dg[-9:] == de[-9:]
    g, e = norm(str(got)), norm(str(exp))      # contains
    return e in g or g == e


def compare_card(card: dict[str, Any], truth: dict[str, Any],
                 fields: Optional[list[str]] = None) -> list[dict[str, Any]]:
    out = []
    for k, label, mode in CARD_FIELDS:
        if k not in truth or (fields is not None and k not in fields):
            continue
        exp = truth[k]
        got = card.get(k)
        ok = got not in (None, "") and _field_ok(mode, exp, got)
        out.append({"field": k, "label": label,
                    "expected": ", ".join(map(str, exp)) if isinstance(exp, list) else exp,
                    "got": got, "ok": ok})
    return out
