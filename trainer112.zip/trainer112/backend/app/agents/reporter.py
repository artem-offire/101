"""Звітувальник (крок 6): звіт після сесії.

Бали рахує код за вагами, а не LLM. LLM (якщо є) лише переписує текст рекомендацій.
"""
from __future__ import annotations

from typing import Any, Optional

from ..models import CallState, Event
from ..nlu import intents
from ..scenarios import Prepared
from .evaluator import compare_card
from .llm import LLMClient, parse_json


def _fmt(ms: Optional[int]) -> str:
    if ms is None:
        return "—"
    s = int(ms / 1000)
    return f"{s // 60}:{s % 60:02d}"


class Reporter:
    def __init__(self, prep: Prepared) -> None:
        self.prep = prep
        self.llm = LLMClient("reporter")

    def build(self, st: CallState, final_marks: dict[str, dict[str, Any]], events: list[Event],
              pauses: list[dict[str, Any]], latency: dict[str, Any] | None = None) -> dict[str, Any]:
        prep = self.prep
        steps = prep.steps
        rows, total_w, got_w, missed_crit = [], 0.0, 0.0, []
        for s in steps:
            m = final_marks.get(s.id)
            done = bool(m and m.get("done"))
            late = bool(done and s.deadline_s is not None and m["t"] > s.deadline_s * 1000)
            credit = (0.5 if late else 1.0) if done else 0.0
            total_w += s.weight
            got_w += s.weight * credit
            if s.critical and not done:
                missed_crit.append(s.title)
            rows.append({"step_id": s.id, "title": s.title, "critical": s.critical, "weight": s.weight,
                         "deadline_s": s.deadline_s, "done": done, "late": late, "credit": credit,
                         "t": m.get("t") if m else None, "quote": m.get("quote") if m else None,
                         "confidence": m.get("confidence") if m else None,
                         "needs_review": bool(m and m.get("needs_review")), "example": s.example,
                         "source": s.source, "basis": s.basis})
        score = round(100 * got_w / total_w, 1) if total_w else 0
        passed = not missed_crit and score >= 60
        if passed:
            pass_reason = f"Зараховано: усі критичні кроки виконано, бал {score:g}."
        elif missed_crit:
            pass_reason = "Не зараховано: пропущено критичні кроки: " + "; ".join(missed_crit) + "."
        else:
            pass_reason = f"Не зараховано: бал {score:g}, потрібно щонайменше 60."
        time_to = {r["step_id"]: (round(r["t"] / 1000, 1) if r["t"] is not None else None)
                   for r in rows if r["critical"]}
        card = compare_card(st.card, prep.scenario.card_truth)
        card_score = round(100 * sum(c["ok"] for c in card) / len(card)) if card else None
        timeline = self._timeline(st, rows)
        recs, replay_t = self._recommendations(st, rows, pauses, card)
        dur = max([u.t for u in st.transcript] + [st.last_t, 0])
        blocked = sum(1 for e in events if e.type == "caller.sentence_blocked")
        return {
            "call_id": st.call_id, "scenario_id": prep.scenario.id, "scenario_title": prep.scenario.title,
            "category": prep.scenario.category, "branch": prep.branch, "seed": prep.seed,
            "difficulty": prep.difficulty, "duration_s": round(dur / 1000, 1), "end_reason": st.end_reason,
            "score": score, "passed": passed, "pass_reason": pass_reason,
            "missed_critical": missed_crit, "checklist": rows,
            "time_to": time_to, "card": card, "card_score": card_score, "speech": st.speech.model_dump(),
            "pauses": pauses, "emotion_series": st.emotion_series, "timeline": timeline,
            "recommendations": recs, "replay_t": replay_t, "guard_blocked": blocked,
            "transcript": [u.model_dump() for u in st.transcript],
            "final_emotion": {"panic": st.caller.panic, "trust": st.caller.trust},
            "latency": latency or {},
        }

    def _timeline(self, st: CallState, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        tl: list[dict[str, Any]] = []
        for u in st.transcript:
            tl.append({"t": u.t, "kind": u.who, "text": u.text, "emotion": u.emotion})
        for r in rows:
            if r["done"]:
                tl.append({"t": r["t"], "kind": "step", "text": r["title"], "critical": r["critical"],
                           "late": r["late"]})
            elif r["deadline_s"] is not None and r["critical"]:
                tl.append({"t": r["deadline_s"] * 1000, "kind": "missed", "text": f"Дедлайн: {r['title']}",
                           "critical": True})
        for s in st.scene:
            tl.append({"t": s["t"], "kind": "scene", "text": s.get("title") or s.get("caption") or s.get("id"),
                       "by": s.get("by")})
        for e in st.emotion_series:
            if e.get("reason") and abs(e.get("panic", 0)) >= 0:
                tl.append({"t": e["t"], "kind": "emotion", "text": e["reason"], "panic": e["panic"],
                           "trust": e["trust"]})
        tl.sort(key=lambda x: (x["t"], x["kind"] != "operator"))
        return tl

    def _caller_before(self, st: CallState, t: int) -> Optional[Any]:
        prev = [u for u in st.transcript if u.who == "caller" and u.t <= t]
        return prev[-1] if prev else None

    def _recommendations(self, st: CallState, rows: list[dict[str, Any]], pauses: list[dict[str, Any]],
                         card: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], Optional[int]]:
        recs: list[dict[str, Any]] = []
        replay_t: Optional[int] = None
        addr = self.prep.scenario.card_truth.get("address")
        addr_txt = ", ".join(map(str, addr)) if isinstance(addr, list) else str(addr or "вулиця, будинок")
        for r in rows:
            r["example"] = (r["example"] or "").replace("{address}", "Повторюю: " + addr_txt)
        ops = [u for u in st.transcript if u.who == "operator"]
        for r in rows:
            if r["critical"] and not r["done"]:
                dl = (r["deadline_s"] or 60) * 1000
                cb = self._caller_before(st, dl)
                rt = max(0, (ops[-1].t if ops and ops[-1].t < dl else dl) - 3000)
                prev_ops = [u for u in ops if u.t <= dl]
                rt = max(0, prev_ops[-1].t - 500) if prev_ops else 0
                replay_t = rt if replay_t is None else min(replay_t, rt)
                recs.append({"prio": 0, "title": f"Критичний крок не виконано: {r['title']}",
                             "text": f"Цей крок обов'язковий, без нього сесія не зараховується. Спробуйте так: «{r['example']}»",
                             "quote": cb.text if cb else None, "quote_who": "caller",
                             "t": cb.t if cb else dl, "replay_t": rt})
        for r in rows:
            if r["critical"] and r["late"]:
                step_ = self.prep.step(r["step_id"])
                late_hint = ("Подавайте сигнал одразу, щойно відоме місце події (СНС р. III гл. 1 п. 9)."
                             if step_ and step_.rule.action else
                             "Ставте це питання раніше, одразу після «що сталося».")
                recs.append({"prio": 1, "title": f"Запізно: {r['title']}",
                             "text": f"Виконано на {_fmt(r['t'])} при порозі {r['deadline_s']} с. " + late_hint,
                             "quote": r["quote"], "quote_who": "operator", "t": r["t"],
                             "replay_t": max(0, r["t"] - 15000)})
                if replay_t is None:
                    replay_t = max(0, r["deadline_s"] * 1000 - 10000)
        rude = [u for u in ops if "rude" in intents(u.text)]
        if rude:
            recs.append({"prio": 1, "title": "Тон розмови", "text": "Різкі слова знижують довіру заявника і "
                         "підвищують паніку, після цього він гірше відповідає на питання.",
                         "quote": rude[0].text, "quote_who": "operator", "t": rude[0].t,
                         "replay_t": max(0, rude[0].t - 2000)})
        # найбільший стрибок паніки
        series = st.emotion_series
        best = None
        for a, b in zip(series, series[1:]):
            d = b["panic"] - a["panic"]
            if d >= 1 and (best is None or d > best[0]):
                best = (d, b)
        if best:
            b = best[1]
            cb = self._caller_before(st, b["t"] + 4000)
            recs.append({"prio": 2, "title": f"Тут заявник запанікував (+{best[0]:.1f})",
                         "text": f"Причина за журналом Режисера: {b.get('reason') or 'не вказано'}. "
                                 "Коротко заспокойте і дайте зрозуміти, що допомога вже їде.",
                         "quote": cb.text if cb else None, "quote_who": "caller", "t": b["t"],
                         "replay_t": max(0, b["t"] - 3000)})
        if pauses:
            p = max(pauses, key=lambda x: x["ms"])
            cb = self._caller_before(st, p["t"])
            recs.append({"prio": 2, "title": f"Довга пауза {p['ms'] / 1000:.1f} с",
                         "text": "Наляканий заявник сприймає тишу як те, що його не чують. Якщо треба час на "
                                 "введення даних, скажіть «я записую, залишайтеся на лінії».",
                         "quote": cb.text if cb else None, "quote_who": "caller", "t": p["t"],
                         "replay_t": max(0, p["t"] - p["ms"] - 1000)})
        bad_card = [c for c in card if not c["ok"]]
        if bad_card:
            recs.append({"prio": 3, "title": "Картка виклику заповнена не повністю",
                         "text": "Не збігається з фактами: " + ", ".join(c["label"] for c in bad_card) +
                                 ". Заповнюйте картку паралельно з розмовою.",
                         "quote": None, "t": None, "replay_t": None})
        for r in rows:
            if not r["critical"] and not r["done"]:
                recs.append({"prio": 3, "title": f"Пропущено: {r['title']}",
                             "text": f"Приклад формулювання: «{r['example']}»", "quote": None, "t": None,
                             "replay_t": None})
        sp = st.speech
        if sp.wpm > 185:
            recs.append({"prio": 3, "title": "Занадто швидкий темп", "text": f"{sp.wpm} слів/хв. Цільовий діапазон "
                         "120–160: заявник у стресі не встигає зрозуміти питання.", "quote": None, "t": None})
        if sp.fillers >= 4:
            recs.append({"prio": 4, "title": "Слова-паразити", "text": f"Помічено {sp.fillers} слів-паразитів.",
                         "quote": None, "t": None})
        recs.sort(key=lambda r: r["prio"])
        if not recs:
            recs.append({"prio": 9, "title": "Чудова робота", "text": "Усі кроки виконано вчасно. "
                         "Спробуйте цей сценарій на вищій складності.", "quote": None, "t": None})
        return recs[:3], replay_t

    async def polish(self, report: dict[str, Any]) -> dict[str, Any]:
        """Необов'язково: LLM переписує текст рекомендацій живою мовою (бали не змінює)."""
        if not self.llm.enabled:
            return report
        msgs = [{"role": "system", "content": "Ти інструктор операторів ПЗЧ. Перепиши поля text рекомендацій "
                 "коротко і доброзичливо українською. Поверни JSON {\"texts\":[...]} того ж розміру."},
                {"role": "user", "content": str([r["title"] + ": " + r["text"] for r in report["recommendations"]])}]
        try:
            data = parse_json(await self.llm.complete(msgs, json_mode=True, max_tokens=500)) or {}
            for r, t in zip(report["recommendations"], data.get("texts", [])):
                r["text"] = t
        except Exception:  # noqa: BLE001
            pass
        return report
