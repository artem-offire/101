"""Нормалізатор (E4-02): адреси, числа, телефони -> структуровані сутності.

Лише правила і довідник, без LLM у гарячому шляху (~1 мс).
"""
from __future__ import annotations

import re
from typing import Any, Optional

from ..nlu import intents, norm

UNITS = {
    "нуль": 0, "один": 1, "одна": 1, "одне": 1, "перший": 1, "перша": 1, "два": 2, "дві": 2, "другий": 2,
    "три": 3, "третій": 3, "чотири": 4, "четвертий": 4, "п'ять": 5, "п'ятий": 5, "шість": 6, "шостий": 6,
    "сім": 7, "сьомий": 7, "вісім": 8, "восьмий": 8, "дев'ять": 9, "дев'ятий": 9,
}
TEENS = {
    "десять": 10, "десятий": 10, "одинадцять": 11, "одинадцятий": 11, "дванадцять": 12, "дванадцятий": 12,
    "тринадцять": 13, "тринадцятий": 13, "чотирнадцять": 14, "чотирнадцятий": 14, "п'ятнадцять": 15,
    "п'ятнадцятий": 15, "шістнадцять": 16, "шістнадцятий": 16, "сімнадцять": 17, "сімнадцятий": 17,
    "вісімнадцять": 18, "вісімнадцятий": 18, "дев'ятнадцять": 19, "дев'ятнадцятий": 19,
}
TENS = {
    "двадцять": 20, "двадцятий": 20, "тридцять": 30, "тридцятий": 30, "сорок": 40, "сороковий": 40,
    "п'ятдесят": 50, "п'ятдесятий": 50, "шістдесят": 60, "шістдесятий": 60, "сімдесят": 70,
    "сімдесятий": 70, "вісімдесят": 80, "вісімдесятий": 80, "дев'яносто": 90, "дев'яностий": 90,
}
HUNDREDS = {"сто": 100, "двісті": 200, "триста": 300, "чотириста": 400, "п'ятсот": 500,
            "шістсот": 600, "сімсот": 700, "вісімсот": 800, "дев'ятсот": 900}
ALL_NUM = {**UNITS, **TEENS, **TENS, **HUNDREDS}

# Довідник вулиць і населених пунктів (у проді — з міського реєстру)
STREETS = [
    "київська", "шевченка", "грушевського", "лесі українки", "соборна", "незалежності", "садова", "миру",
    "центральна", "перемоги", "франка", "хрещатик", "зелена", "польова", "лісова", "набережна",
    "вишнева", "героїв", "квіткова", "шкільна", "молодіжна", "заводська", "гагаріна", "пушкінська",
    "сагайдачного", "мазепи", "бандери", "липова", "річкова", "весела", "сонячна", "озерна",
    "наукова", "сихівська", "стрийська", "личаківська", "городоцька", "кульпарківська",
]
SETTLEMENTS = ["київ", "бровари", "ірпінь", "буча", "житомир", "васильків", "біла церква", "обухів",
               "фастів", "вишгород", "березань", "гостомель", "макарів", "борова", "гатне", "петрівка",
               "брюховичі", "винники", "рудне", "сокільники", "пустомити", "львів"]

_num_word = re.compile(r"[а-яіїєґ']+")


def words_to_numbers(text: str) -> str:
    """'сімнадцять а' -> '17 а', 'сорок п'ятий' -> '45'."""
    t = norm(text)
    tokens = re.findall(r"[а-яіїєґ'0-9]+|[^а-яіїєґ'0-9]+", t)
    out: list[str] = []
    acc: Optional[int] = None
    for tok in tokens:
        if tok in ALL_NUM:
            v = ALL_NUM[tok]
            if acc is None:
                acc = v
            elif (acc % 10 == 0 and v < 10 and acc >= 20) or (acc % 100 == 0 and v < 100):
                acc += v
            else:
                out.append(str(acc))
                acc = v
            continue
        if tok.strip() == "" and acc is not None:
            continue
        if acc is not None:
            out.append(str(acc) + " ")
            acc = None
        out.append(tok)
    if acc is not None:
        out.append(str(acc))
    return re.sub(r"\s+", " ", "".join(out)).strip()


def _stem(s: str) -> str:
    return s[:-1] if len(s) > 5 and s[-1] in "аіуоиїя" else s


def extract(text: str) -> dict[str, Any]:
    t = words_to_numbers(text)
    ent: dict[str, Any] = {}
    addr: dict[str, Any] = {}
    best = -1
    for st in STREETS:
        pos = t.rfind(_stem(st)[:-1])
        if pos > best:          # остання згадка виграє (абонент виправився)
            best = pos
            addr["street"] = st.title() if " " not in st else st.capitalize()
    m = re.search(r"вул(?:иц[яіюе])?\.?\s+([а-яіїєґ']+)", t)
    if m and "street" not in addr and m.group(1) not in ALL_NUM:
        addr["street"] = m.group(1).title()
    toks = re.findall(r"[а-яіїєґ']+", t)
    for s in SETTLEMENTS:
        base = s.split()[0]
        if any(tok.startswith(base[:-1] if len(base) > 4 else base) and len(tok) - len(base) <= 2
               and not tok.endswith("ська") for tok in toks):
            addr["settlement"] = s.title()
            break
    t2 = re.sub(r"(\d)\s*-?\s*([абвгд])(?![а-яіїєґ'])", r"\1\2", t)
    hms = list(re.finditer(r"(?:будин\w*|буд\.?|№|номер будинку)\s*(\d{1,3})([абвгд])?(?![\w])", t2))
    if "street" in addr:
        stem = _stem(addr["street"].lower())[:-1]
        hms += list(re.finditer(stem + r"\w*[,.\s]+(?:\.\.\.|…|ні,?|\s|,)*?(\d{1,3})([абвгд])?(?![\w])", t2))
        tail = re.search(stem + r".*?(?:ні|точніше|вибачте)[,\s.…]+(\d{1,3})([абвгд])?(?![\w])", t2)
        if tail:
            hms.append(tail)
    hm = max(hms, key=lambda m: m.start(1)) if hms else None
    if hm:
        addr["house"] = hm.group(1) + (hm.group(2) or "")
    am = re.search(r"квартир\w*\s*(\d{1,4})", t)
    if am:
        addr["apartment"] = am.group(1)
    fm = re.search(r"(\d{1,2})\s*(?:-?й|-?му)?\s*повер|поверс?\w*\s*(\d{1,2})", t)
    if fm:
        addr["floor"] = fm.group(1) or fm.group(2)
    hw = re.search(r"\b([мнр])\s*-?\s*(\d{2})\b", t)
    if hw and ("трас" in t or "дорог" in t or "м-" in t or "н-" in t):
        addr["highway"] = f"{hw.group(1).upper()}-{hw.group(2)}"
    km = re.search(r"(\d{1,3})\s*(?:-?й|-?му)?\s*(?:кілометр|км)", t)
    if km:
        addr["km"] = km.group(1)
    if addr:
        ent["address"] = addr
    ph = re.search(r"(?:\+?38)?\s*\(?0\d{2}\)?[\s-]*\d{3}[\s-]*\d{2}[\s-]*\d{2}", t)
    if ph:
        ent["phone"] = re.sub(r"\D", "", ph.group(0))[-10:]
    pm = re.search(r"(\d{1,2})\s*(?:люд|чолов|осіб|постраждал|дит)", t)
    if pm:
        ent["people_count"] = int(pm.group(1))
    return ent


def _addr_key(a: dict[str, Any]) -> tuple:
    return (str(a.get("street", "")).lower(), str(a.get("house", "")).lower(),
            str(a.get("highway", "")).lower(), str(a.get("km", "")).lower(),
            str(a.get("settlement", "")).lower())


class Normalizer:
    """Пише `entities.*`. Відрізняє почуте від абонента і підтверджене повтором оператора."""

    def run(self, text: str, who: str, entities: dict[str, Any]) -> dict[str, Any]:
        found = extract(text)
        out: dict[str, Any] = {}
        heard = dict(entities.get("address_heard") or {})
        if who == "caller":
            if "address" not in found and heard.get("street"):
                t = words_to_numbers(text)
                t = re.sub(r"(\d)\s*-?\s*([абвгд])(?![а-яіїєґ'])", r"\1\2", t)
                ms = re.findall(r"(?<![\d-])(\d{1,3}[абвгд]?)(?![\d\w])", t)
                prev_h = re.sub(r"\D", "", str(heard.get("house", "")))
                if ms and prev_h and any(re.sub(r"\D", "", m) == prev_h for m in ms) \
                        and re.search(r"\bні\b|\bне\b", t) and len(ms) <= 3:
                    found["address"] = {"house": ms[-1]}
            if "address" in found:
                heard.update(found["address"])
                out["address_heard"] = heard
                cur = entities.get("address") or {}
                if cur.get("confirmed") and _addr_key({**cur, **found["address"]}) != _addr_key(cur):
                    out["address"] = {**cur, **found["address"], "confirmed": False}
            for k in ("phone", "people_count"):
                if k in found:
                    out[f"{k}_heard"] = found[k]
            return out
        # оператор
        if "address" in found:
            a = {**(entities.get("address") or {}), **found["address"]}
            a["confirmed"] = self._confirms(found["address"], heard, text)
            out["address"] = a
        if "phone" in found:
            out["phone"] = {"value": found["phone"],
                            "confirmed": found["phone"] == entities.get("phone_heard")}
        if "people_count" in found:
            out["people_count"] = found["people_count"]
        return out

    @staticmethod
    def _confirms(said: dict[str, Any], heard: dict[str, Any], text: str) -> bool:
        if not heard:
            return False
        keys = [k for k in ("street", "house", "highway", "km", "settlement") if heard.get(k)]
        must = [k for k in keys if k in ("street", "house", "highway", "km")] or keys
        if not must:
            return False
        ok = all(str(said.get(k, "")).lower() == str(heard[k]).lower() for k in must)
        it = intents(text)
        return ok and ("confirm" in it or "?" in text)
