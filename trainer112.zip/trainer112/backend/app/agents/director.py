"""Агент «Режисер» (крок 4): сюжет, таймери, емоційна модель, складність, команди інструктора.

Детермінована частина (правила + seed) дає відтворюваність. LLM (якщо ввімкнено)
використовується лише для «м'яких» рішень і повертає строгий JSON.
Режисер не викликає інших агентів: він повертає події, які Оркестратор публікує.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from ..models import CallState, Event, PlotEvent
from ..nlu import intents, words
from ..scenarios import Prepared
from .llm import LLMClient, parse_json


@dataclass
class Out:
    type: str
    payload: dict[str, Any]


@dataclass
class DirectorAgent:
    prep: Prepared
    adaptive: bool = True
    caller_end_t: int = 0
    last_hello_t: int = -10_000
    last_adapt_t: int = 0
    last_reassure_t: int = 0
    asked: dict[str, int] = field(default_factory=dict)
    silenced: bool = False
    llm: LLMClient = field(default_factory=lambda: LLMClient("director"))

    # --- допоміжне ------------------------------------------------------
    def _emotion(self, st: CallState, dp: float, dt: float, reason: str, **extra: Any) -> Optional[Out]:
        if abs(dp) < 1e-6 and abs(dt) < 1e-6 and not extra:
            return None
        p = {"panic": round(max(0, min(10, st.caller.panic + dp)), 2),
             "trust": round(max(0, min(10, st.caller.trust + dt)), 2), "reason": reason, **extra}
        # одразу відображаємо в локальній копії, щоб кілька змін в одному тіку складались
        st.caller.panic, st.caller.trust = p["panic"], p["trust"]
        return Out("caller.emotion", p)

    def fire(self, ev: PlotEvent, st: CallState, now: int, by: str = "plot") -> list[Out]:
        e = ev.effects
        out: list[Out] = [Out("scene.event", {"id": ev.id, "title": ev.title, "sound": e.sound,
                                              "caption": e.caption, "by": by})]
        extra: dict[str, Any] = {}
        if e.hysteria is not None:
            extra["hysteria"] = e.hysteria
        if e.silent_s:
            extra["silent_until"] = now + e.silent_s * 1000
        em = self._emotion(st, e.panic, e.trust, f"подія: {ev.title}", **extra)
        if em:
            out.append(em)
        if e.say:
            out.append(Out("director.directive", {"kind": "say", "text": e.say, "speak_now": True,
                                                  "fact": e.reveal[0] if e.reveal else None,
                                                  "delay_ms": (e.silent_s or 0) * 1000}))
        elif e.reveal:
            out.append(Out("director.directive", {"kind": "fact", "fact": e.reveal[0], "speak_now": True,
                                                  "text": f"зараз скажи про {e.reveal[0]}"}))
        if e.silent_s and not e.say:
            out.append(Out("director.directive", {"kind": "line_back", "speak_now": True,
                                                  "delay_ms": e.silent_s * 1000}))
        if e.end_call:
            out.append(Out("call.end", {"reason": e.end_call}))
        return out

    # --- старт ------------------------------------------------------------
    def opening(self) -> Out:
        return Out("director.directive", {"kind": "opening", "speak_now": True, "text": "почни розмову"})

    # --- тік раз на 1 с ------------------------------------------------
    def tick(self, st: CallState, now: int, tts_playing: bool) -> list[Out]:
        out: list[Out] = []
        now_s = now / 1000
        for ev in self.prep.events:
            if ev.id in st.director.fired_events or ev.trigger.manual:
                continue
            tr = ev.trigger
            due = False
            if tr.at_s is not None and now_s >= tr.at_s:
                due = True
            if tr.after_s is not None and now_s >= tr.after_s:
                due = True
                if tr.unless_step and st.checklist.get(tr.unless_step):
                    due = False
                if tr.if_step and not st.checklist.get(tr.if_step):
                    due = False
            if tr.after_fact:
                due = False
                if tr.after_fact in st.facts["revealed"]:
                    ft = next((u.t for u in st.transcript if tr.after_fact in u.facts), None)
                    if ft is not None and now >= ft + tr.delay_s * 1000:
                        due = True
            if due:
                out += self.fire(ev, st, now)
                st.director.fired_events.append(ev.id)
        # ініціатива абонента: оператор мовчить довше за поріг (правило 4.3.2)
        thr = self.prep.scenario.silence_threshold_s * 1000
        quiet_since = max(st.last_operator_t, self.caller_end_t)
        if (not tts_playing and st.turn.get("holder") == "operator" and now - quiet_since > thr
                and now - self.last_hello_t > thr * 1.5 and now >= st.caller.silent_until and st.transcript):
            self.last_hello_t = now
            em = self._emotion(st, 1.0, -0.5, "оператор довго мовчить")
            if em:
                out.append(em)
            out.append(Out("director.directive", {"kind": "hello", "speak_now": True,
                                                  "text": "ало, ви мене чуєте?"}))
        # повільний дрейф: без заспокоєння паніка зростає
        if now - self.last_reassure_t > 30_000 and int(now_s) % 10 == 0 and st.caller.panic < 9:
            em = self._emotion(st, 0.3, 0, "довго немає слів підтримки")
            if em:
                out.append(em)
                self.last_reassure_t = now - 20_000
        # адаптивна складність (E7-01)
        if self.adaptive and now - self.last_adapt_t >= 20_000 and now_s > 25:
            self.last_adapt_t = now
            out += self.adapt(st, now)
        return out

    def adapt(self, st: CallState, now: int) -> list[Out]:
        steps = self.prep.steps
        done_w = sum(s.weight for s in steps if st.checklist.get(s.id))
        total = sum(s.weight for s in steps) or 1
        expected = min(1.0, (now / 1000) / 120)
        progress = done_w / total
        out: list[Out] = []
        diff = st.director.difficulty
        if progress > expected + 0.15 and diff >= 0.45:
            remaining = [c for c in self.prep.complications if c.id not in st.director.fired_events]
            if remaining:
                c = remaining[0]
                out += self.fire(c, st, now, by="adaptive")
                out.append(Out("director.state", {"difficulty": round(min(1, diff + 0.1), 2),
                                                  "complications_used": st.director.complications_used + 1}))
        elif progress < expected - 0.35:
            em = self._emotion(st, -1, 0.5, "адаптивне спрощення: курсанту важко")
            if em:
                out.append(em)
            crit = [f for f in self.prep.facts.values() if f.critical and f.id not in st.facts["revealed"]]
            if crit:
                out.append(Out("director.directive", {"kind": "fact", "fact": crit[0].id, "speak_now": False,
                                                      "text": f"сам скажи про {crit[0].id}"}))
            out.append(Out("director.state", {"difficulty": round(max(0, diff - 0.1), 2)}))
        return out

    # --- реакція на репліку оператора (емоційна модель, 2.3) -----------
    def on_operator(self, st: CallState, text: str, now: int, response_delay_ms: int) -> list[Out]:
        it = intents(text)
        n = len(words(text))
        dp, dt, reasons = 0.0, 0.0, []
        if "rude" in it:
            dp += 1.5
            dt -= 2
            reasons.append("грубість оператора")
        if "reassure" in it:
            dp -= 0.8
            dt += 1
            reasons.append("оператор заспокоїв")
            self.last_reassure_t = now
        if "instruct" in it:
            dp -= 0.4
            dt += 0.5
            reasons.append("чітка інструкція")
        if "?" in text and n <= 15 and "rude" not in it:
            dp -= 0.3
            dt += 0.2
            reasons.append("спокійне коротке питання")
        if n > 30:
            dp += 0.6
            reasons.append("занадто довга репліка")
        key = ",".join(sorted(it & {"address", "house", "people", "name", "phone", "what", "condition"}))
        if key and "confirm" not in it:
            self.asked[key] = self.asked.get(key, 0) + 1
            if self.asked[key] >= 3:
                dp += 1
                dt -= 1
                reasons.append("оператор втретє питає те саме")
        if response_delay_ms > self.prep.scenario.silence_threshold_s * 1000:
            dp += 0.5
            reasons.append(f"пауза оператора {response_delay_ms / 1000:.1f} с")
        if dp > 0 and st.caller.trust > 7:
            dp *= 0.6
        out: list[Out] = []
        em = self._emotion(st, dp, dt, "; ".join(reasons)) if reasons else None
        if em:
            out.append(em)
        if "rude" in it and st.caller.panic >= 8:
            out.append(Out("caller.emotion", {"hysteria": True, "reason": "абонент у істериці"}))
        elif st.caller.hysteria and st.caller.panic < 6:
            out.append(Out("caller.emotion", {"hysteria": False, "reason": "абонент заспокоївся"}))
        return out

    async def soft_decision(self, st: CallState, text: str) -> Optional[dict[str, Any]]:
        """LLM для «м'яких» рішень (необов'язково). Вихід строго JSON із розділу 5."""
        if not self.llm.enabled:
            return None
        msgs = [{"role": "system", "content":
                 "Ти режисер навчальної симуляції дзвінка до пожежно-рятувальної частини. Оціни останню репліку оператора і поверни лише JSON "
                 '{"panic_delta":-2..2,"trust_delta":-2..2,"directive":str|null,"inject_event":null,"reason":str}.'},
                {"role": "user", "content": f"Паніка {st.caller.panic}, довіра {st.caller.trust}. Репліка: {text}"}]
        try:
            return parse_json(await self.llm.complete(msgs, json_mode=True, max_tokens=150))
        except Exception:  # noqa: BLE001
            return None

    def on_caller_utterance(self, st: CallState, facts: list[str], kind: Optional[str],
                            t_end: int) -> list[Out]:
        self.caller_end_t = max(self.caller_end_t, t_end)
        if st.director.directive and (kind in ("hello", "opening", "say", "line_back", "fact")
                                      or (st.director.directive_fact and st.director.directive_fact in facts)):
            return [Out("director.directive", {"text": None, "fact": None})]
        return []

    # --- команди інструктора (через Режисера, правило 4.3.3) ----------
    def command(self, st: CallState, cmd: str, arg: Optional[str], now: int) -> list[Out]:
        if cmd == "harder":
            remaining = [c for c in self.prep.complications if c.id not in st.director.fired_events]
            out = [Out("director.state", {"difficulty": round(min(1, st.director.difficulty + 0.15), 2)})]
            if remaining:
                out += self.fire(remaining[0], st, now, by="instructor")
            else:
                em = self._emotion(st, 1.5, -1, "інструктор: ускладнити")
                if em:
                    out.append(em)
            return out
        if cmd == "easier":
            out = [Out("director.state", {"difficulty": round(max(0, st.director.difficulty - 0.15), 2)})]
            em = self._emotion(st, -1.5, 1, "інструктор: спростити")
            return out + ([em] if em else [])
        if cmd == "silence":
            secs = int(arg or 8)
            return [Out("caller.emotion", {"silent_until": now + secs * 1000, "reason": f"інструктор: абонент замовк на {secs} с"}),
                    Out("director.directive", {"kind": "line_back", "speak_now": True, "delay_ms": secs * 1000,
                                               "text": "після паузи: алло, ви тут?"})]
        if cmd == "inject" and arg:
            ev = self.prep.event(arg)
            if ev:
                return self.fire(ev, st, now, by="instructor")
        if cmd == "line_drop":
            return [Out("scene.event", {"id": "line_drop", "title": "Обрив зв'язку", "sound": "beeps",
                                        "caption": "зв'язок обірвався", "by": "instructor"}),
                    Out("caller.emotion", {"silent_until": now + 6000, "panic": min(10, st.caller.panic + 1),
                                           "reason": "обрив зв'язку"}),
                    Out("director.directive", {"kind": "line_back", "speak_now": True, "delay_ms": 6000})]
        if cmd == "panic":
            em = self._emotion(st, float(arg or 2), 0, "інструктор: підвищити паніку")
            return [em] if em else []
        if cmd == "hysteria":
            return [Out("caller.emotion", {"hysteria": True, "reason": "інструктор: істерика"})]
        return []


def to_events(call_id: str, now: int, outs: list[Out]) -> list[Event]:
    return [Event(call_id=call_id, t=now, type=o.type, source="director", payload=o.payload) for o in outs]
