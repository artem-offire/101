"""Необов'язковий адаптер до OpenAI-сумісного API (vLLM, llama.cpp server, Ollama тощо).

Вмикається змінними середовища. Без них усі агенти працюють на детермінованих
правилах, тож тренажер запускається без GPU і без ключів.

  LLM_BASE_URL=http://gpu-server:8000/v1
  LLM_API_KEY=...                (необов'язково)
  LLM_MODEL=...                  (модель за замовчуванням)
  LLM_MODEL_CALLER / LLM_MODEL_DIRECTOR / LLM_MODEL_EVALUATOR / LLM_MODEL_REPORTER

Gemini (Google AI Studio) має пріоритет, якщо задано GEMINI_API_KEY:

  GEMINI_API_KEY=...             (ключ зберігається у .env, який не потрапляє в git)
  GEMINI_MODEL=gemini-flash-lite-latest   (швидка модель для живої розмови; ~1 с)
  GEMINI_MODEL_CALLER / _DIRECTOR / _EVALUATOR / _REPORTER   (перевизначення за роллю)
"""
from __future__ import annotations

import json
import os
from typing import Any, AsyncIterator, Optional

import httpx


GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta"


def _gemini_payload(messages: list[dict[str, str]], max_tokens: int, temperature: float,
                    json_mode: bool = False) -> dict[str, Any]:
    """OpenAI-повідомлення → тіло запиту generateContent (system → systemInstruction)."""
    system = "\n\n".join(m["content"] for m in messages if m["role"] == "system")
    contents: list[dict[str, Any]] = []
    for m in messages:
        if m["role"] == "system":
            continue
        role = "model" if m["role"] == "assistant" else "user"
        if contents and contents[-1]["role"] == role:  # Gemini вимагає чергування ролей
            contents[-1]["parts"][0]["text"] += "\n" + m["content"]
        else:
            contents.append({"role": role, "parts": [{"text": m["content"]}]})
    if not contents or contents[0]["role"] != "user":
        contents.insert(0, {"role": "user", "parts": [{"text": "(початок розмови)"}]})
    cfg: dict[str, Any] = {"maxOutputTokens": max_tokens, "temperature": temperature}
    if json_mode:
        cfg["responseMimeType"] = "application/json"
    body: dict[str, Any] = {"contents": contents, "generationConfig": cfg}
    if system:
        body["systemInstruction"] = {"parts": [{"text": system}]}
    return body


def _gemini_text(data: dict[str, Any]) -> str:
    parts = (data.get("candidates") or [{}])[0].get("content", {}).get("parts", [])
    return "".join(p.get("text", "") for p in parts if not p.get("thought"))


class LLMClient:
    def __init__(self, role: str) -> None:
        self.gemini_key = os.environ.get("GEMINI_API_KEY", "")
        self.gemini_model = (os.environ.get(f"GEMINI_MODEL_{role.upper()}")
                             or os.environ.get("GEMINI_MODEL", "gemini-flash-lite-latest"))
        self.base = os.environ.get("LLM_BASE_URL", "").rstrip("/")
        self.key = os.environ.get("LLM_API_KEY", "")
        self.model = os.environ.get(f"LLM_MODEL_{role.upper()}") or os.environ.get("LLM_MODEL", "")
        self.timeout = float(os.environ.get("LLM_TIMEOUT", "20"))

    @property
    def enabled(self) -> bool:
        return bool(self.gemini_key or (self.base and self.model))

    @property
    def is_gemini(self) -> bool:
        return bool(self.gemini_key)

    def _headers(self) -> dict[str, str]:
        h = {"Content-Type": "application/json"}
        if self.key:
            h["Authorization"] = f"Bearer {self.key}"
        return h

    async def complete(self, messages: list[dict[str, str]], json_mode: bool = False,
                       max_tokens: int = 400, temperature: float = 0.4) -> str:
        if self.is_gemini:
            async with httpx.AsyncClient(timeout=self.timeout) as c:
                r = await c.post(f"{GEMINI_BASE}/models/{self.gemini_model}:generateContent",
                                 headers={"x-goog-api-key": self.gemini_key},
                                 json=_gemini_payload(messages, max_tokens, temperature, json_mode))
                r.raise_for_status()
                return _gemini_text(r.json())
        body: dict[str, Any] = {"model": self.model, "messages": messages,
                                "max_tokens": max_tokens, "temperature": temperature}
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        async with httpx.AsyncClient(timeout=self.timeout) as c:
            r = await c.post(f"{self.base}/chat/completions", headers=self._headers(), json=body)
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]

    async def stream(self, messages: list[dict[str, str]], max_tokens: int = 120,
                     temperature: float = 0.7) -> AsyncIterator[str]:
        if self.is_gemini:
            async with httpx.AsyncClient(timeout=self.timeout) as c:
                async with c.stream("POST", f"{GEMINI_BASE}/models/{self.gemini_model}:streamGenerateContent?alt=sse",
                                    headers={"x-goog-api-key": self.gemini_key},
                                    json=_gemini_payload(messages, max_tokens, temperature)) as r:
                    r.raise_for_status()
                    async for line in r.aiter_lines():
                        if not line.startswith("data:"):
                            continue
                        try:
                            delta = _gemini_text(json.loads(line[5:].strip()))
                        except Exception:  # noqa: BLE001
                            delta = ""
                        if delta:
                            yield delta
            return
        body = {"model": self.model, "messages": messages, "max_tokens": max_tokens,
                "temperature": temperature, "stream": True}
        async with httpx.AsyncClient(timeout=self.timeout) as c:
            async with c.stream("POST", f"{self.base}/chat/completions", headers=self._headers(), json=body) as r:
                r.raise_for_status()
                async for line in r.aiter_lines():
                    if not line.startswith("data:"):
                        continue
                    data = line[5:].strip()
                    if data == "[DONE]":
                        break
                    try:
                        delta = json.loads(data)["choices"][0]["delta"].get("content")
                    except Exception:  # noqa: BLE001
                        delta = None
                    if delta:
                        yield delta


def parse_json(text: str) -> Optional[dict[str, Any]]:
    try:
        s = text[text.index("{"): text.rindex("}") + 1]
        return json.loads(s)
    except Exception:  # noqa: BLE001
        return None
