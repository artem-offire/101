"""Агент «Абонент» (крок 3).

Дві реалізації з однаковим інтерфейсом `stream_sentences`:
  * MockCaller  — детермінований, працює за шаром «легенда + факти з умовами»;
  * LLMCaller   — промпт із розділу 3 через OpenAI-сумісний API, з відкатом на Mock.
Абонент не бачить протокол оцінювання.
"""
from __future__ import annotations

import random
import re
from dataclasses import dataclass, field
from typing import AsyncIterator, Optional

from ..models import CallState, Fact
from ..nlu import intents
from ..scenarios import Prepared
from .llm import LLMClient

EMOTIONS = ["спокійно", "напружено", "плач", "крик"]


@dataclass
class Sentence:
    text: str
    emotion: str
    facts: list[str] = field(default_factory=list)
    filler: bool = False


@dataclass
class CallerInput:
    state: CallState
    operator_text: Optional[str]
    directive: Optional[dict]


def emotion_for(panic: float, rng: random.Random) -> str:
    if panic >= 8.5:
        return rng.choice(["крик", "плач"])
    if panic >= 6.5:
        return "плач" if rng.random() < 0.3 else "напружено"
    if panic >= 3.5:
        return "напружено"
    return "спокійно"


def fact_allowed(f: Fact, st: CallState, it: set[str], directive_fact: Optional[str], now_s: float) -> bool:
    r = f.reveal
    if r.after_fact and r.after_fact not in st.facts["revealed"]:
        return False
    if directive_fact == f.id:
        return True
    if r.asked and it & set(r.asked):
        return True
    if r.after_s is not None and now_s >= r.after_s:
        return True
    return False


def facts_eligible(prep: Prepared, st: CallState, text: Optional[str], directive_fact: Optional[str]) -> list[str]:
    """Перелік фактів, які Абонент МАЄ ПРАВО назвати зараз (для Сторожа і промпту)."""
    it = intents(text or "")
    now_s = st.last_t / 1000
    out = list(st.facts["revealed"])
    for f in prep.facts.values():
        if f.id not in out and (fact_allowed(f, st, it, directive_fact, now_s) or f.reveal.volunteer):
            out.append(f.id)
    return out


class MockCaller:
    is_llm = False

    def __init__(self, prep: Prepared) -> None:
        self.prep = prep

    def respond(self, inp: CallerInput) -> list[Sentence]:
        st, prep = inp.state, self.prep
        rng = random.Random(prep.seed * 7919 + st.version)
        panic, trust = st.caller.panic, st.caller.trust
        leg = prep.scenario.legend
        d = inp.directive or {}
        kind = d.get("kind")
        out: list[Sentence] = []

        def em() -> str:
            return emotion_for(panic, rng)

        def filler(text: str) -> str:
            if leg.fillers and rng.random() < 0.15 + panic / 25:
                fl = rng.choice(leg.fillers)
                if text.lower().startswith(fl.lower()):
                    return text
                if text.startswith("("):
                    return text
                first = text.split()[0].strip(",.!?…")
                body = text if first in leg.name else text[0].lower() + text[1:]
                return f"{fl.capitalize()}, {body}"
            return text

        def say_fact(f: Fact) -> Sentence:
            lines = f.say_panic if (panic >= 7 and f.say_panic) else f.say
            return Sentence(filler(rng.choice(lines)), em(), [f.id])

        if kind == "opening":
            return [Sentence(rng.choice(leg.opening), em())]
        if kind == "say":
            fs = [d["fact"]] if d.get("fact") else []
            return [Sentence(d["text"], d.get("emotion") or em(), fs)]
        if kind == "hello":
            return [Sentence(rng.choice(["Алло?! Ви мене чуєте?", "Алло! Чому ви мовчите?!",
                                         "Ви там? Алло!"]), "напружено" if panic < 7 else "крик")]
        if kind == "line_back":
            return [Sentence("Алло! Алло! Зв'язок обірвався… Ви мене чуєте?", "крик")]

        text = inp.operator_text or ""
        it = intents(text)
        now_s = st.last_t / 1000
        revealed = set(st.facts["revealed"])
        directive_fact = d.get("fact") or st.director.directive_fact

        if "rude" in it:
            out.append(Sentence(rng.choice(["Чого ви на мене кричите?!", "Не кричіть на мене, будь ласка…",
                                            "Я ж вам кажу!"]), "плач"))
        # 1) факти, про які питають
        cands: list[Fact] = []
        blocked: list[Fact] = []
        repeated: list[Fact] = []
        for f in prep.facts.values():
            if not fact_allowed(f, st, it, directive_fact, now_s):
                continue
            if f.id in revealed:
                if f.reveal.asked and it & set(f.reveal.asked) and not (it & {"confirm"}):
                    repeated.append(f)
                continue
            if f.id == directive_fact or (trust >= f.reveal.min_trust and panic <= f.reveal.max_panic):
                cands.append(f)
            else:
                blocked.append(f)
        # конкретніші інтенти першими (номер будинку важливіший за «адресу»)
        def spec(f: Fact) -> int:
            return min((len(f.reveal.asked) for _ in [0]), default=9) if f.reveal.asked else 9
        cands.sort(key=lambda f: (f.id != directive_fact, spec(f)))
        for f in cands[:2]:
            out.append(say_fact(f))

        if "confirm" in it and not cands:
            ok = rng.choice(["Так, так, правильно!", "Так! Швидше, будь ласка!", "Так, все вірно."])
            heard = st.entities.get("address_heard") or {}
            said = st.entities.get("address") or {}
            if said and heard and said.get("confirmed") is False and "address" in it:
                ok = "Ні-ні, не так! Я ж казала…"
            out.append(Sentence(ok, em()))
        if not cands and blocked:
            out.append(Sentence(filler(rng.choice([
                "Я не знаю! Я не можу зараз думати, приїжджайте!",
                "Зачекайте… я не пам'ятаю… Господи…",
                "Та яка різниця?! Швидше!",
            ])), "плач" if panic >= 7 else "напружено"))
        if not cands and repeated and "confirm" not in it:
            f = repeated[0]
            out.append(Sentence(f"Я ж вам вже казала! {rng.choice(f.say)}", "напружено", []))
        if not out:
            if it & {"instruct"}:
                out.append(Sentence(rng.choice(["Добре, добре… зараз.", "Так, зараз зроблю…", "Зрозуміла, роблю."]), em()))
            elif it & {"reassure"}:
                out.append(Sentence(rng.choice(["Добре… Тільки швидше, будь ласка.", "Дякую… Я тут, тут.",
                                                "Скільки їм їхати?!"]), em()))
            elif it & {"greeting"} and not it & {"what", "address"}:
                pending_vol = [f for f in prep.facts.values() if f.reveal.volunteer and f.id not in revealed]
                if pending_vol:
                    out.append(say_fact(pending_vol[0]))
                else:
                    out.append(Sentence("Алло! Допоможіть!", em()))
            elif it & {"any", "what", "people", "name", "phone", "condition", "location_detail", "address"}:
                out.append(Sentence(filler(rng.choice(leg.unknown)), em()))
            else:
                out.append(Sentence(rng.choice(["Що? Я не зрозуміла…", "Що ви кажете? Повторіть!",
                                                "Що мені робити?!"]), em()))
        # 2) у паніці абонент сам вигукує важливе
        if len(out) < 2 and panic >= 7.5 and rng.random() < 0.35:
            vol = [f for f in prep.facts.values()
                   if f.reveal.volunteer and f.id not in revealed and all(f.id not in s.facts for s in out)]
            if vol:
                out.append(say_fact(vol[0]))
        return out[:2]

    async def stream_sentences(self, inp: CallerInput) -> AsyncIterator[Sentence]:
        for s in self.respond(inp):
            yield s


CALLER_PROMPT = """Ти граєш людину, яка телефонує до пожежно-рятувальної частини (101). Ти НЕ асистент і не знаєш протоколів.
ЛЕГЕНДА: {legend}
СТАН: паніка {panic}/10, довіра до оператора {trust}/10.
ЩО МОЖНА СКАЗАТИ ЗАРАЗ: {allowed_facts} (кожен факт лише за його умовою).
ДИРЕКТИВА РЕЖИСЕРА: {directive}
ПРАВИЛА: говори 1–2 короткими реченнями, розмовною українською; не вигадуй фактів поза легендою;
якщо не знаєш відповіді, так і скажи по-людськи; перед реченням став мітку [спокійно|напружено|плач|крик];
коли видаєш факт, додай в кінці <fact id="..."/>."""

_tag = re.compile(r"^\s*\[(спокійно|напружено|плач|крик)\]\s*")
_fact = re.compile(r"<fact\s+id=\"([^\"]+)\"\s*/>")
_split = re.compile(r"(?<=[.!?…])\s+")


class LLMCaller:
    is_llm = True

    def __init__(self, prep: Prepared, client: Optional[LLMClient] = None) -> None:
        self.prep = prep
        self.client = client or LLMClient("caller")
        self.mock = MockCaller(prep)

    def build_messages(self, inp: CallerInput) -> list[dict[str, str]]:
        st, prep = inp.state, self.prep
        leg = prep.scenario.legend
        d = inp.directive or {}
        allowed = facts_eligible(prep, st, inp.operator_text, d.get("fact") or st.director.directive_fact)
        facts_txt = "; ".join(f'{fid}: "{prep.facts[fid].say[0]}"' for fid in allowed if fid in prep.facts)
        legend = (f"{leg.name}, {leg.age} р. Де: {leg.location}. Бачить: {leg.sees}. Манера: {leg.manner}. "
                  f"Слова-паразити: {', '.join(leg.fillers)}")
        directive = d.get("text") or st.director.directive or "немає"
        system = CALLER_PROMPT.format(legend=legend, panic=round(st.caller.panic), trust=round(st.caller.trust),
                                      allowed_facts=facts_txt or "нічого нового", directive=directive)
        msgs = [{"role": "system", "content": system}]
        for u in st.transcript[-10:]:
            if u.who == "operator":
                msgs.append({"role": "user", "content": u.text})
            elif u.who == "caller":
                msgs.append({"role": "assistant", "content": f"[{u.emotion or 'напружено'}] {u.text}"})
        if inp.operator_text and (not st.transcript or st.transcript[-1].text != inp.operator_text):
            msgs.append({"role": "user", "content": inp.operator_text})
        if d.get("kind") == "opening":
            msgs.append({"role": "user", "content": "(з'єднання встановлено, ти говориш першим)"})
        return msgs

    async def stream_sentences(self, inp: CallerInput) -> AsyncIterator[Sentence]:
        kind = (inp.directive or {}).get("kind")
        if not self.client.enabled or kind in ("say", "line_back"):
            async for s in self.mock.stream_sentences(inp):
                yield s
            return
        buf, n = "", 0
        try:
            async for tok in self.client.stream(self.build_messages(inp)):
                buf += tok
                parts = _split.split(buf)
                for p in parts[:-1]:
                    s = self._parse(p)
                    if s:
                        n += 1
                        yield s
                buf = parts[-1]
            if buf.strip():
                s = self._parse(buf)
                if s:
                    yield s
        except Exception:  # noqa: BLE001 — відкат на детермінованого абонента
            if n == 0:
                async for s in self.mock.stream_sentences(inp):
                    yield s

    def _parse(self, raw: str) -> Optional[Sentence]:
        emo = "напружено"
        m = _tag.match(raw)
        if m:
            emo = m.group(1)
            raw = raw[m.end():]
        facts = _fact.findall(raw)
        text = _fact.sub("", raw).strip()
        return Sentence(text, emo, facts) if text else None


def make_caller(prep: Prepared) -> MockCaller | LLMCaller:
    c = LLMClient("caller")
    return LLMCaller(prep, c) if c.enabled else MockCaller(prep)
