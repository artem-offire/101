"""Агент «Сторож» (гардрейли, E9-04).

Перевіряє кожне речення Абонента перед TTS: вихід з ролі, підказки протоколу,
англійські слова, факти поза дозволеними, вигадані числа. Лише правила, <1 мс.
"""
from __future__ import annotations

import random
import re
from typing import Optional

from ..models import CallState
from ..nlu import norm
from ..scenarios import Prepared
from .caller import Sentence, facts_eligible

FORBIDDEN = [
    (r"\bші\b|штучн\w* інтелект|мовн\w* модел|нейромереж", "out_of_role_ai"),
    (r"я\s+(?:лише\s+|просто\s+)?(?:асистент|бот|програма|помічник)", "out_of_role_ai"),
    (r"як\s+(?:ші|асистент|модель)", "out_of_role_ai"),
    (r"протокол|чек-?лист|оцінюван|критичн\w* крок|бал(?:и|ів)\b", "protocol_hint"),
    (r"(?:вам|ви)\s+(?:варто|слід|потрібно|треба|маєте)\s+(?:запитати|спитати|уточнити|з'ясувати)", "protocol_hint"),
    (r"оператор\w*\s+(?:повин|має|мусить)", "protocol_hint"),
    (r"сценарі", "out_of_role_meta"),
]
SAFE = ["Що? Я вас погано чую!", "Ой… зачекайте…", "Я не знаю, я не знаю!", "Алло? Ви тут?",
        "Господи… Що мені робити?"]


class Guard:
    def __init__(self, prep: Prepared) -> None:
        self.prep = prep
        allowed_text = " ".join(" ".join(f.say + f.say_panic) for f in prep.facts.values())
        allowed_text += " " + " ".join(prep.scenario.legend.opening) + " " + str(prep.scenario.legend.age)
        allowed_text += " " + " ".join(str(e.effects.say or "") for e in prep.events + prep.complications)
        self.allowed_numbers = set(re.findall(r"\d+", allowed_text))

    def check(self, s: Sentence, st: CallState, operator_text: Optional[str],
              directive_fact: Optional[str] = None) -> tuple[bool, str]:
        t = norm(s.text)
        if len(s.text) > 320:
            return False, "too_long"
        for pat, reason in FORBIDDEN:
            if re.search(pat, t):
                return False, reason
        if re.search(r"[a-zA-Z]{3,}", s.text):
            return False, "latin"
        allowed = set(facts_eligible(self.prep, st, operator_text, directive_fact))
        for f in s.facts:
            if f not in self.prep.facts:
                return False, "unknown_fact"
            if f not in allowed:
                return False, "fact_not_allowed"
        for n in re.findall(r"\d+", s.text):
            if n not in self.allowed_numbers:
                return False, "invented_number"
        return True, ""

    def safe_fallback(self, st: CallState) -> Sentence:
        rng = random.Random(self.prep.seed + st.version)
        return Sentence(rng.choice(SAFE), "напружено")
