"""Озвучка через Gemini TTS: текст + емоція + голос → WAV.

Ключ береться з GEMINI_API_KEY (файл .env). Відповіді кешуються в пам'яті, бо репліки сценаріїв повторюються.
Якщо ключа немає або запит не вдався, ендпоїнт повертає 503, а браузер озвучує реплікою через Web Speech API.
"""
from __future__ import annotations

import base64
import hashlib
import io
import os
import re
import wave
from collections import OrderedDict
from typing import Optional

import httpx

GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta"
# Стиль задається короткою англійською директивою «Say <як>: <текст>». Довга інструкція українською модель
# озвучувала вголос разом з репліком, тож у запит іде лише директива і сама репліка.
STYLE = {"спокійно": "in a tired, worried but calm voice",
         "напружено": "in a tense, anxious voice, slightly fast, like a frightened person on the phone",
         "плач": "in a trembling, tearful voice, sobbing between phrases",
         "крик": "in a panicked, breathless, loud voice, almost screaming"}
STAGE = re.compile(r"\([^)]*\)")
_CACHE: "OrderedDict[str, bytes]" = OrderedDict()
_MAX_CACHE = 300


def enabled() -> bool:
    return bool(os.environ.get("GEMINI_API_KEY"))


def pick_voice(spec: str) -> str:
    """female_60_tremble / male_14 / female_40 → голос Gemini."""
    forced = os.environ.get("GEMINI_TTS_VOICE_FORCE")
    if forced:
        return forced
    m = re.match(r"(male|female)(?:_(\d+))?", spec or "")
    sex, age = (m.group(1), int(m.group(2) or 40)) if m else ("female", 40)
    if sex == "male":
        return "Puck" if age < 25 else ("Orus" if age < 55 else "Charon")
    return "Leda" if age < 30 else ("Kore" if age < 55 else "Aoede")


def pcm_to_wav(pcm: bytes, rate: int = 24000) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm)
    return buf.getvalue()


def _audio_to_wav(mime: str, data: bytes) -> bytes:
    mime = mime.lower()
    if "wav" in mime or data[:4] == b"RIFF":
        return data
    m = re.search(r"rate=(\d+)", mime)
    return pcm_to_wav(data, int(m.group(1)) if m else 24000)


async def synthesize(text: str, emotion: str = "напружено", voice_spec: str = "female_40") -> Optional[bytes]:
    key = os.environ.get("GEMINI_API_KEY", "")
    text = STAGE.sub("", text).strip()
    if not key or not text:
        return None
    voice = pick_voice(voice_spec)
    model = os.environ.get("GEMINI_TTS_MODEL", "gemini-3.8-flash-tts")
    ck = hashlib.sha1(f"{model}|{voice}|{emotion}|{text}".encode()).hexdigest()
    if ck in _CACHE:
        _CACHE.move_to_end(ck)
        return _CACHE[ck]
    prompt = f"Say {STYLE.get(emotion, STYLE['напружено'])}: {text}"
    body = {"contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {"responseModalities": ["AUDIO"],
                                 "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voice}}}}}
    async with httpx.AsyncClient(timeout=float(os.environ.get("TTS_TIMEOUT", "25"))) as c:
        r = await c.post(f"{GEMINI_BASE}/models/{model}:generateContent", headers={"x-goog-api-key": key}, json=body)
        r.raise_for_status()
    part = r.json()["candidates"][0]["content"]["parts"][0]["inlineData"]
    wav = _audio_to_wav(part.get("mimeType", ""), base64.b64decode(part["data"]))
    _CACHE[ck] = wav
    while len(_CACHE) > _MAX_CACHE:
        _CACHE.popitem(last=False)
    return wav
