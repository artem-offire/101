"""Оркестратор дзвінка (крок 2, E9-02).

Одна asyncio-задача на дзвінок. Єдиний, хто вирішує, хто «має слово»:
тримає turn, запускає/скасовує генерацію Абонента, розсилає роботу холодному
контуру і не чекає на нього. Усі зміни стану йдуть подіями через редуктор.
"""
from __future__ import annotations

import asyncio
import time
import uuid
from typing import Any, Optional

from .agents.caller import CallerInput, Sentence, make_caller
from .agents.director import DirectorAgent, Out
from .agents.evaluator import Evaluator
from .agents.guard import Guard
from .agents.normalizer import Normalizer
from .agents.reporter import Reporter
from .agents.speech import SpeechAnalyst
from .bus import EventBus
from .metrics import METRICS, Metrics
from .models import ACTIONS, CallState, Event, Utterance
from .nlu import norm, words
from .scenarios import Prepared
from .store import Store

VOICE_PARAMS = {"спокійно": (1.0, 1.0), "напружено": (1.1, 1.05), "плач": (0.95, 1.15), "крик": (1.2, 1.2)}


class RealClock:
    def __init__(self, offset_ms: int = 0) -> None:
        self.t0 = time.monotonic()
        self.offset = offset_ms

    def now(self) -> int:
        return int((time.monotonic() - self.t0) * 1000) + self.offset


class SimClock:
    """Віртуальний час для бота-курсанта і тестів: дзвінок на 3 хв проганяється за мілісекунди."""

    def __init__(self, offset_ms: int = 0) -> None:
        self.t = offset_ms

    def now(self) -> int:
        return self.t

    def advance(self, ms: int) -> None:
        self.t += ms


def caller_duration_ms(text: str) -> int:
    return 400 + len(text) * 55


class CallOrchestrator:
    def __init__(self, call_id: str, prep: Prepared, bus: EventBus, store: Store,
                 clock: RealClock | SimClock, options: Optional[dict[str, Any]] = None,
                 metrics: Metrics = METRICS, history: Optional[list[Event]] = None,
                 from_t: Optional[int] = None) -> None:
        self.call_id = call_id
        self.prep = prep
        self.bus = bus
        self.store = store
        self.clock = clock
        self.sim = isinstance(clock, SimClock)
        self.options = options or {}
        self.metrics = metrics
        self.history = history
        self.from_t = from_t
        self.channel = f"call.{call_id}"
        self.state = CallState(call_id=call_id)
        self.caller = make_caller(prep)
        self.guard = Guard(prep)
        self.director = DirectorAgent(prep, adaptive=self.options.get("adaptive", True))
        self.evaluator = Evaluator(prep.steps, prep.scenario.card_truth)
        self.speech = SpeechAnalyst()
        self.reporter = Reporter(prep)
        self.normalizer = Normalizer()
        self.caller_task: Optional[asyncio.Task] = None
        self.tick_task: Optional[asyncio.Task] = None
        self.cold: set[asyncio.Task] = set()
        self.scheduled: list[tuple[int, dict[str, Any]]] = []
        self.op_seq = 0
        self.op_speech_start: Optional[int] = None
        self.final_perf: Optional[float] = None
        self.speculative: dict[str, asyncio.Task] = {}
        self.finished = False
        self.started = False
        self.done = asyncio.Event()
        self.report: Optional[dict[str, Any]] = None
        self.caller_speaking_until = 0
        self.last_directive_kind: Optional[str] = None

    # ------------------------------------------------------------------
    async def emit(self, type_: str, source: str, payload: dict[str, Any], t: Optional[int] = None) -> Event:
        ev = Event(call_id=self.call_id, t=self.clock.now() if t is None else t, type=type_, source=source,
                   payload=payload)
        self.state.apply(ev)
        await self.bus.publish(self.channel, ev)
        return ev

    async def start(self) -> None:
        """Фаза «Дзвінок»: курсант прийняв виклик. До цього дзвінок у фазі «Підготовка»."""
        if self.started:
            return
        self.started = True
        if isinstance(self.clock, RealClock):
            self.clock.t0 = time.monotonic()
        prep = self.prep
        if self.history is not None:
            # «переграти з моменту»: відновлюємо стан із журналу до from_t
            for ev in self.history:
                if self.from_t is not None and ev.t > self.from_t:
                    break
                if ev.type in ("call.end", "report.ready", "phase.changed"):
                    continue
                ev2 = ev.model_copy(update={"call_id": self.call_id, "id": uuid.uuid4().hex[:12]})
                self.state.apply(ev2, enforce=False)
                await self.bus.publish(self.channel, ev2)
            self.director.caller_end_t = self.state.last_caller_t
            await self.emit("call.restored", "orchestrator", {"from_t": self.from_t})
            await self.emit("phase.changed", "orchestrator", {"phase": "live"})
            await self.emit("turn.changed", "orchestrator", {"holder": "operator"})
        else:
            await self.emit("call.started", "orchestrator", {
                "scenario": {"id": prep.scenario.id, "branch": prep.branch, "seed": prep.seed,
                             "title": prep.scenario.title},
                "caller": {"panic": prep.initial["panic"], "trust": prep.initial["trust"], "voice": prep.voice},
                "pending": list(prep.facts), "steps": [s.id for s in prep.steps],
                "difficulty": prep.difficulty,
                "pending_events": [f"{e.id}@{(e.trigger.at_s or e.trigger.after_s or 0) * 1000}"
                                   for e in prep.events if not e.trigger.manual],
                "options": self.options,
            }, t=0)
            await self.emit("phase.changed", "orchestrator", {"phase": "live"})
            await self._process([self.director.opening()])
        if not self.sim:
            self.tick_task = asyncio.create_task(self._tick_loop())

    async def _tick_loop(self) -> None:
        try:
            while not self.finished:
                await asyncio.sleep(1)
                await self.tick()
        except asyncio.CancelledError:
            pass

    async def tick(self) -> None:
        if self.finished:
            return
        now = self.clock.now()
        if now >= self.prep.scenario.max_duration_s * 1000:
            await self.finish("timeout")
            return
        due = [d for d in self.scheduled if d[0] <= now]
        self.scheduled = [d for d in self.scheduled if d[0] > now]
        for _, directive in due:
            self._speak(directive, None)
        playing = bool(self.state.tts_playing) or (self.sim and now < self.caller_speaking_until) \
            or bool(self.caller_task and not self.caller_task.done())
        outs = self.director.tick(self.state.snapshot(), now, playing)
        await self._process(outs)

    async def _process(self, outs: list[Out]) -> None:
        now = self.clock.now()
        for o in outs:
            if o.type == "call.end":
                await self.finish(o.payload.get("reason", "plot"))
                return
            await self.emit(o.type, "director", o.payload)
            if o.type == "director.directive" and o.payload.get("speak_now"):
                delay = int(o.payload.get("delay_ms") or 0)
                if delay:
                    self.scheduled.append((now + delay, o.payload))
                else:
                    self._speak(o.payload, None)

    # --- гарячий контур ---------------------------------------------------
    def _cancel_caller(self) -> None:
        if self.caller_task and not self.caller_task.done():
            self.caller_task.cancel()

    def _speak(self, directive: Optional[dict[str, Any]], op_text: Optional[str]) -> None:
        self._cancel_caller()
        self.caller_task = asyncio.create_task(self._speak_as_caller(directive, op_text))

    async def _first_sentences(self, inp: CallerInput) -> list[Sentence]:
        return [s async for s in self.caller.stream_sentences(inp)]

    async def _speak_as_caller(self, directive: Optional[dict[str, Any]], op_text: Optional[str]) -> None:
        seq = self.op_seq
        now = self.clock.now()
        kind = (directive or {}).get("kind")
        if now < self.state.caller.silent_until and kind not in ("line_back", "say"):
            return
        try:
            await self.emit("turn.changed", "orchestrator", {"holder": "caller"})
            snap = self.state.snapshot()
            d = dict(directive or {})
            if not d.get("fact") and snap.director.directive_fact:
                d["fact"] = snap.director.directive_fact
            inp = CallerInput(snap, op_text, d)
            spec = self.speculative.pop(norm(op_text or ""), None) if op_text else None
            first = True
            if spec is not None:
                sentences = await spec
                source = _aiter(sentences)
            elif self.caller.is_llm:
                source = self.caller.stream_sentences(inp)
            else:
                with self.metrics.stage("caller"):
                    sentences = await self._first_sentences(inp)
                source = _aiter(sentences)
            # живий заповнювач («ааа…», схлип) ховає затримку повільної LLM
            filler = asyncio.create_task(self._filler_after(0.4, seq)) \
                if (self.caller.is_llm and not self.sim and spec is None) else None
            async for s in source:
                if filler:
                    filler.cancel()
                    filler = None
                if seq != self.op_seq:      # запізнілий результат відкидається (правило 4.3.6)
                    return
                await self._emit_sentence(s, op_text, d, first)
                first = False
            if filler:
                filler.cancel()
            self.last_directive_kind = kind
        except asyncio.CancelledError:
            raise
        finally:
            if not self.finished and seq == self.op_seq:
                try:
                    await self.emit("turn.changed", "orchestrator", {"holder": "operator"})
                except Exception:  # noqa: BLE001
                    pass

    async def _filler_after(self, secs: float, seq: int) -> None:
        await asyncio.sleep(secs)
        if seq == self.op_seq and not self.finished:
            txt = "Ааа…" if self.state.caller.panic < 7 else "(схлип) Ох…"
            await self.emit("tts.say", "orchestrator", {"uid": "f" + uuid.uuid4().hex[:6], "text": txt,
                                                        "emotion": "напружено", "filler": True, "rate": 1.0,
                                                        "pitch": 1.0, "voice": self.state.caller.voice})

    async def _emit_sentence(self, s: Sentence, op_text: Optional[str], d: dict[str, Any], first: bool) -> None:
        with self.metrics.stage("guard"):
            ok, reason = self.guard.check(s, self.state, op_text, d.get("fact"))
        await self.emit("caller.sentence", "caller", {"text": s.text, "emotion": s.emotion, "facts": s.facts})
        self.metrics.guard_result(ok, reason)
        if ok:
            await self.emit("caller.sentence_approved", "guard", {"text": s.text})
        else:
            await self.emit("caller.sentence_blocked", "guard", {"text": s.text, "reason": reason})
            s = self.guard.safe_fallback(self.state)
        if first and self.final_perf is not None and op_text:
            self.metrics.hot((time.perf_counter() - self.final_perf) * 1000)
        uid = "c" + uuid.uuid4().hex[:8]
        now = self.clock.now()
        if s.facts:
            await self.emit("facts.revealed", "caller", {"ids": s.facts})
        await self.emit("caller.utterance", "guard", {"uid": uid, "text": s.text, "emotion": s.emotion,
                                                       "facts": s.facts})
        ents = self.normalizer.run(s.text, "caller", self.state.entities)
        if ents:
            await self.emit("entities.updated", "normalizer", {"entities": ents})
            if (ents.get("address") or {}).get("confirmed") is False:
                # абонент виправив адресу: підтвердження скасовується
                for st_ in self.prep.steps:
                    if st_.rule.entity_confirmed == "address" and self.state.checklist.get(st_.id):
                        await self.emit("checklist.step", "evaluator", {
                            "step_id": st_.id, "done": False, "override": True, "t": now,
                            "quote": s.text, "reason": "абонент виправив адресу"})
        rate, pitch = VOICE_PARAMS.get(s.emotion, (1.0, 1.0))
        rate += (self.state.caller.panic - 5) * 0.03
        await self.emit("tts.say", "orchestrator", {"uid": uid, "text": s.text, "emotion": s.emotion,
                                                    "voice": self.state.caller.voice, "rate": round(rate, 2),
                                                    "pitch": pitch})
        dur = caller_duration_ms(s.text)
        start = max(now, self.caller_speaking_until)
        self.caller_speaking_until = start + dur
        if self.sim:
            self.state.last_t = max(self.state.last_t, now)
        outs = self.director.on_caller_utterance(self.state, s.facts, d.get("kind"), start + dur)
        await self._process(outs)

    # --- вхідні події від клієнта/бота ---------------------------------
    async def handle(self, type_: str, payload: dict[str, Any], source: str = "operator_ui") -> None:
        if self.finished and type_ not in ("card.updated",):
            return
        now = self.clock.now()
        if type_ == "operator.speech_start":
            self.op_speech_start = now
            await self.emit("operator.speech_start", source, {})
            speaking = bool(self.state.tts_playing) or (self.sim and now < self.caller_speaking_until)
            if speaking:
                if self.state.caller.hysteria:
                    await self.emit("barge_in.ignored", "orchestrator", {"reason": "абонент у істериці"})
                else:
                    await self.barge_in()
        elif type_ == "operator.partial":
            await self.emit("operator.partial", source, {"text": payload.get("text", "")})
            txt = payload.get("text", "")
            if self.caller.is_llm and len(words(txt)) >= 4 and norm(txt) not in self.speculative:
                # спекулятивна генерація: якщо фінальний текст збігся, відповідь уже готова
                inp = CallerInput(self.state.snapshot(), txt, {"fact": self.state.director.directive_fact})
                self.speculative = {norm(txt): asyncio.create_task(self._first_sentences(inp))}
        elif type_ == "operator.final":
            await self.operator_final(payload.get("text", "").strip(), int(payload.get("duration_ms") or 0), source)
        elif type_ == "operator.speech_end":
            await self.emit("operator.speech_end", source, {})
        elif type_ == "tts.playing":
            await self.emit("tts.playing", "client", {"uid": payload.get("uid")})
            if payload.get("latency_ms"):
                self.metrics.e2e(float(payload["latency_ms"]))
        elif type_ == "tts.stopped":
            await self.emit("tts.stopped", "client", {"uid": payload.get("uid"),
                                                      "played_chars": payload.get("played_chars")})
            self.director.caller_end_t = now
        elif type_ == "card.updated":
            await self.emit("card.updated", source if source in ("operator_ui", "bot") else "operator_ui",
                            {"fields": payload.get("fields", {})})
        elif type_ == "operator.action":
            aid = payload.get("action")
            if aid in ACTIONS and aid not in self.state.actions:
                src = source if source in ("operator_ui", "bot") else "operator_ui"
                await self.emit("operator.action", src, {"action": aid})
                for m in self.evaluator.on_action(self.state, aid, now):
                    await self.emit("checklist.step", "evaluator", m)
        elif type_ == "instructor.command":
            await self.emit("instructor.command", "instructor", payload)
            self.store.audit(payload.get("by", "instructor"), "instructor.command",
                             {"call_id": self.call_id, **payload})
            await self._process(self.director.command(self.state.snapshot(), payload.get("cmd", ""),
                                                      payload.get("arg"), now))
        elif type_ == "call.end":
            await self.finish(payload.get("reason", "operator"))

    async def barge_in(self) -> None:
        """Правило 4.3.1: оператор перебив абонента — зупинити TTS і скасувати генерацію."""
        self.op_seq += 1
        self._cancel_caller()
        uid = self.state.tts_playing
        await self.emit("tts.stop", "orchestrator", {"uid": uid, "reason": "barge_in"})
        if self.sim:
            # у симуляції рахуємо, скільки встигло прозвучати
            last = next((u for u in reversed(self.state.transcript) if u.who == "caller"), None)
            if last:
                played = max(0, int((self.clock.now() - last.t - 400) / 55))
                await self.emit("tts.stopped", "orchestrator", {"uid": last.id, "played_chars": played})
            self.caller_speaking_until = self.clock.now()
        await self.emit("speech.metric", "speech", self.speech.on_interrupt())
        self.director.caller_end_t = self.clock.now()

    async def operator_final(self, text: str, duration_ms: int, source: str) -> None:
        if not text:
            return
        self.op_seq += 1
        self.final_perf = time.perf_counter()
        now = self.clock.now()
        start = self.op_speech_start if self.op_speech_start is not None else now - (duration_ms or 0)
        self.op_speech_start = None
        delay = max(0, start - max(self.director.caller_end_t, self.state.last_operator_t))
        uid = "o" + uuid.uuid4().hex[:8]
        src = source if source in ("asr", "operator_ui", "bot") else "operator_ui"
        await self.emit("operator.final", src, {"text": text, "uid": uid, "duration_ms": duration_ms})
        u = self.state.transcript[-1]
        # нормалізатор — синхронно, у гарячому шляху
        with self.metrics.stage("normalizer"):
            ents = self.normalizer.run(text, "operator", self.state.entities)
        if "address" in ents:
            prev = self.state.entities.get("address") or {}
            if ents["address"].get("confirmed"):
                ents["address"]["confirmed_uid"] = uid
            elif prev.get("confirmed"):
                ents.pop("address")             # підтвердження «липке»
        if ents:
            await self.emit("entities.updated", "normalizer", {"entities": ents})
        dur = duration_ms or len(words(text)) * 380
        await self.emit("speech.metric", "speech", self.speech.on_operator(text, dur, delay, now))
        await self._process(self.director.on_operator(self.state.snapshot(), text, now, delay))
        # холодний контур: запустити і НЕ чекати
        task = asyncio.create_task(self._evaluate(self.state.snapshot(), u, time.perf_counter()))
        self.cold.add(task)
        task.add_done_callback(self.cold.discard)
        # гарячий контур: скасувати стару відповідь, почати нову
        self._speak({"fact": self.state.director.directive_fact}, text)

    async def _evaluate(self, snap: CallState, u: Utterance, t0: float) -> None:
        self.metrics.cold_enter()
        try:
            marks = self.evaluator.on_utterance(snap, u)
            marks += await self.evaluator.semantic(snap, u, self.prep.steps)
            for m in marks:
                if not self.state.checklist.get(m["step_id"]):
                    await self.emit("checklist.step", "evaluator", m)
            soft = await self.director.soft_decision(snap, u.text)
            if soft:
                await self._process([Out("caller.emotion", {
                    "panic": self.state.caller.panic + float(soft.get("panic_delta", 0)),
                    "trust": self.state.caller.trust + float(soft.get("trust_delta", 0)),
                    "reason": "LLM: " + str(soft.get("reason", ""))})])
        finally:
            self.metrics.cold_exit((time.perf_counter() - t0) * 1000)

    async def wait_caller(self) -> None:
        """Для симуляції: дочекатися, поки абонент договорить (і холодний контур)."""
        for _ in range(5):
            t = self.caller_task
            if t and not t.done():
                try:
                    await t
                except asyncio.CancelledError:
                    pass
            if self.cold:
                await asyncio.gather(*list(self.cold), return_exceptions=True)
            if self.caller_task is t:
                break

    # --- завершення і розбір --------------------------------------------
    async def finish(self, reason: str) -> Optional[dict[str, Any]]:
        if self.finished:
            return self.report
        self.finished = True
        self._cancel_caller()
        if self.tick_task and asyncio.current_task() is not self.tick_task:
            self.tick_task.cancel()
        await self.emit("call.end", "orchestrator", {"reason": reason})
        if self.cold:
            await asyncio.wait(list(self.cold), timeout=10)
        final = self.evaluator.final_pass(self.state)
        events = self.store.events(self.call_id)
        rep = self.reporter.build(self.state, final, events, self.speech.pauses, self.metrics.snapshot()["hot"])
        rep = await self.reporter.polish(rep)
        self.report = rep
        self.store.finish_session(self.call_id, rep)
        await self.emit("phase.changed", "orchestrator", {"phase": "debrief"})
        await self.emit("report.ready", "reporter", {"score": rep["score"], "passed": rep["passed"]})
        self.done.set()
        return rep


async def _aiter(items: list[Sentence]):
    for s in items:
        yield s
