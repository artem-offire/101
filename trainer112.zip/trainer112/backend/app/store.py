"""Журнал подій і довгострокові дані (SQLite у прототипі, PostgreSQL у проді).

Таблиці: events (журнал усіх подій дзвінка, з нього звіт, аудит і реплей),
sessions, assignments, calibrations, users, audit.
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Optional

from .models import Event

SCHEMA = """
CREATE TABLE IF NOT EXISTS events(
  id TEXT PRIMARY KEY, call_id TEXT, t INTEGER, type TEXT, source TEXT, payload TEXT, wall REAL);
CREATE INDEX IF NOT EXISTS ev_call ON events(call_id, t);
CREATE TABLE IF NOT EXISTS sessions(
  id TEXT PRIMARY KEY, trainee TEXT, scenario_id TEXT, branch TEXT, seed INTEGER, difficulty INTEGER,
  status TEXT, created REAL, ended REAL, score REAL, passed INTEGER, report TEXT, assignment_id TEXT,
  options TEXT, parent_id TEXT, from_t INTEGER);
CREATE TABLE IF NOT EXISTS assignments(
  id TEXT PRIMARY KEY, trainee TEXT, scenario_id TEXT, difficulty INTEGER, due TEXT, note TEXT,
  created_by TEXT, created REAL, status TEXT, session_id TEXT);
CREATE TABLE IF NOT EXISTS calibrations(
  session_id TEXT, step_id TEXT, system_done INTEGER, instructor_done INTEGER, comment TEXT,
  instructor TEXT, created REAL, PRIMARY KEY(session_id, step_id));
CREATE TABLE IF NOT EXISTS users(name TEXT PRIMARY KEY, role TEXT, created REAL);
CREATE TABLE IF NOT EXISTS audit(ts REAL, actor TEXT, action TEXT, details TEXT);
"""


class Store:
    def __init__(self, path: str | Path = ":memory:") -> None:
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.lock = threading.Lock()
        with self.lock:
            self.db.executescript(SCHEMA)
            self.db.commit()

    # --- журнал -------------------------------------------------------
    def append_event(self, ev: Event) -> None:
        with self.lock:
            self.db.execute("INSERT OR IGNORE INTO events VALUES(?,?,?,?,?,?,?)",
                            (ev.id, ev.call_id, ev.t, ev.type, ev.source,
                             json.dumps(ev.payload, ensure_ascii=False), ev.wall))
            self.db.commit()

    def events(self, call_id: str) -> list[Event]:
        with self.lock:
            rows = self.db.execute("SELECT * FROM events WHERE call_id=? ORDER BY t, wall", (call_id,)).fetchall()
        return [Event(id=r["id"], call_id=r["call_id"], t=r["t"], type=r["type"], source=r["source"],
                      payload=json.loads(r["payload"]), wall=r["wall"]) for r in rows]

    # --- сесії --------------------------------------------------------
    def create_session(self, **kw: Any) -> None:
        cols = ["id", "trainee", "scenario_id", "branch", "seed", "difficulty", "status", "created",
                "assignment_id", "options", "parent_id", "from_t"]
        kw.setdefault("created", time.time())
        kw.setdefault("status", "live")
        kw["options"] = json.dumps(kw.get("options") or {}, ensure_ascii=False)
        with self.lock:
            self.db.execute(f"INSERT INTO sessions({','.join(cols)}) VALUES({','.join('?' * len(cols))})",
                            [kw.get(c) for c in cols])
            self.db.commit()

    def finish_session(self, sid: str, report: dict[str, Any]) -> None:
        with self.lock:
            self.db.execute("UPDATE sessions SET status='done', ended=?, score=?, passed=?, report=? WHERE id=?",
                            (time.time(), report.get("score"), int(bool(report.get("passed"))),
                             json.dumps(report, ensure_ascii=False), sid))
            self.db.execute("UPDATE assignments SET status='done' WHERE session_id=?", (sid,))
            self.db.commit()

    def update_report(self, sid: str, report: dict[str, Any]) -> None:
        with self.lock:
            self.db.execute("UPDATE sessions SET report=?, score=?, passed=? WHERE id=?",
                            (json.dumps(report, ensure_ascii=False), report.get("score"),
                             int(bool(report.get("passed"))), sid))
            self.db.commit()

    def session(self, sid: str) -> Optional[dict[str, Any]]:
        with self.lock:
            r = self.db.execute("SELECT * FROM sessions WHERE id=?", (sid,)).fetchone()
        return _sess(r) if r else None

    def sessions(self, trainee: Optional[str] = None, limit: int = 200) -> list[dict[str, Any]]:
        q = "SELECT * FROM sessions"
        args: list[Any] = []
        if trainee:
            q += " WHERE trainee=?"
            args.append(trainee)
        q += " ORDER BY created DESC LIMIT ?"
        args.append(limit)
        with self.lock:
            rows = self.db.execute(q, args).fetchall()
        return [_sess(r, brief=True) for r in rows]

    # --- призначення --------------------------------------------------
    def add_assignment(self, **kw: Any) -> None:
        cols = ["id", "trainee", "scenario_id", "difficulty", "due", "note", "created_by", "created", "status"]
        kw.setdefault("created", time.time())
        kw.setdefault("status", "assigned")
        with self.lock:
            self.db.execute(f"INSERT INTO assignments({','.join(cols)}) VALUES({','.join('?' * len(cols))})",
                            [kw.get(c) for c in cols])
            self.db.commit()

    def assignments(self, trainee: Optional[str] = None) -> list[dict[str, Any]]:
        q, args = "SELECT * FROM assignments", []
        if trainee:
            q += " WHERE trainee=?"
            args.append(trainee)
        q += " ORDER BY created DESC"
        with self.lock:
            return [dict(r) for r in self.db.execute(q, args).fetchall()]

    def link_assignment(self, aid: str, sid: str) -> None:
        with self.lock:
            self.db.execute("UPDATE assignments SET status='in_progress', session_id=? WHERE id=?", (sid, aid))
            self.db.commit()

    # --- калібрування -------------------------------------------------
    def calibrate(self, sid: str, step_id: str, system_done: bool, instructor_done: bool,
                  comment: str, instructor: str) -> None:
        with self.lock:
            self.db.execute("INSERT OR REPLACE INTO calibrations VALUES(?,?,?,?,?,?,?)",
                            (sid, step_id, int(system_done), int(instructor_done), comment, instructor, time.time()))
            self.db.commit()

    def calibrations(self, sid: Optional[str] = None) -> list[dict[str, Any]]:
        q, args = "SELECT * FROM calibrations", []
        if sid:
            q += " WHERE session_id=?"
            args.append(sid)
        with self.lock:
            return [dict(r) for r in self.db.execute(q, args).fetchall()]

    # --- користувачі та аудит -----------------------------------------
    def upsert_user(self, name: str, role: str) -> None:
        with self.lock:
            self.db.execute("INSERT OR REPLACE INTO users VALUES(?,?,?)", (name, role, time.time()))
            self.db.commit()

    def users(self, role: Optional[str] = None) -> list[dict[str, Any]]:
        q, args = "SELECT * FROM users", []
        if role:
            q += " WHERE role=?"
            args.append(role)
        with self.lock:
            return [dict(r) for r in self.db.execute(q + " ORDER BY name", args).fetchall()]

    def audit(self, actor: str, action: str, details: dict[str, Any] | None = None) -> None:
        with self.lock:
            self.db.execute("INSERT INTO audit VALUES(?,?,?,?)",
                            (time.time(), actor, action, json.dumps(details or {}, ensure_ascii=False)))
            self.db.commit()

    def audit_log(self, limit: int = 200) -> list[dict[str, Any]]:
        with self.lock:
            rows = self.db.execute("SELECT * FROM audit ORDER BY ts DESC LIMIT ?", (limit,)).fetchall()
        return [{**dict(r), "details": json.loads(r["details"])} for r in rows]


def _sess(r: sqlite3.Row, brief: bool = False) -> dict[str, Any]:
    d = dict(r)
    d["options"] = json.loads(d.get("options") or "{}")
    rep = json.loads(d["report"]) if d.get("report") else None
    if brief:
        d.pop("report", None)
        if rep:
            d["summary"] = {"score": rep.get("score"), "passed": rep.get("passed"),
                            "missed_critical": rep.get("missed_critical", []),
                            "time_to": rep.get("time_to", {}), "scenario_title": rep.get("scenario_title")}
    else:
        d["report"] = rep
    return d
