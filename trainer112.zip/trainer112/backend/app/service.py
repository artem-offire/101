"""Сервісний шар: бібліотека сценаріїв, журнал, шина й активні дзвінки."""
from __future__ import annotations

import asyncio
import os
import random
import uuid
from pathlib import Path
from typing import Any, Optional

from .bus import EventBus
from .metrics import METRICS
from .orchestrator import CallOrchestrator, RealClock, SimClock
from .scenarios import Library, prepare
from .store import Store

DATA = Path(os.environ.get("TRAINER_DATA", Path(__file__).resolve().parents[2] / "data"))


class Trainer:
    def __init__(self, db_path: Optional[str] = None, library: Optional[Library] = None) -> None:
        self.store = Store(db_path or str(DATA / "trainer.db"))
        self.library = library or Library()
        self.bus = EventBus()
        self.bus.add_sink(lambda ev: None if ev.type.startswith("calls.") else self.store.append_event(ev))
        self.calls: dict[str, CallOrchestrator] = {}
        self.meta: dict[str, dict[str, Any]] = {}

    async def start_call(self, trainee: str, scenario_id: str, level: Optional[int] = None,
                         seed: Optional[int] = None, branch: Optional[str] = None,
                         options: Optional[dict[str, Any]] = None, assignment_id: Optional[str] = None,
                         sim: bool = False, from_session: Optional[str] = None,
                         from_t: Optional[int] = None, autostart: bool = True,
                         category: Optional[str] = None) -> CallOrchestrator:
        history = None
        if from_session:
            parent = self.store.session(from_session)
            if not parent:
                raise KeyError(from_session)
            scenario_id = parent["scenario_id"]
            seed, branch, level = parent["seed"], parent["branch"], parent["difficulty"]
            history = self.store.events(from_session)
        if scenario_id == "random":
            # «Будь-яка ситуація»: сервер сам обирає сценарій; курсант його назву до кінця дзвінка не бачить
            pool = sorted(sid for sid, s0 in self.library.items.items() if not category or s0.category == category)
            if not pool:
                raise KeyError("random")
            scenario_id = random.choice(pool)
            options = {**(options or {}), "blind": True}
        sc = self.library.get(scenario_id)
        seed = seed if seed is not None else random.randint(1000, 99999)
        prep = prepare(sc, seed, level, branch)
        call_id = "c-" + uuid.uuid4().hex[:8]
        clock = SimClock(from_t or 0) if sim else RealClock(from_t or 0)
        opts = {"show_indicators": True, "adaptive": True, **(options or {})}
        orch = CallOrchestrator(call_id, prep, self.bus, self.store, clock, opts, METRICS, history, from_t)
        self.store.create_session(id=call_id, trainee=trainee, scenario_id=sc.id, branch=prep.branch, seed=seed,
                                  difficulty=level or sc.difficulty, assignment_id=assignment_id, options=opts,
                                  parent_id=from_session, from_t=from_t)
        if assignment_id:
            self.store.link_assignment(assignment_id, call_id)
        self.store.audit(trainee, "call.start", {"call_id": call_id, "scenario": sc.id, "sim": sim})
        self.calls[call_id] = orch
        self.meta[call_id] = {"trainee": trainee, "scenario_id": sc.id, "title": sc.title, "sim": sim,
                              "level": level or sc.difficulty}
        await self.bus.publish("calls", _calls_event(call_id, "started", self.meta[call_id]))
        if autostart or sim:
            await orch.start()
        asyncio.get_running_loop().create_task(self._reap(call_id))
        return orch

    async def _reap(self, call_id: str) -> None:
        orch = self.calls.get(call_id)
        if not orch:
            return
        await orch.done.wait()
        await self.bus.publish("calls", _calls_event(call_id, "ended", self.meta.get(call_id, {})))
        await asyncio.sleep(30)
        self.calls.pop(call_id, None)

    def active(self) -> list[dict[str, Any]]:
        out = []
        for cid, o in self.calls.items():
            if o.finished or self.meta.get(cid, {}).get("sim"):
                continue
            st = o.state
            done = sum(1 for v in st.checklist.values() if v)
            out.append({"call_id": cid, **self.meta[cid], "t": o.clock.now() if o.started else 0,
                        "started": o.started, "panic": st.caller.panic,
                        "trust": st.caller.trust, "steps_done": done, "steps_total": len(st.checklist)})
        return out


def _calls_event(call_id: str, kind: str, meta: dict[str, Any]):
    from .models import Event
    return Event(call_id=call_id, t=0, type=f"calls.{kind}", source="orchestrator", payload=meta)
