"""Шина подій: один канал на дзвінок (`call.<id>`) + глобальний канал `calls`.

У прототипі це in-memory pub/sub на asyncio.Queue. Інтерфейс (publish/subscribe)
збігається з тим, що дадуть Redis Streams або NATS, тож заміна локальна.
"""
from __future__ import annotations

import asyncio
from collections import defaultdict
from typing import AsyncIterator, Callable

from .models import Event


class EventBus:
    def __init__(self) -> None:
        self._subs: dict[str, list[asyncio.Queue]] = defaultdict(list)
        self._sinks: list[Callable[[Event], None]] = []

    def add_sink(self, fn: Callable[[Event], None]) -> None:
        """Синхронний споживач усіх подій (журнал, метрики)."""
        self._sinks.append(fn)

    async def publish(self, channel: str, ev: Event) -> None:
        for s in self._sinks:
            s(ev)
        for q in list(self._subs.get(channel, [])):
            q.put_nowait(ev)

    def publish_nowait(self, channel: str, ev: Event) -> None:
        for s in self._sinks:
            s(ev)
        for q in list(self._subs.get(channel, [])):
            q.put_nowait(ev)

    def queue(self, channel: str) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue()
        self._subs[channel].append(q)
        return q

    def unsubscribe(self, channel: str, q: asyncio.Queue) -> None:
        if q in self._subs.get(channel, []):
            self._subs[channel].remove(q)

    async def subscribe(self, channel: str) -> AsyncIterator[Event]:
        q = self.queue(channel)
        try:
            while True:
                yield await q.get()
        finally:
            self.unsubscribe(channel, q)
