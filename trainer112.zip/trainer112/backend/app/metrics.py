"""Спостережуваність (крок 8): затримки гарячого контуру, Сторож, черга холодного контуру.

Легка in-process реалізація. Якщо встановлено opentelemetry, кожен етап також
пишеться як span (див. `stage`).
"""
from __future__ import annotations

import contextlib
import time
from collections import defaultdict, deque
from typing import Any, Iterator

try:  # необов'язково
    from opentelemetry import trace as _otel  # type: ignore
    _tracer = _otel.get_tracer("trainer112")
except Exception:  # pragma: no cover
    _tracer = None


def _pct(vals: list[float], p: float) -> float:
    if not vals:
        return 0.0
    s = sorted(vals)
    k = min(len(s) - 1, max(0, int(round(p / 100 * (len(s) - 1)))))
    return round(s[k], 1)


class Metrics:
    def __init__(self) -> None:
        self.stages: dict[str, deque] = defaultdict(lambda: deque(maxlen=2000))
        self.hot_latency: deque = deque(maxlen=2000)          # сервер: operator.final -> перше речення
        self.e2e_latency: deque = deque(maxlen=2000)          # клієнт: кінець фрази -> перший звук
        self.series: deque = deque(maxlen=600)
        self.guard = {"approved": 0, "blocked": 0}
        self.guard_reasons: dict[str, int] = defaultdict(int)
        self.cold_queue = 0
        self.cold_queue_max = 0
        self.cold_lag: deque = deque(maxlen=2000)

    @contextlib.contextmanager
    def stage(self, name: str, **attrs: Any) -> Iterator[None]:
        t0 = time.perf_counter()
        span = _tracer.start_as_current_span(name) if _tracer else contextlib.nullcontext()
        with span:
            try:
                yield
            finally:
                self.stages[name].append((time.perf_counter() - t0) * 1000)

    def hot(self, ms: float) -> None:
        self.hot_latency.append(ms)
        self.series.append({"ts": time.time(), "hot_ms": round(ms, 1), "cold_queue": self.cold_queue})

    def e2e(self, ms: float) -> None:
        self.e2e_latency.append(ms)

    def guard_result(self, ok: bool, reason: str = "") -> None:
        self.guard["approved" if ok else "blocked"] += 1
        if not ok:
            self.guard_reasons[reason] += 1

    def cold_enter(self) -> None:
        self.cold_queue += 1
        self.cold_queue_max = max(self.cold_queue_max, self.cold_queue)

    def cold_exit(self, lag_ms: float) -> None:
        self.cold_queue -= 1
        self.cold_lag.append(lag_ms)

    def snapshot(self) -> dict[str, Any]:
        hot, e2e = list(self.hot_latency), list(self.e2e_latency)
        tot = self.guard["approved"] + self.guard["blocked"]
        return {
            "hot": {"p50": _pct(hot, 50), "p90": _pct(hot, 90), "n": len(hot)},
            "e2e": {"p50": _pct(e2e, 50), "p90": _pct(e2e, 90), "n": len(e2e), "target_ms": 1200},
            "stages": {k: {"p50": _pct(list(v), 50), "p90": _pct(list(v), 90), "n": len(v)}
                       for k, v in self.stages.items()},
            "guard": {**self.guard, "blocked_share": round(self.guard["blocked"] / tot, 4) if tot else 0,
                      "reasons": dict(self.guard_reasons)},
            "cold": {"queue": self.cold_queue, "queue_max": self.cold_queue_max,
                     "lag_p90": _pct(list(self.cold_lag), 90)},
            "series": list(self.series)[-120:],
        }


METRICS = Metrics()
