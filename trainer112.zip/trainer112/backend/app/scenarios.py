"""Завантаження, валідація і підготовка сценаріїв (фаза «Підготовка», розділ 2.1)."""
from __future__ import annotations

import json
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import yaml
from pydantic import ValidationError

from .models import ACTIONS, Fact, PlotEvent, Protocol, ProtocolStep, Scenario, merge_fact

ROOT = Path(__file__).resolve().parents[2]
SCENARIO_DIR = ROOT / "scenarios"
PROTOCOL_DIR = ROOT / "protocols"


class ScenarioError(Exception):
    def __init__(self, errors: list[str]):
        super().__init__("; ".join(errors))
        self.errors = errors


def load_base_protocol(name: str) -> list[ProtocolStep]:
    path = PROTOCOL_DIR / f"{name}.yaml"
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    return [ProtocolStep(**s) for s in data["steps"]]


def resolve_steps(protocol: Protocol) -> list[ProtocolStep]:
    steps: dict[str, ProtocolStep] = {}
    if protocol.base:
        for s in load_base_protocol(protocol.base):
            steps[s.id] = s
    for s in protocol.steps:
        sid = s.get("id")
        if not sid:
            raise ValueError("крок без id")
        if sid in steps:
            steps[sid] = ProtocolStep(**{**steps[sid].model_dump(), **s})
        else:
            steps[sid] = ProtocolStep(**s)
    for r in protocol.remove:
        steps.pop(r, None)
    return sorted(steps.values(), key=lambda s: s.order)


def parse_scenario(data: dict[str, Any]) -> Scenario:
    """Валідація за схемою + семантичні перевірки. Кидає ScenarioError зі списком помилок."""
    errors: list[str] = []
    try:
        sc = Scenario(**data)
    except ValidationError as e:
        for err in e.errors():
            loc = ".".join(str(x) for x in err["loc"])
            errors.append(f"{loc}: {err['msg']}")
        raise ScenarioError(errors)
    try:
        steps = resolve_steps(sc.protocol)
    except Exception as e:  # noqa: BLE001
        raise ScenarioError([f"protocol: {e}"])
    ids = {s.id for s in steps}
    if not any(s.critical for s in steps):
        errors.append("protocol: потрібен хоча б один критичний крок")
    for s in steps:
        if not s.source:
            errors.append(f"protocol.{s.id}: не вказано джерело (source)")
    for s in steps:
        r = s.rule
        if not (r.keywords or r.all_groups or r.intent or r.entity_confirmed or r.semantic
                or r.action or r.card_fields):
            errors.append(f"protocol.{s.id}: правило порожнє")
        if r.action and r.action not in ACTIONS:
            errors.append(f"protocol.{s.id}: невідома дія")
    all_events = list(sc.events) + list(sc.complications) + [e for b in sc.branches for e in b.events]
    for e in all_events:
        for k in (e.trigger.unless_step, e.trigger.if_step):
            if k and k not in ids:
                errors.append(f"подія {e.id}: крок {k} не існує в протоколі")
    if errors:
        raise ScenarioError(errors)
    return sc


def scenario_schema() -> dict[str, Any]:
    return Scenario.model_json_schema()


class Library:
    def __init__(self, directory: Path = SCENARIO_DIR) -> None:
        self.dir = directory
        self.items: dict[str, Scenario] = {}
        self.errors: dict[str, list[str]] = {}
        self.reload()

    def reload(self) -> None:
        self.items.clear()
        self.errors.clear()
        for p in sorted(self.dir.glob("*.yaml")):
            try:
                data = yaml.safe_load(p.read_text(encoding="utf-8"))
                sc = parse_scenario(data)
                self.items[sc.id] = sc
            except ScenarioError as e:
                self.errors[p.stem] = e.errors
            except yaml.YAMLError as e:
                self.errors[p.stem] = [f"YAML: {e}"]

    def get(self, sid: str) -> Scenario:
        return self.items[sid]

    def save(self, text: str) -> Scenario:
        data = yaml.safe_load(text)
        sc = parse_scenario(data)
        (self.dir / f"{sc.id}.yaml").write_text(text, encoding="utf-8")
        self.items[sc.id] = sc
        self.errors.pop(sc.id, None)
        return sc

    def raw(self, sid: str) -> str:
        return (self.dir / f"{sid}.yaml").read_text(encoding="utf-8")

    def summary(self) -> list[dict[str, Any]]:
        out = []
        for sc in self.items.values():
            steps = resolve_steps(sc.protocol)
            out.append({
                "id": sc.id, "title": sc.title, "category": sc.category, "difficulty": sc.difficulty,
                "brief": sc.brief, "branches": [b.id for b in sc.branches],
                "steps": len(steps), "critical": [s.title for s in steps if s.critical],
                "skills": sc.skills, "voice": sc.legend.voice, "valid": True,
            })
        for sid, errs in self.errors.items():
            out.append({"id": sid, "title": sid, "valid": False, "errors": errs})
        return out


DIFFICULTY = {1: 0.3, 2: 0.6, 3: 0.9}


@dataclass
class Prepared:
    scenario: Scenario
    branch: str
    seed: int
    difficulty: float
    facts: dict[str, Fact]
    events: list[PlotEvent]
    complications: list[PlotEvent]
    steps: list[ProtocolStep]
    initial: dict[str, float]
    voice: str
    rng: random.Random = field(repr=False, default_factory=random.Random)

    def step(self, sid: str) -> Optional[ProtocolStep]:
        return next((s for s in self.steps if s.id == sid), None)

    def event(self, eid: str) -> Optional[PlotEvent]:
        return next((e for e in self.events + self.complications if e.id == eid), None)


def prepare(sc: Scenario, seed: int, level: Optional[int] = None, branch: Optional[str] = None) -> Prepared:
    """Режисер: обрати гілку, голос і стартові емоції з фіксованим seed (відтворюваність)."""
    rng = random.Random(seed)
    if branch:
        br = next(b for b in sc.branches if b.id == branch)
    else:
        br = rng.choices(sc.branches, weights=[b.weight for b in sc.branches])[0]
    facts = {f.id: f for f in sc.facts}
    for fid, ov in br.facts.items():
        facts[fid] = merge_fact(facts[fid], ov)
    # гілка може змінити правду для картки (наприклад, no_person: victims 0) — порівнюємо з нею
    br_truth = {k: v for fid in br.facts for k, v in (facts[fid].truth or {}).items() if k in sc.card_truth}
    if br_truth:
        sc = sc.model_copy(update={"card_truth": {**sc.card_truth, **br_truth}})
    level = level or sc.difficulty
    diff = DIFFICULTY.get(level, 0.6)
    init = {**sc.initial, **br.initial}
    panic = init.get("panic", 6) + (diff - 0.6) * 4 + rng.uniform(-0.5, 0.5)
    trust = init.get("trust", 4) - (diff - 0.6) * 3
    return Prepared(
        scenario=sc, branch=br.id, seed=seed, difficulty=diff, facts=facts,
        events=list(sc.events) + list(br.events), complications=list(sc.complications),
        steps=resolve_steps(sc.protocol),
        initial={"panic": round(max(0, min(10, panic)), 1), "trust": round(max(0, min(10, trust)), 1)},
        voice=sc.legend.voice, rng=rng,
    )


def layer_view(sc: Scenario, layer: str) -> dict[str, Any]:
    """Кожен агент бачить лише свій шар (розділ 2.2)."""
    d = json.loads(sc.model_dump_json())
    if layer == "caller":
        return {"legend": d["legend"], "facts": d["facts"]}
    if layer == "director":
        return {"facts": d["facts"], "events": d["events"], "complications": d["complications"],
                "branches": d["branches"], "silence_threshold_s": d["silence_threshold_s"]}
    if layer == "evaluator":
        return {"protocol": [s.model_dump() for s in resolve_steps(sc.protocol)], "card_truth": d["card_truth"]}
    raise KeyError(layer)
