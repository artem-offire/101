"""Збирає trainer112.html: один файл, що відкривається подвійним кліком, без сервера.

Усе вбудовано: стилі, шрифти, інтерфейс, Python-бекенд, сценарії і протокол.
Python виконується в браузері через Pyodide (з CDN, потрібен інтернет при першому запуску).

    python tools/build_standalone.py            # → trainer112.html у корені проєкту
Потрібен Node.js (npx esbuild) для збирання JS-модулів в один скрипт.
"""
from __future__ import annotations

import base64
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FRONT = ROOT / "frontend"
OUT = ROOT / "trainer112.html"

BOOT_CSS = """
.boot { position: fixed; inset: 0; z-index: 100; display: grid; place-items: center; background: var(--bg);
  transition: opacity var(--t-base) var(--ease-out); }
.boot.leaving { opacity: 0; }
.boot-card { display: flex; flex-direction: column; align-items: center; gap: var(--s-3); text-align: center;
  width: min(420px, calc(100vw - 32px)); font-size: var(--fs-md); }
.boot-card b { font-size: var(--fs-lg); }
.boot-bar { width: 100%; height: 6px; border-radius: 3px; background: var(--surface-2); overflow: hidden; margin-top: var(--s-2); }
.boot-bar i { display: block; height: 100%; background: var(--brand-solid); transform: scaleX(0); transform-origin: left;
  transition: transform var(--t-slow) var(--ease-out); }
.boot-msg { color: var(--text); }
.boot-note { color: var(--muted); font-size: var(--fs-sm); }
.boot.failed .boot-bar { display: none; }
.boot.failed .boot-msg { color: var(--danger); }
"""


def bundle_js() -> str:
    npx = "npx.cmd" if sys.platform == "win32" else "npx"
    r = subprocess.run([npx, "--yes", "esbuild", str(FRONT / "js" / "app.js"), "--bundle", "--format=iife",
                        "--target=es2020", "--minify"], capture_output=True, text=True, encoding="utf-8")
    if r.returncode:
        sys.exit(r.stderr)
    return r.stdout


def inline_css() -> str:
    fonts = (FRONT / "fonts" / "fonts.css").read_text(encoding="utf-8")

    def data_uri(m: re.Match) -> str:
        f = FRONT / "fonts" / Path(m.group(1)).name
        return f'url("data:font/woff2;base64,{base64.b64encode(f.read_bytes()).decode()}")'
    fonts = re.sub(r'url\(["\']?([^"\')]+\.woff2)["\']?\)', data_uri, fonts)
    css = (FRONT / "styles.css").read_text(encoding="utf-8")
    css = re.sub(r'@import url\(["\']?/static/fonts/fonts\.css["\']?\);', lambda _: fonts, css)
    return css + BOOT_CSS


def backend_files() -> dict[str, str]:
    out = {}
    globs = [("backend/app", "**/*.py"), ("scenarios", "*.yaml"), ("protocols", "*.yaml"), ("standalone/py", "**/*.py")]
    for base, pat in globs:
        for f in sorted((ROOT / base).glob(pat)):
            if "__pycache__" in f.parts:
                continue
            out[f.relative_to(ROOT).as_posix()] = f.read_text(encoding="utf-8")
    return out


def safe(s: str) -> str:
    return s.replace("</script", "<\\/script").replace("<!--", "<\\!--")


def main() -> None:
    html = (FRONT / "index.html").read_text(encoding="utf-8")
    html = re.sub(r'\s*<link rel="preload"[^>]*>', "", html)
    html = html.replace('<link rel="stylesheet" href="/static/styles.css">', f"<style>{inline_css()}</style>")
    files = json.dumps(backend_files(), ensure_ascii=False)
    scripts = (f"<script>window.__T112_FILES = {safe(files)};</script>\n"
               f"<script>{safe((ROOT / 'standalone' / 'boot.js').read_text(encoding='utf-8'))}</script>\n"
               f"<script>{safe(bundle_js())}</script>")
    html = html.replace('<script type="module" src="/static/js/app.js"></script>', scripts)
    OUT.write_text(html, encoding="utf-8")
    print(f"{OUT} · {OUT.stat().st_size / 1024:.0f} КБ")


if __name__ == "__main__":
    main()
