# Редизайн у стилі Airbnb: як реалізувати в коді

Специфікація для переходу від поточного «темного дашборда» до світлого, спокійного стилю Airbnb.
Стек не змінюється: чистий JS без збірки, один `frontend/styles.css` з шарами, розмітка через `h()` з `core.js`.

**Головне правило.** Повний стиль Airbnb отримують вхід, бібліотека, звіт, кабінет і пульт.
Екран виклику бере нові токени (кольори, радіуси, шрифт), але лишається щільним: там людина працює в стресі,
і повітря та великі картки заважатимуть.

**Порядок робіт:**

1. Виправити баги (крок 1). Вони не залежать від стилю, і їх треба закрити першими.
2. Замінити токени (крок 2). Після цього весь застосунок одразу виглядає інакше.
3. Переписати базові компоненти (крок 3).
4. Переробити екрани по одному (крок 4).
5. Перезібрати standalone і оновити документацію (крок 5).

Кожен крок можна комітити окремо, і після кожного застосунок працює.

---

## Крок 1. Баги

### 1.1. Тема не стежить за системою

**Що сталося.** [DESIGN.md](DESIGN.md) обіцяє `prefers-color-scheme`, але у [styles.css](frontend/styles.css) такого правила немає.
`:root` завжди темний, а `theme.isDark()` у `core.js` дивиться на систему. Тому при світлій системі показується темна тема,
а перший клік по перемикачу записує `"dark"` і нічого не змінює.

**Рішення.** Атрибут `data-theme` на `<html>` стоїть завжди, а CSS знає лише два стани: `:root` (світла, нова
тема за замовчуванням) і `:root[data-theme="dark"]`. Яку тему ставити, вирішує JS: збережений вибір, інакше система.

`frontend/index.html`, рядок 7. Замінити скрипт, щоб тема ставилася ще до першого кадру:

```html
<script>try{var t=localStorage.getItem("t112.theme");document.documentElement.dataset.theme=t||(matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light")}catch(e){}</script>
```

`frontend/js/core.js`. Замінити об'єкт `theme`:

```js
const THEME_KEY = "t112.theme";
const sysDark = matchMedia("(prefers-color-scheme: dark)");
export const theme = {
  stored() { try { return localStorage.getItem(THEME_KEY); } catch { return null; } },
  current() { return this.stored() || (sysDark.matches ? "dark" : "light"); },
  isDark() { return this.current() === "dark"; },
  apply() { document.documentElement.dataset.theme = this.current(); },
  toggle() {
    try { localStorage.setItem(THEME_KEY, this.isDark() ? "light" : "dark"); } catch { /* */ }
    this.apply();
  },
  // поки користувач нічого не обрав, тема йде за системою
  watch(onChange) {
    sysDark.addEventListener("change", () => { if (!this.stored()) { this.apply(); onChange?.(); } });
  },
};
```

`frontend/js/app.js`, `themeButton()`. Підписати іконку кнопки на зміну системної теми:

```js
function themeButton() {
  const b = h("button.btn.ghost.icon.theme-toggle", { type: "button", on: { click: () => { theme.toggle(); sync(); } } });
  const sync = () => {
    const dark = theme.isDark();
    b.innerHTML = icon[dark ? "sun" : "moon"];
    b.title = dark ? "Увімкнути світлу тему" : "Увімкнути темну тему";
    b.setAttribute("aria-label", b.title);
  };
  theme.watch(sync);
  sync();
  return b;
}
```

`themeButton()` викликається при кожному `renderTop`, тому слухачі накопичуватимуться. Щоб цього уникнути, викличте
`theme.watch(() => renderTop(session.get()))` один раз поруч із `theme.apply()` на початку `app.js`, а з `themeButton()` виклик `watch` приберіть.

Графіки (`charts.js`) читають кольори через `tok()` у момент малювання. Після перемикання теми відкритий графік
лишиться в старих кольорах. Найпростіше рішення: у `toggle` і `watch` після `apply()` викликати `route()`, щоб сторінка
перемалювалася. На екрані виклику цього не робити: дзвінок перерветься. Там графіків немає, тож усе гаразд.

### 1.2. Поле відповіді сховане, коли є розпізнавання мови

**Що сталося.** У `call.js:49` режим стає `"voice"`, якщо браузер підтримує ASR. Тоді `callScreen.js` ховає форму
відповіді, а `Ctrl+/` перевіряє `props.mode === 'text'` і не спрацьовує. Курсант без мікрофона або в шумному
приміщенні не може відповісти абоненту.

**Рішення.** `mode` означає лише «чи доступний мікрофон». Поле відповіді видиме в будь-якому режимі, коли дзвінок триває.

`frontend/js/callScreen.js`, функція `update`:

```js
// було: setHidden(ref.composer, p.mode !== 'text' || phase === 'incoming');
// стало (у гілці зміни mode і в гілці зміни phase):
setHidden(ref.composer, phase !== 'live' && phase !== 'ending');
```

Рядок `if (!same(phase, o.phase) && phase !== 'incoming') setHidden(ref.composer, p.mode !== 'text');` видалити: його замінює правило вище.

`onKeyDown`:

```js
// було: if (e.ctrlKey && e.key === '/' && props.mode === 'text') { ... }
if ((e.ctrlKey || e.metaKey) && e.key === '/' && props.phase === 'live') { e.preventDefault(); ref.replyInput.focus(); return; }
```

Підказку `voiceHint` змінити на «Говоріть (F2) або пишіть (Ctrl+/)» і показувати лише в режимі voice.
У `.composer` прибрати верхню рамку: всередині `panel-talk` вона зайва (див. крок 4.4).

### 1.3. Кнопка всередині кнопки на картці сценарію

**Що сталося.** `app.js:147`: `div.card` має `role="button"` і `tabindex=0`, а всередині ще одна `<button>` «Почати».
Скринрідер читає дві кнопки, а Tab зупиняється двічі на одній картці.

**Рішення: «розтягнуте посилання».** Інтерактивна лише кнопка. Її псевдоелемент `::after` накриває всю картку,
тому клік будь-де по картці натискає кнопку. Код у кроці 4.2, CSS у кроці 3.

### 1.4. Рамка фокуса навколо всього `<main>`

`main#app` має `tabindex="-1"` (для skip-link і переходу між маршрутами), тому після кліку по порожньому місцю
браузер малює `:focus-visible`. У `@layer base`:

```css
main[tabindex="-1"]:focus, main[tabindex="-1"]:focus-visible { outline: none; }
```

### 1.5. Плитки ролей не оновлюють `aria-pressed`

`app.js`, `renderLogin()`: при кліку оновлюється лише клас `sel`. Перемкнути атрибут разом із класом:

```js
on: { click: () => { role = id; tiles.forEach((x) => { const on = x === b; x.classList.toggle("sel", on); x.setAttribute("aria-pressed", String(on)); }); } }
```

Ще краще замінити плитки на `role="radiogroup"` з `role="radio"` і `aria-checked`. Так уже зроблені `.choice` на екрані виклику.

---

## Крок 2. Токени

Замінити обидва блоки кольорів у `@layer tokens` ([styles.css:41–85](frontend/styles.css)).
Світла тема тепер основна (`:root`), темна вмикається через `[data-theme="dark"]` (див. 1.1).
Контраст перевірено за WCAG: текст ≥ 4.5:1, рамки полів ≥ 3:1.

```css
@layer tokens {
  :root {
    /* шрифт лишаємо Manrope: найближчий відкритий до Airbnb Cereal */
    --fw-regular: 400; --fw-medium: 500; --fw-bold: 600; --fw-black: 700;   /* було 400/600/700/800 */

    --r-xs: 4px; --r-sm: 8px; --r-md: 12px; --r-lg: 16px; --r-xl: 24px; --r-pill: 999px;

    --page-max: 1120px;          /* Airbnb тримає контент вузьким */
    --page-max-wide: 1440px;     /* кабінет і пульт */
  }

  :root, :root[data-theme="light"] {
    --bg: #ffffff;
    --surface: #ffffff;
    --surface-2: #f7f7f7;        /* підкладки, hover */
    --surface-3: #ebebeb;        /* натиснуте, вибране */
    --line: #dddddd;             /* роздільники й рамки карток */
    --line-strong: #858585;      /* рамки полів 3.69:1 */
    --text: #222222;             /* 15.9:1 */
    --text-2: #6a6a6a;           /* 5.41:1 */
    --text-3: #717171;           /* 4.88:1, мінімум для тексту */

    /* Акцент лише для ОДНІЄЇ головної дії на екрані */
    --brand: #d70466;            /* текст і рамки акценту, 5.12:1 */
    --brand-solid: #e31c5f;      /* заливка кнопки, білий текст 4.57:1 */
    --brand-grad: linear-gradient(to right, #e61e4d 0%, #e31c5f 50%, #d70466 100%);
    --on-brand: #ffffff;
    --brand-soft: rgb(227 28 95 / .08);

    /* Звичайні кнопки чорні: так у Airbnb, і акцент не розмивається */
    --ink: #222222; --on-ink: #ffffff;

    --ok: #008a05; --ok-solid: #008a05; --on-ok: #ffffff; --ok-soft: rgb(0 138 5 / .08);
    --danger: #c13515; --danger-solid: #c13515; --on-danger: #ffffff; --danger-soft: rgb(193 53 21 / .07);
    --warn: #9a5b00; --warn-soft: rgb(255 176 32 / .16);
    --info: #0b63a5; --info-soft: rgb(11 99 165 / .08);
    --violet: #5b3fd1; --violet-soft: rgb(91 63 209 / .08);
    --focus: #222222;

    --sh-1: none;
    --sh-2: 0 6px 16px rgb(0 0 0 / .12);            /* hover картки, спливні елементи */
    --sh-3: 0 6px 20px rgb(0 0 0 / .2);             /* модальні вікна */
    --glow-brand: none; --glow-ok: none; --glow-danger: none;
    --aurora-a: transparent; --aurora-b: transparent;
    --scrim: rgb(0 0 0 / .5);
  }

  :root[data-theme="dark"] {
    --bg: #121212; --surface: #121212; --surface-2: #1e1e1e; --surface-3: #2a2a2a;
    --line: #333333; --line-strong: #8a8a8a;
    --text: #f7f7f7; --text-2: #b0b0b0; --text-3: #a3a3a3;
    --brand: #ff5a79; --brand-solid: #e31c5f; --on-brand: #ffffff; --brand-soft: rgb(255 90 121 / .14);
    --brand-grad: linear-gradient(to right, #e61e4d, #d70466);
    --ink: #f7f7f7; --on-ink: #121212;
    --ok: #4ade80; --ok-solid: #16a34a; --on-ok: #ffffff; --ok-soft: rgb(74 222 128 / .12);
    --danger: #ff6b6b; --danger-solid: #c13515; --on-danger: #ffffff; --danger-soft: rgb(255 107 107 / .12);
    --warn: #fbbf24; --warn-soft: rgb(251 191 36 / .12);
    --info: #6cc4ff; --info-soft: rgb(108 196 255 / .12);
    --violet: #b9a3ff; --violet-soft: rgb(185 163 255 / .12);
    --focus: #f7f7f7;
    --sh-1: none; --sh-2: 0 6px 16px rgb(0 0 0 / .5); --sh-3: 0 8px 28px rgb(0 0 0 / .6);
    --glow-brand: none; --glow-ok: none; --glow-danger: none;
    --aurora-a: transparent; --aurora-b: transparent;
    --scrim: rgb(0 0 0 / .6);
  }
}
```

Псевдоніми для графіків (`--red`, `--blue`…) лишаються. Одна зміна: `--blue: var(--info)` замість `var(--brand)`.
Інакше лінія «довіра» на графіку стане рожевою і зіллється з «панікою».

Блок `body` у `@layer base` спростити:

```css
body { background: var(--bg); color: var(--text); font: var(--fw-regular) var(--fs-md)/var(--lh-body) var(--font); -webkit-font-smoothing: antialiased; }
h1 { font-size: var(--fs-2xl); font-weight: var(--fw-bold); letter-spacing: -.02em; }   /* 30 px */
h2 { font-size: var(--fs-xl); font-weight: var(--fw-bold); letter-spacing: -.01em; }    /* 24 px, було 18 */
h3 { font-size: var(--fs-lg); font-weight: var(--fw-bold); color: var(--text); letter-spacing: 0; } /* було 13 px сірим */
a { color: var(--text); text-decoration: underline; text-underline-offset: 2px; font-weight: var(--fw-medium); }
main.wide { max-width: var(--page-max-wide); }
```

Зміна `h3` з 13 px сірого на 18 px чорного сама виправляє слабку ієрархію заголовків панелей у звіті й кабінеті.

---

## Крок 3. Базові компоненти

Усе нижче замінює відповідні правила в `@layer components`. Принцип: **у кожного елемента лише один засіб
відокремлення** (рамка, тінь або фон), а не всі три одразу.

### Панелі та картки

```css
.panel {
  background: var(--surface); border: 1px solid var(--line); border-radius: var(--r-md);
  box-shadow: none; padding: var(--s-6);
  animation: none;               /* «виринання» кожної панелі прибрати: Airbnb не анімує статичний контент */
}
.card {
  background: transparent; border: 0; padding: 0; box-shadow: none; gap: var(--s-2);
  border-radius: var(--r-md);
}
.card .title { font-size: var(--fs-md); font-weight: var(--fw-bold); }

/* розтягнуте посилання (1.3): уся картка клікабельна через основну кнопку */
.card.stretch { position: relative; }
.card.stretch .stretch-link::after { content: ""; position: absolute; inset: 0; border-radius: inherit; z-index: 1; }
.card.stretch :is(a, button):not(.stretch-link) { position: relative; z-index: 2; }
.card.stretch:has(.stretch-link:focus-visible) { outline: 3px solid var(--focus); outline-offset: 4px; }
.card.stretch .stretch-link:focus-visible { outline: none; }

@media (hover: hover) and (pointer: fine) {
  .card.stretch:hover .cover { transform: scale(1.02); }
  .card.clickable:hover { transform: none; background: transparent; box-shadow: none; }
}
```

### Кнопки

Три рівні замість п'яти:

| Клас | Вигляд | Коли |
|---|---|---|
| `.btn.primary` | рожевий градієнт | одна головна дія на екрані: «Почати», «Увійти», «Прийняти» |
| `.btn` | чорна заливка | звичайні дії |
| `.btn.ghost` | біла з рамкою `#222` | другорядні дії |
| `.btn.link` | підкреслений текст | «Назад», «Звіт →», «Детальніше» |

```css
.btn {
  min-height: 48px; padding: 0 var(--s-6); border-radius: var(--r-sm); border: 1px solid transparent;
  background: var(--ink); color: var(--on-ink); font: var(--fw-bold) var(--fs-md)/1 var(--font);
  transition: transform var(--t-fast) var(--ease), background var(--t-fast) var(--ease);
}
.btn:active:not(:disabled) { transform: scale(.96); }
.btn.primary { background: var(--brand-grad); color: var(--on-brand); }
.btn.ghost { background: var(--surface); color: var(--text); border-color: var(--text); }
.btn.link { background: none; border: 0; padding: 0 var(--s-1); min-height: var(--hit); color: var(--text); text-decoration: underline; text-underline-offset: 2px; }
.btn.danger { background: var(--danger-solid); color: var(--on-danger); }
.btn.success { background: var(--ok-solid); color: var(--on-ok); }
.btn.small { min-height: 36px; padding: 0 var(--s-4); font-size: var(--fs-sm); }
.btn.icon { width: 40px; min-height: 40px; border-radius: 50%; padding: 0; }
.btn.ghost.icon { border-color: transparent; }

@media (hover: hover) and (pointer: fine) {
  .btn:hover:not(:disabled) { transform: none; background: #000; }
  .btn.primary:hover:not(:disabled) { background: var(--brand-solid); box-shadow: none; }
  .btn.ghost:hover:not(:disabled) { background: var(--surface-2); }
  .btn.ghost.icon:hover:not(:disabled) { background: var(--surface-2); }
  .btn.link:hover:not(:disabled) { background: none; color: #000; }
}
:root[data-theme="dark"] .btn:hover:not(:disabled):not(.primary):not(.ghost):not(.link) { background: #fff; }
```

Пошук по JS, де міняти класи (без зміни логіки):

- `a.btn.ghost` «← Назад» у `report.js` → `a.btn.link`.
- `a.btn.small.ghost` «Звіт →» в історії (`app.js`) → `a.btn.link`.
- Кнопка «Почати» на картках бібліотеки лишається `primary` (одна головна дія картки), але див. 4.2.
- На звіті лише «Переграти з моменту помилки» лишається `primary`, «Пройти знову» стає `ghost`.

### Поля

Білі поля з чіткою рамкою, щоб не виглядали вимкненими:

```css
input:not([type=checkbox]):not([type=radio]):not([type=range]), select, textarea {
  min-height: 48px; background: var(--surface); border: 1px solid var(--line-strong);
  border-radius: var(--r-sm); padding: var(--s-3) var(--s-4); font-size: var(--fs-md);
}
input:not([type=checkbox]):not([type=radio]):not([type=range]):hover, select:hover, textarea:hover { background: var(--surface); border-color: var(--text); }
input:focus-visible, select:focus-visible, textarea:focus-visible {
  outline: none; border-color: var(--text); box-shadow: 0 0 0 1px var(--text); background: var(--surface);
}
input[aria-invalid="true"] { border-color: var(--danger); box-shadow: 0 0 0 1px var(--danger); }
input:disabled, select:disabled, textarea:disabled { background: var(--surface-2); border-color: var(--line); color: var(--text-3); }
label.field, .field > label { font-size: var(--fs-sm); font-weight: var(--fw-medium); color: var(--text); }
```

Плаваюча мітка всередині поля, як у Airbnb, необов'язкова. Вона потребує зміни розмітки кожного поля
(`<label>` всередині обгортки з `position:relative` і `:placeholder-shown`). Для тренажера мітка над полем читається
швидше, тому рекомендую лишити так.

### Мітки, вкладки, навігація

```css
.chip { border: 0; background: var(--surface-2); color: var(--text); font-weight: var(--fw-medium); padding: 4px 10px; }
.chip.red    { background: var(--danger-soft); color: var(--danger); }
.chip.green  { background: var(--ok-soft);     color: var(--ok); }
.chip.amber  { background: var(--warn-soft);   color: var(--warn); }
.chip.blue   { background: var(--info-soft);   color: var(--info); }
.chip.violet { background: var(--violet-soft); color: var(--violet); }

.tabs { gap: var(--s-6); }
.tabs button { padding: 0; color: var(--text-2); border-bottom-width: 2px; }
.tabs button:hover { color: var(--text); border-bottom-color: var(--line); }
.tabs button.active { color: var(--text); border-bottom-color: var(--text); }

.topbar { background: var(--bg); backdrop-filter: none; -webkit-backdrop-filter: none; min-height: 80px; }
.brand-badge { background: var(--brand-solid); box-shadow: none; border-radius: var(--r-sm); }
.brand { color: var(--brand); font-weight: var(--fw-bold); }
.nav { justify-content: center; }
.nav a { border-radius: var(--r-pill); color: var(--text-2); font-weight: var(--fw-medium); }
.nav a:hover { background: var(--surface-2); color: var(--text); text-decoration: none; }
.nav a.active { background: none; color: var(--text); font-weight: var(--fw-bold); text-decoration: underline; text-decoration-thickness: 2px; text-underline-offset: 8px; }
.userchip { border: 1px solid var(--line); border-radius: var(--r-pill); padding: var(--s-1) var(--s-1) var(--s-1) var(--s-4); }
.userchip:hover { box-shadow: var(--sh-2); }
```

### Діалоги, підказки, банери

```css
dialog.dlg { border: 0; border-radius: var(--r-xl); box-shadow: var(--sh-3); padding: var(--s-8); }
dialog.dlg::backdrop { backdrop-filter: none; }
.dlg-actions { border-top: 1px solid var(--line); padding-top: var(--s-4); justify-content: space-between; }
.toast { background: var(--ink); color: var(--on-ink); border: 0; border-radius: var(--r-sm); }
.banner { border: 0 !important; border-radius: var(--r-sm); font-weight: var(--fw-regular); }
```

### Рух

Прибрати декоративну анімацію статичного контенту: `rise` з `.panel`, `.stagger` на сітках звіту.
Залишити анімацію там, де вона щось повідомляє: репліка абонента (`swap`), дзвінок (`ripple`),
заповнення «Завершити», шиммер скелетонів, поява тосту.

---

## Крок 4. Екрани

### 4.1. Вхід (`renderLogin` у `app.js`)

Одна колонка 560 px по центру. Без пульсуючої точки й моноширинного надпису.

```js
app.append(h("div.login", h("div.login-card",
  h("h1", "Тренажер оператора 112"),
  h("p.muted", "Керована симуляція екстреного дзвінка з розбором після кожної сесії."),
  h("form.col", { on: { submit } },
    h("div.roles", { role: "radiogroup", "aria-label": "Роль" }, tiles),
    h("label.field", "Прізвище та ім'я", name),
    h("button.btn.primary.w-full", { type: "submit" }, "Увійти"),
    h("p.tiny.muted.mb-0", "Демо-вхід без пароля. Усі сценарії та голоси синтетичні.")))));
```

Плитку ролі зробити `button.role` з `role="radio"` і `aria-checked`.

```css
.login { min-height: calc(100dvh - 80px); display: grid; place-items: start center; padding: var(--s-10) var(--s-4); }
.login-card { width: min(560px, 100%); display: grid; gap: var(--s-4); }
.login-card h1 { font-size: var(--fs-3xl); }
.roles { grid-template-columns: 1fr; gap: var(--s-3); margin: var(--s-2) 0; }
.role { flex-direction: row; align-items: center; min-height: 0; padding: var(--s-5); background: var(--surface); border: 1px solid var(--line); border-radius: var(--r-md); gap: var(--s-4); }
.role svg { color: var(--text); }
.role[aria-checked="true"] { border-color: var(--text); box-shadow: inset 0 0 0 1px var(--text); background: var(--surface); }
```

### 4.2. Бібліотека сценаріїв (`renderHome` у `app.js`)

Найбільша зміна, саме вона дає «відчуття Airbnb»:

1. **Рядок категорій** над сіткою: іконка й підпис, обрана категорія підкреслена. Фільтрує на клієнті.
2. **Картка з обкладинкою**: квадратна плитка з великою іконкою категорії на кольоровому фоні, нижче назва,
   один рядок опису і складність словом. Без рамки.
3. **Мітки навичок** переходять у `title`/підказку, бо на картці їх забагато.

**Метадані категорій.** У `core.js` поруч із `CATEGORY`:

```js
export const CATEGORY_META = {
  "медична":    { icon: "heart",  tint: "#fde8ec", label: "Медицина" },
  "пожежа":     { icon: "flame",  tint: "#fdebe1", label: "Пожежа" },
  "газ":        { icon: "wind",   tint: "#fff3d6", label: "Газ" },
  "отруєння":   { icon: "flask",  tint: "#f3ecff", label: "Отруєння" },
  "ДТП":        { icon: "car",    tint: "#e6f0fb", label: "ДТП" },
  "утоплення":  { icon: "waves",  tint: "#e3f4f8", label: "Вода" },
  "насильство": { icon: "shield", tint: "#efeafd", label: "Насильство" },
  "обстріл":    { icon: "alert",  tint: "#f1f1f1", label: "Обстріл" },
};
export const DIFFICULTY = ["", "Легкий", "Середній", "Складний"];
```

Відтінки `tint` у темній темі задати через токени (`--tint-medical` тощо) або накласти на них
`color-mix(in srgb, <tint> 12%, var(--surface-2))`. Найпростіше рішення: у CSS для темної теми
`.cover { background: var(--surface-2) !important; }`.

**Нові іконки** для об'єкта `icon` у `core.js` (у стилі Lucide, як наявні):

```js
heart:  P('<path d="M19 14c1.5-1.5 3-3.2 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.8 0-3 .5-4.5 2-1.5-1.5-2.7-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4 3 5.5l7 7Z"/>'),
flame:  P('<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.4-.5-2-1-3-1.1-2.1-.2-4 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.2.4-2.3 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>'),
wind:   P('<path d="M17.7 7.7a2.5 2.5 0 1 1 1.8 4.3H2"/><path d="M9.6 4.6A2 2 0 1 1 11 8H2"/><path d="M12.6 19.4A2 2 0 1 0 14 16H2"/>'),
flask:  P('<path d="M9 3h6M10 3v6L4.5 18.5A2 2 0 0 0 6.2 21.5h11.6a2 2 0 0 0 1.7-3L14 9V3"/>'),
car:    P('<path d="M3 17v-5l2.2-5.2A2 2 0 0 1 7 5.5h10a2 2 0 0 1 1.8 1.3L21 12v5"/><path d="M3 12h18"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/>'),
waves:  P('<path d="M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/><path d="M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/><path d="M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/>'),
shield: P('<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>'),
alert:  P('<path d="m21.7 18-8-14a2 2 0 0 0-3.5 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.7-3"/><path d="M12 9v4M12 17h.01"/>'),
grid:   P('<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>'),
```

**Рендер бібліотеки.** Замінити блок «Бібліотека сценаріїв» у `renderHome`:

```js
const valid = scs.filter((s) => s.valid);
const cats = ["все", ...new Set(valid.map((s) => s.category))];
let active = "все";
const grid = h("div.grid.cards.library");

function scenarioCard(s) {
  const meta = CATEGORY_META[s.category] || { icon: "alert", tint: "#f1f1f1", label: s.category };
  const start = h("button.btn.small.stretch-link", {
    type: "button", "aria-label": `Почати: ${s.title}`,
    on: { click: (e) => startCall(user, s, null, e.currentTarget) },
  }, ic("phone"), "Почати");
  return h("article.card.stretch", { title: (s.skills || []).join(" · ") },
    h("div.cover", { style: { background: meta.tint }, "aria-hidden": "true" }, h("span.cover-ico", { html: icon[meta.icon] })),
    h("div.row.between.nowrap",
      h("h3.title.m-0", s.title),
      h("span.small.nowrap", DIFFICULTY[s.difficulty] || "")),
    h("p.small.muted.m-0.clamp-2", s.brief),
    h("div.row.between",
      h("span.small.muted", `${meta.label} · ${plural(s.steps, ["крок", "кроки", "кроків"])}`),
      start));
}

function renderGrid() {
  grid.replaceChildren(...valid.filter((s) => active === "все" || s.category === active).map(scenarioCard));
}

const catBar = h("div.catbar", { role: "tablist", "aria-label": "Категорії" }, cats.map((c) => {
  const meta = c === "все" ? { icon: "grid", label: "Усі" } : (CATEGORY_META[c] || { icon: "alert", label: c });
  const b = h("button.cat", { type: "button", role: "tab", "aria-selected": String(c === active),
    on: { click: () => {
      active = c;
      catBar.querySelectorAll(".cat").forEach((x) => x.setAttribute("aria-selected", String(x === b)));
      renderGrid();
    } } }, h("span", { html: icon[meta.icon] }), meta.label);
  return b;
}));

app.append(h("section.section",
  h("div.section-title", h("h2", "Бібліотека сценаріїв"), h("span.muted.small", plural(valid.length, ["сценарій", "сценарії", "сценаріїв"]))),
  catBar, grid));
renderGrid();
```

Призначені сесії рендерити тією самою `scenarioCard`, додавши над обкладинкою мітку
`h("span.badge", "Призначено · до " + a.due)` (абсолютно в лівому верхньому куті обкладинки) і передаючи
`a` у `startCall`. Так зникне дубльована розмітка картки.

```css
.catbar { display: flex; gap: var(--s-8); overflow-x: auto; padding-bottom: var(--s-2); margin-bottom: var(--s-6); border-bottom: 1px solid var(--line); scrollbar-width: none; }
.cat { display: grid; justify-items: center; gap: var(--s-2); min-height: var(--hit); padding: var(--s-2) 0 var(--s-3); background: none; border: 0; border-bottom: 2px solid transparent; color: var(--text-2); font: var(--fw-medium) var(--fs-xs) var(--font); cursor: pointer; white-space: nowrap; }
.cat svg { width: 24px; height: 24px; }
.cat:hover { color: var(--text); border-bottom-color: var(--line); }
.cat[aria-selected="true"] { color: var(--text); border-bottom-color: var(--text); }

.grid.cards.library { grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: var(--s-10) var(--s-6); }
.cover { aspect-ratio: 1 / 1; border-radius: var(--r-md); display: grid; place-items: center; overflow: hidden; transition: transform var(--t-slow) var(--ease); margin-bottom: var(--s-2); position: relative; }
.cover-ico svg { width: 56px; height: 56px; color: #222; stroke-width: 1.5; }
.badge { position: absolute; top: var(--s-3); left: var(--s-3); background: #fff; color: #222; padding: 4px 10px; border-radius: var(--r-pill); font: var(--fw-bold) var(--fs-xs) var(--font); box-shadow: var(--sh-2); }
.clamp-2 { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
:root[data-theme="dark"] .cover { background: var(--surface-2) !important; }
:root[data-theme="dark"] .cover-ico svg { color: var(--text); }
```

**Статистика курсанта** (`progressCard`): замість трьох окремих плиток один рядок тексту під привітанням,
наприклад «1 сесія · середній бал 0 · час до адреси —». Сітка `.grid.stats` лишається лише у звіті.

**Історія** лишається таблицею, але без обгортки-панелі: `h("div.table-wrap", h("table", …))`.
Рядок таблиці з `tr.click` має таку саму проблему клікабельності, як картка: клікабельний рядок без фокуса з клавіатури.
Лишити клікабельним лише посилання «Звіт» (`a.btn.link`), а `tr.click` прибрати.

### 4.3. Звіт (`renderReport` у `report.js`)

Мета: за 3 секунди зрозуміти «зараховано чи ні, що головне виправити, що натиснути далі».

**Шапка.** Прибрати службові мітки з видимої частини, лишити одну головну дію:

```js
const verdict = passed ? "Зараховано" : "Не зараховано";
const headline = r.missed_critical.length
  ? `Пропущено ${plural(r.missed_critical.length, ["критичний крок", "критичні кроки", "критичних кроків"])}`
  : "Усі критичні кроки виконано";

app.append(h("section.report-hero.section",
  scoreRing(r.score_instructor ?? r.score, passed),
  h("div.col",
    h("span", { class: `chip ${passed ? "green" : "red"} self-start` }, verdict),
    h("h1.m-0", r.scenario_title),
    h("p.lead.m-0", headline),
    h("p.small.muted.m-0", `${fmtDate(s.created)} · ${fmtT(r.duration_s * 1000)} · ${endReason(r.end_reason)}`)),
  h("div.report-actions",
    r.replay_t != null ? h("button.btn.primary", { on: { click: () => replay(r.replay_t) } }, ic("replay"), `Переграти з ${fmtT(r.replay_t)}`) : null,
    h("button.btn.ghost", { on: { click: () => replay(0) } }, "Пройти знову"),
    h("a.btn.link", { href: user.role === "trainee" ? "#/home" : "#/cabinet" }, "Назад"))));
```

Службові дані (`branch`, `seed`, калібрування) перенести в згорнутий блок унизу сторінки:

```js
app.append(h("details.fold.section",
  h("summary", "Технічні деталі"),
  h("div.fold-body", h("dl.kv",
    h("dt", "Гілка сценарію"), h("dd.mono", r.branch),
    h("dt", "Seed"), h("dd.mono", r.seed),
    r.score_instructor != null ? [h("dt", "Бал після калібрування"), h("dd", r.score_instructor)] : null))));
```

Інструкторам (`canCalibrate`) блок можна розкривати за замовчуванням (`open: true`).

**Рекомендації.** Нейтральна картка, колір лише в іконці, а кнопка «Переграти» лише там, де вона веде до
іншого моменту, ніж головна кнопка в шапці:

```js
const PRIO = { 0: ["alert", "danger"], 9: ["check", "ok"] };   // інакше: ["info", "warn"]
r.recommendations.map((rec) => {
  const [ico, tone] = PRIO[rec.prio] || ["info", "warn"];
  const showReplay = rec.replay_t != null && rec.replay_t !== r.replay_t && rec.replay_t > 0;
  return h("article.rec-card",
    h("span", { class: `rec-ico tone-${tone}`, html: icon[ico] || "" }),
    h("div.col",
      h("h3.m-0", rec.title),
      h("p.small.m-0", rec.text),
      rec.quote ? h("blockquote.quote", h("div.who", `${rec.quote_who === "operator" ? "Ви" : "Абонент"} · ${fmtT(rec.t)}`), `«${rec.quote}»`) : null,
      showReplay ? h("button.btn.link.self-start", { on: { click: () => replay(rec.replay_t) } }, `Переграти з ${fmtT(rec.replay_t)}`) : null));
});
```

Іконок `check` і `info` в `core.js` ще немає, їх треба додати:

```js
check: P('<polyline points="20 6 9 17 4 12"/>'),
info:  P('<circle cx="12" cy="12" r="9"/><path d="M12 16v-4M12 8h.01"/>'),
```

Заголовок рекомендації «Критичний крок не виконано: Запитав точну адресу» скоротити на бекенді
(`agents/reporter.py`) до «Запитати точну адресу». Факт, що крок критичний, уже передає червона іконка.

```css
.report-hero { grid-template-columns: auto 1fr auto; gap: var(--s-8); padding-bottom: var(--s-8); border-bottom: 1px solid var(--line); }
.lead { font-size: var(--fs-lg); }
.rec-card { display: grid; grid-template-columns: 40px 1fr; gap: var(--s-4); padding: var(--s-6); border: 1px solid var(--line); border-radius: var(--r-md); }
.rec-ico { width: 40px; height: 40px; border-radius: 50%; display: grid; place-items: center; }
.rec-ico svg { width: 20px; height: 20px; }
.tone-danger { background: var(--danger-soft); color: var(--danger); }
.tone-warn   { background: var(--warn-soft);   color: var(--warn); }
.tone-ok     { background: var(--ok-soft);     color: var(--ok); }
.quote { border: 0; background: var(--surface-2); border-radius: var(--r-sm); margin: 0; }
.stat { border: 0; border-radius: 0; padding: 0 var(--s-6) 0 0; box-shadow: none; background: none; }
.stat + .stat { border-left: 1px solid var(--line); padding-left: var(--s-6); }
.stat.bad .v { color: var(--text); }       /* червоні цифри прибрати, «—» і так означає «не виконано» */
.grid.stats { grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: var(--s-4) 0; }
```

Решта звіту (графік, чек-лист, таймлайн, картка, мовлення, реплей) лишається, але кожна панель
отримує заголовок `h2` замість `h3` 13 px, а чек-лист і таймлайн стають двома колонками без власних рамок.

### 4.4. Екран виклику (`callScreen.js` + CSS)

Структура й поведінка не змінюються. Лише стиль і дві дрібниці в розмітці.

1. **Поля картки білі** (крок 3, автоматично).
2. **Панель репліки** займає лише потрібну висоту, а не половину екрана. У сітці `.l-call` на ≥1024 px
   рядки зробити `auto minmax(0,1fr)` для правої колонки:

   ```css
   @media (min-width: 1024px) {
     .l-call { grid-template-rows: auto auto minmax(0, 1fr); }
     .l-call { grid-template-areas:
       "bar  bar  bar  bar  bar  bar  bar  bar  bar  bar  bar  bar"
       "card card card card card card card talk talk talk talk talk"
       "card card card card card card card log  log  log  log  log"; }
   }
   .utterance { min-height: 2.4em; }
   ```

3. **Поле відповіді** (див. 1.2) стоїть унизу панелі репліки:

   ```css
   .composer { border-top: 0; padding: 0; }
   .composer input { border-radius: var(--r-pill); padding-inline: var(--s-5); }
   .composer .btn { border-radius: var(--r-pill); }
   ```

4. **Смуга стану** без розмиття й тіні, з тонкою нижньою рамкою; «Прийняти» стає `.btn.primary`, а не зеленою:

   ```css
   .statusbar { background: var(--bg); backdrop-filter: none; -webkit-backdrop-filter: none; box-shadow: none; border-radius: var(--r-md); }
   .incoming .ring { background: var(--surface-2); color: var(--text); }
   .incoming .ring::before, .incoming .ring::after { border-color: var(--brand); }
   ```

   У `callScreen.js`: `class: 'btn success'` для `ref.accept` → `'btn primary'`.

5. **Чипи типу події** (`.choice`): вибраний чорний, як фільтри Airbnb:

   ```css
   .choice { background: var(--surface); border-color: var(--line); min-height: 40px; }
   .choice:hover { border-color: var(--text); background: var(--surface); transform: none; }
   .choice[aria-checked="true"] { background: var(--ink); color: var(--on-ink); border-color: var(--ink); box-shadow: none; }
   ```

6. **Заголовки груп** «ДЕ ЦЕ СТАЛОСЯ» перестають бути великими літерами з трекінгом:
   `.fgroup { text-transform: none; letter-spacing: 0; font-size: var(--fs-md); font-weight: var(--fw-bold); color: var(--text); }`

7. **Журнал розмови**: репліки оператора отримують `background: var(--ink); color: var(--on-ink)` (як вихідні
   повідомлення в чаті Airbnb), репліки абонента `var(--surface-2)` без рамки.

### 4.5. Пульт інструктора (`console.js`)

Порожній стан (рядок 36): замінити текст на ілюстрований блок.

```js
mid.append(h("div.empty-state",
  h("span.empty-ico", { html: icon.headset }),
  h("h2", "Поки немає активних дзвінків"),
  h("p.muted", "Коли курсант прийме виклик, дзвінок з'явиться ліворуч. Ви зможете слухати, бачити чек-лист і керувати Режисером."),
  h("a.btn.ghost", { href: "#/cabinet" }, "Призначити сесію")));
```

```css
.empty-state { display: grid; justify-items: center; text-align: center; gap: var(--s-3); padding: var(--s-10) var(--s-6); }
.empty-ico { width: 64px; height: 64px; border-radius: 50%; background: var(--surface-2); display: grid; place-items: center; }
.empty-ico svg { width: 28px; height: 28px; }
```

Список дзвінків ліворуч (`.callitem`): без фону, вибраний має рамку `var(--text)` 2 px.

### 4.6. Кабінет (`cabinet.js`)

- Ширину обмежує `main.wide` (1440 px, крок 2), щоб таблиці не тягнулися на весь монітор.
- Вкладки в стилі кроку 3.
- Форма призначення: поля в сітку 3 колонки, кнопка «Призначити» звичайна чорна `.btn`.
- «Експорт CSV» → `.btn.ghost.small`.

### 4.7. Методист

Окремих змін не потребує: отримує все з кроків 2–3. YAML-редактор лишається моноширинним.

---

## Крок 5. Збирання, тести, документація

1. **Standalone.** `tools/build_standalone.py` вбудовує CSS, шукаючи точний рядок
   `<link rel="stylesheet" href="/static/styles.css">` в `index.html`. Цей рядок не змінювати.
   Після змін перезібрати:

   ```bash
   python tools/build_standalone.py
   ```

2. **Тести.**

   ```bash
   python -m pytest -q
   ```

   ```bash
   node --test frontend/tests/
   ```

   Тест `cardAdapter.test.js` не залежить від стилів. Тести бекенду не перевіряють текст заголовків
   рекомендацій, тож зміна в `reporter.py:112` їх не зламає.

3. **Ручна перевірка** на 1440, 1024, 768 і 375 px у світлій і темній темі:
   вхід → бібліотека (фільтр, клік по картці, Tab по картках) → виклик (поле відповіді, Ctrl+/, F2,
   утримання «Завершити») → звіт → пульт → кабінет.

4. **Контраст.** Усі пари з кроку 2 перевірені. Якщо додаєте нові кольори, текст має бути ≥ 4.5:1, рамки полів ≥ 3:1.

5. **[DESIGN.md](DESIGN.md).** Оновити розділи «Теми» (світла за замовчуванням, `data-theme` ставить JS),
   «Форма» (радіуси 4/8/12/16/24, одна тінь) і додати правило «один акцент на екран, звичайні кнопки чорні».

---

## Що НЕ брати з Airbnb

- **Великі фото й багато повітря на екрані виклику.** Там важлива щільність і швидкість.
- **Сірий текст дрібніше 13 px.** Наявне правило DESIGN.md лишається.
- **Рожевий для помилок.** Рожевий означає «головна дія», для помилок окремий `--danger` з іконкою.
- **Шрифт Airbnb Cereal.** Він закритий, Manrope достатньо близький.
