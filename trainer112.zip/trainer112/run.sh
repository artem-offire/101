#!/usr/bin/env bash
# Запуск тренажера локально: http://localhost:8112
set -e
cd "$(dirname "$0")"
python3 -m pip install -q -r requirements.txt
cd backend && exec python3 -m uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-8112}"
