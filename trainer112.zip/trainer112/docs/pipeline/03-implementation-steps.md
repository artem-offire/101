# 03. Покрокова інструкція для Haiku 5.5

Документ для виконавця, який діє буквально. Він повністю реалізує рішення з `02-normative-and-tech-decisions.md` (профіль: оператор пункту зв'язку пожежно-рятувальної частини, НПРЧ ЛДУБЖД). Нічого не вирішуйте і не спрощуйте самі.

Проєкт: `/Users/artem/Desktop/trainer112`. Бекенд: `backend/app` (Python, FastAPI). Фронтенд: `frontend/` (чистий JavaScript). Сценарії: `scenarios/*.yaml`. Протокол: `protocols/standard.yaml`. Тести: `tests/`.

## Як працювати

1. Виконуйте кроки СТРОГО за порядком номерів: 1, 2, 3, ... 79. Не перескакуйте, не міняйте місцями, не об'єднуйте.
2. Перед кожним кроком прочитайте його ПОВНІСТЮ, включно з перевіркою.
3. Кожен крок містить: `Файл:` (абсолютний шлях), `Дія:` і один з блоків нижче. Усі блоки обрамлені трьома зворотними апострофами; сам рядок з апострофами в текст НЕ входить.
4. Позначки блоків, на власному рядку:
   - `ЗНАЙТИ:` і одразу після нього `ЗАМІНИТИ НА:` це пара. Використайте інструмент Edit: `old_string` дорівнює вмісту блоку ЗНАЙТИ, `new_string` дорівнює вмісту блоку ЗАМІНИТИ НА. Вміст береться символ у символ, з усіма початковими пробілами, без додаткового порожнього рядка в кінці. Кожен фрагмент ЗНАЙТИ зустрічається в файлі рівно ОДИН раз (я це перевірив). Якщо в кроці кілька пар, виконуйте їх по черзі зверху вниз.
   - `ВМІСТ ФАЙЛУ:` повний новий текст файла. Спершу прочитайте наявний файл (якщо він є), потім інструментом Write запишіть файл цілком. Текст блоку записується без змін, у кінці файла один символ нового рядка.
   - `КОМАНДА:` виконайте в терміналі (інструмент Bash) рівно як написано. Результат можна не звіряти.
   - `ПЕРЕВІРКА:` виконайте в терміналі і ЗВІРТЕ вивід з рядком `Очікується:` під блоком. Якщо збігається, крок виконано. Якщо ні, див. розділ «Якщо перевірка не пройшла» в кінці документа.
5. Пробіли в Python і YAML значущі. Не міняйте відступи, лапки, апострофи (`'` і `’` це різні символи), дефіси та кирилицю. Не замінюйте кириличні літери латинськими: наприклад, у `М-10`, `ГБО`, `ДТП` усі літери кириличні. Копіюйте текст з цього документа, не друкуйте його заново.
6. Номери телефонів у YAML завжди в лапках (`"0957072233"`), інакше вони перетворяться на число.
7. НЕ змінюйте жодних файлів, яких немає в кроках. НЕ встановлюйте залежності. НЕ запускайте сервери на портах `8112` і `8113`. НЕ перейменовуйте файли, папки, ключі `t112.user`, `t112.theme`, базу `trainer112`, шлях `/t112/`, `window.__T112_FILES`, `trainer112.html` та id наявних сценаріїв: збережені сесії й тести на них спираються.
8. Після кожного кроку занотовуйте для себе: номер, чи виконано, чи пройшла перевірка, чи були відхилення. Ці нотатки знадобляться для журналу в кроці 78.
9. Якщо ви випадково виконали крок двічі, фрагмент ЗНАЙТИ вже не знайдеться. Це не помилка: переконайтеся, що текст ЗАМІНИТИ НА вже є у файлі, і йдіть далі.

## Команди (для довідки, у кроках вони вже підставлені)

- Python з потрібними пакетами: `/private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python`
- Усі тести: `cd /Users/artem/Desktop/trainer112 && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -m pytest -q -p no:cacheprovider .`
- Перевірка синтаксису JS: `node --check <файл>`
- Тест JS: `node --test frontend/tests/cardAdapter.test.js`

## План

| Частина | Кроки | Що робимо | Контрольна точка |
|---|---|---|---|
| 1. Ядро бекенда | 1 до 22 | схема, розпізнавання реплік, оцінювач, оркестратор, API, бот, звіт, нормалізатор, промпти | КТ1 після кроку 22: `68 passed` |
| 2. Протокол і сценарії | 23 до 39 | архів, протокол з 15 кроків, 10 сценаріїв, перевірка джерела, тести | КТ2 після кроку 39: `73 passed` і проганяння бота |
| 3. Фронтенд | 40 до 74 | тексти, головна сторінка, картка виклику, кнопки дій, адаптер картки, звіт | КТ3 після кроку 74 |
| 4. Збирання і документи | 75 до 79 | автономний файл, README, DESIGN, журнал, остаточна перевірка | КТ4 у кроці 79 |

Кроки 40 до 74 (фронтенд) і кроки 76, 77 не залежать від бекенда. Кроки 2 до 39 залежать одне від одного послідовно. Крок 75 залежить від усіх попередніх. Крок 78 залежить від ваших нотаток.

Важливо: між кроками 23 і 35 окремі тести тимчасово можуть падати, бо сценарії переписуються по одному. Це очікувано. Остаточний результат дивіться лише на контрольній точці 2.

---

# ЧАСТИНА 1. Ядро бекенда (схема, розпізнавання, оцінювач, оркестратор, API, бот)

Після цієї частини система працює зі СТАРИМ протоколом і СТАРИМИ сценаріями, але вже вміє нове (дії оператора, картку за СГП, прихований випадковий сценарій). Усі 68 наявних тестів мають пройти.

### Крок 1. Перевірка вихідного стану
Файл: `/Users/artem/Desktop/trainer112`
Дія: виконати команду і переконатися, що все працює ДО змін.

КОМАНДА:
```bash
cd /Users/artem/Desktop/trainer112 && ls scenarios protocols tests backend/app
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -m pytest -q -p no:cacheprovider . 2>&1 | tail -3
```
Очікується: останній рядок `68 passed` (кількість секунд може відрізнятися, одне попередження про `httpx` нормальне). Якщо не `68 passed` — ЗУПИНІТЬСЯ і повідомте замовника: вихідний стан не збігається з тим, що очікує інструкція.

### Крок 2. models.py: власник події `operator.action`
Файл: `/Users/artem/Desktop/trainer112/backend/app/models.py`
Дія: замінити фрагмент.

ЗНАЙТИ:
```python
    "card.updated": {"operator_ui", "bot"},
```

ЗАМІНИТИ НА:
```python
    "card.updated": {"operator_ui", "bot"},
    "operator.action": {"operator_ui", "bot"},
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && grep -c '"operator.action": {"operator_ui", "bot"},' backend/app/models.py
```
Очікується: `1`.

### Крок 3. models.py: нові поля стану дзвінка
Файл: `/Users/artem/Desktop/trainer112/backend/app/models.py`
Дія: замінити фрагмент (клас `CallState`).

ЗНАЙТИ:
```python
    last_operator_t: int = 0
    last_caller_t: int = 0
```

ЗАМІНИТИ НА:
```python
    last_operator_t: int = 0
    last_caller_t: int = 0
    actions: dict[str, int] = Field(default_factory=dict)   # дії оператора: id -> час, мс
    card_t: int = 0                                         # час останнього оновлення картки, мс
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && grep -c "card_t: int = 0" backend/app/models.py
```
Очікується: `1`.

### Крок 4. models.py: редуктор подій
Файл: `/Users/artem/Desktop/trainer112/backend/app/models.py`
Дія: замінити фрагмент (метод `apply`).

ЗНАЙТИ:
```python
        elif ty == "card.updated":
            self.card.update(p.get("fields", {}))
```

ЗАМІНИТИ НА:
```python
        elif ty == "card.updated":
            self.card.update(p.get("fields", {}))
            self.card_t = ev.t
        elif ty == "operator.action":
            self.actions.setdefault(p["action"], ev.t)
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && grep -c 'self.actions.setdefault' backend/app/models.py
```
Очікується: `1`.

### Крок 5. models.py: інтенти та словник дій
Файл: `/Users/artem/Desktop/trainer112/backend/app/models.py`
Дія: замінити фрагмент.

ЗНАЙТИ:
```python
INTENTS = {
    "greeting", "what", "address", "house", "apartment", "people", "name", "phone",
    "condition", "reassure", "instruct", "confirm", "rude", "location_detail", "any",
}
```

ЗАМІНИТИ НА:
```python
INTENTS = {
    "greeting", "what", "address", "house", "apartment", "people", "name", "phone",
    "condition", "reassure", "instruct", "confirm", "rude", "location_detail", "any",
    "floors", "access", "danger",
}

# Дії оператора після прийому повідомлення (кнопки на картці виклику)
ACTIONS = {"alarm": "Подано сигнал «Тривога»", "report": "Доповідь про виїзд караулу"}
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && grep -c '^ACTIONS = ' backend/app/models.py
```
Очікується: `1`.

### Крок 6. models.py: правило кроку (`StepRule`)
Файл: `/Users/artem/Desktop/trainer112/backend/app/models.py`
Дія: замінити фрагмент.

ЗНАЙТИ:
```python
    entity_confirmed: Optional[str] = None
    semantic: Optional[str] = None     # опис для LLM-оцінювача
```

ЗАМІНИТИ НА:
```python
    entity_confirmed: Optional[str] = None
    semantic: Optional[str] = None     # опис для LLM-оцінювача
    action: Optional[str] = None       # крок виконано, коли курсант натиснув кнопку дії з цим id
    card_fields: list[str] = Field(default_factory=list)   # виконано, якщо ці поля картки збігаються з card_truth
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && grep -c "card_fields: list" backend/app/models.py
```
Очікується: `1`.

### Крок 7. models.py: джерело і підстава кроку (`ProtocolStep`)
Файл: `/Users/artem/Desktop/trainer112/backend/app/models.py`
Дія: замінити фрагмент.

ЗНАЙТИ:
```python
    example: str = ""
    tags: list[str] = Field(default_factory=list)
```

ЗАМІНИТИ НА:
```python
    example: str = ""
    tags: list[str] = Field(default_factory=list)
    source: str = ""                   # документ, розділ, глава, пункт, абзац
    basis: Literal["норма", "методична", "потребує підтвердження"] = "норма"
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112/backend && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -c "from app.models import ACTIONS, ProtocolStep, StepRule, INTENTS; print(sorted(ACTIONS), 'floors' in INTENTS, ProtocolStep(id='x', title='t').basis, StepRule().card_fields)"
```
Очікується: `['alarm', 'report'] True норма []`.

### Крок 8. scenarios.py: перевірка правил із діями
Файл: `/Users/artem/Desktop/trainer112/backend/app/scenarios.py`
Дія: дві заміни в одному файлі, по черзі.

ЗНАЙТИ:
```python
from .models import Fact, PlotEvent, Protocol, ProtocolStep, Scenario, merge_fact
```

ЗАМІНИТИ НА:
```python
from .models import ACTIONS, Fact, PlotEvent, Protocol, ProtocolStep, Scenario, merge_fact
```

ЗНАЙТИ:
```python
        if not (r.keywords or r.all_groups or r.intent or r.entity_confirmed or r.semantic):
            errors.append(f"protocol.{s.id}: правило порожнє")
```

ЗАМІНИТИ НА:
```python
        if not (r.keywords or r.all_groups or r.intent or r.entity_confirmed or r.semantic
                or r.action or r.card_fields):
            errors.append(f"protocol.{s.id}: правило порожнє")
        if r.action and r.action not in ACTIONS:
            errors.append(f"protocol.{s.id}: невідома дія")
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && grep -c "невідома дія" backend/app/scenarios.py
```
Очікується: `1`.

### Крок 9. nlu.py: привітання підрозділу
Файл: `/Users/artem/Desktop/trainer112/backend/app/nlu.py`
Дія: замінити фрагмент.

ЗНАЙТИ:
```python
    "greeting": ["112", "служба", "екстрен", "слухаю", "оператор", "лінія порятунку"],
```

ЗАМІНИТИ НА:
```python
    "greeting": ["112", "служба", "екстрен", "слухаю", "оператор", "лінія порятунку", "частина", "частини", "101",
                 "пункт зв'язку", "черговий", "диспетчер", "пожежно-рятувальн"],
```

### Крок 10. nlu.py: фрази про виїзд караулу
Файл: `/Users/artem/Desktop/trainer112/backend/app/nlu.py`
Дія: замінити фрагмент.

ЗНАЙТИ:
```python
                 "я тут", "я вас чую", "ви молодець", "ви все робите правильно", "рятувальник",
                 "направляю", "відправ"],
```

ЗАМІНИТИ НА:
```python
                 "я тут", "я вас чую", "ви молодець", "ви все робите правильно", "рятувальник",
                 "направляю", "відправ", "караул виїхав", "виїхав караул", "пожежні вже", "пожежні їдуть",
                 "машини вже їдуть", "сили виїхали"],
```

### Крок 11. nlu.py: уточнення місця та нові інтенти
Файл: `/Users/artem/Desktop/trainer112/backend/app/nlu.py`
Дія: замінити фрагмент (кінець словника `INTENT_PATTERNS`).

ЗНАЙТИ:
```python
    "location_detail": ["що поруч", "що біля", "що видно", "що навколо", "біля чого", "знак",
                        "магазин", "зупинк", "двері", "ключ", "зайти"],
}
```

ЗАМІНИТИ НА:
```python
    "location_detail": ["що поруч", "що біля", "що видно", "що навколо", "біля чого", "знак",
                        "магазин", "зупинк", "двері", "ключ", "зайти", "що горить", "що саме горить",
                        "що палає", "відкритий вогонь", "видно вогонь", "місце загоряння"],
    "floors": ["скільки поверхів", "поверховість", "поверхів у", "поверхів в", "скільки там поверх",
               "яка поверховість"],
    "access": ["під'їхати", "підїхати", "проїхати", "проїзд", "заїзд", "заїхати", "доїхати", "під'їзні",
               "шлагбаум", "ворота", "дістатися"],
    "danger": ["вибух", "балон", "загроза вибуху", "пальне", "бензин", "небезпечні речовин", "хімі",
               "акумулятор", "гбо"],
}
```

### Крок 12. nlu.py: нові інтенти є питаннями
Файл: `/Users/artem/Desktop/trainer112/backend/app/nlu.py`
Дія: замінити фрагмент.

ЗНАЙТИ:
```python
QUESTION_INTENTS = {"what", "address", "house", "apartment", "people", "name", "phone", "condition",
                    "location_detail"}
```

ЗАМІНИТИ НА:
```python
QUESTION_INTENTS = {"what", "address", "house", "apartment", "people", "name", "phone", "condition",
                    "location_detail", "floors", "access", "danger"}
```

### Крок 13. nlu.py: розведення конфліктів «поверхи» / «люди» / «квартира»
Файл: `/Users/artem/Desktop/trainer112/backend/app/nlu.py`
Дія: замінити фрагмент (функція `intents`).

ЗНАЙТИ:
```python
    if "house" in found or "apartment" in found:
        found.add("address")
```

ЗАМІНИТИ НА:
```python
    if "floors" in found:
        # «Скільки поверхів?» не є питанням про людей і не є питанням про квартиру
        if not any(p in t for p in INTENT_PATTERNS["people"] if p != "скільки"):
            found.discard("people")
        if not any(p in t for p in ("квартир", "під'їзд", "підїзд", "домофон")):
            found.discard("apartment")
    if "house" in found or "apartment" in found:
        found.add("address")
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112/backend && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -c "
from app.nlu import intents
a = intents('Скільки поверхів у будівлі?'); b = intents('Скільки людей у квартирі?')
c = intents('Чи зможе пожежна машина під\'їхати впритул? Є шлагбаум або ворота?')
d = intents('Чи є поруч газові балони або щось, що може вибухнути?')
print('floors' in a, 'people' in a, 'address' in a, 'people' in b, 'access' in c, 'address' in c, 'danger' in d)"
```
Очікується: `True False False True True False True`.

### Крок 14. evaluator.py: повний новий вміст
Файл: `/Users/artem/Desktop/trainer112/backend/app/agents/evaluator.py`
Дія: ПЕРЕЗАПИСАТИ файл повністю (спочатку прочитайте наявний файл, потім запишіть новий вміст нижче).

ВМІСТ ФАЙЛУ:
```python
"""Агент «Оцінювач протоколу» (крок 5, E5-01).

Бачить лише шар «протокол і ваги» та репліки оператора (не легенду!).
Кожна позначка має цитату, час і впевненість; confidence < 0.7 -> на перевірку інструктору.
Живий прохід (на кожну фразу) для пульта і фінальний прохід після дзвінка.
Кроки з `rule.action` (кнопки «Тривога», «Доповісти») і `rule.card_fields` (запис у картці)
не залежать від реплік: їх позначають дія оператора і картка.
"""
from __future__ import annotations

import re
from typing import Any, Optional

from ..models import ACTIONS, CallState, ProtocolStep, Utterance
from ..nlu import intents, keyword_hit, norm
from .llm import LLMClient, parse_json


class Evaluator:
    def __init__(self, steps: list[ProtocolStep], card_truth: Optional[dict[str, Any]] = None) -> None:
        self.steps = steps
        self.card_truth = card_truth or {}
        self.llm = LLMClient("evaluator")

    def check_step(self, s: ProtocolStep, u: Utterance, entities: dict[str, Any]) -> Optional[dict[str, Any]]:
        r = s.rule
        if r.action or r.card_fields:
            return None                   # ці кроки не виконуються репліками
        text = u.text
        if r.entity_confirmed:
            ent = entities.get(r.entity_confirmed) or {}
            if isinstance(ent, dict) and ent.get("confirmed") and ent.get("confirmed_uid", u.id) == u.id:
                return {"confidence": 0.95}
            return None
        if r.all_groups:
            if all(keyword_hit(text, g) for g in r.all_groups):
                return {"confidence": 0.9}
        if r.keywords:
            if keyword_hit(text, r.keywords):
                return {"confidence": 0.85}
        if r.intent and r.intent in intents(text):
            return {"confidence": 0.8}
        return None

    def on_utterance(self, st: CallState, u: Utterance) -> list[dict[str, Any]]:
        """Живий прохід: перевірити ще не виконані кроки на новій фразі оператора."""
        marks = []
        for s in self.steps:
            if st.checklist.get(s.id):
                continue
            hit = self.check_step(s, u, st.entities)
            if hit:
                conf = hit["confidence"]
                marks.append({"step_id": s.id, "done": True, "t": u.t, "quote": u.text,
                              "confidence": conf, "needs_review": conf < 0.7, "utterance_id": u.id})
        return marks

    def on_action(self, st: CallState, aid: str, t: int) -> list[dict[str, Any]]:
        """Курсант натиснув кнопку дії: позначити кроки з цією дією."""
        marks = []
        for s in self.steps:
            if s.rule.action == aid and not st.checklist.get(s.id):
                marks.append({"step_id": s.id, "done": True, "t": t, "quote": "Дія: " + ACTIONS[aid],
                              "confidence": 1.0, "needs_review": False, "utterance_id": None})
        return marks

    async def semantic(self, st: CallState, u: Utterance, pending: list[ProtocolStep]) -> list[dict[str, Any]]:
        """Смислові кроки через LLM (якщо налаштовано). Структурований JSON-вихід."""
        sem = [s for s in pending if s.rule.semantic and not s.rule.action and not s.rule.card_fields
               and not st.checklist.get(s.id)]
        if not sem or not self.llm.enabled:
            return []
        desc = "\n".join(f"- {s.id}: {s.rule.semantic}" for s in sem)
        msgs = [{"role": "system", "content":
                 "Ти оцінювач протоколу оператора пункту зв'язку пожежно-рятувальної частини. Дано кроки і "
                 'репліку оператора. Поверни JSON {"steps":[{"step_id":str,"done":bool,"confidence":0..1}]} '
                 "лише для виконаних кроків."},
                {"role": "user", "content": f"Кроки:\n{desc}\nРепліка: «{u.text}»"}]
        try:
            data = parse_json(await self.llm.complete(msgs, json_mode=True, max_tokens=200)) or {}
        except Exception:  # noqa: BLE001
            return []
        out = []
        for m in data.get("steps", []):
            if m.get("done") and any(s.id == m.get("step_id") for s in sem):
                c = float(m.get("confidence", 0.6))
                out.append({"step_id": m["step_id"], "done": True, "t": u.t, "quote": u.text,
                            "confidence": c, "needs_review": c < 0.7, "utterance_id": u.id})
        return out

    def final_pass(self, st: CallState) -> dict[str, dict[str, Any]]:
        """Офіційна оцінка на повному транскрипті. Підтвердження адреси беремо з живого проходу."""
        result: dict[str, dict[str, Any]] = {}
        ops = [u for u in st.transcript if u.who == "operator"]
        for s in self.steps:
            live = st.checklist.get(s.id)
            if s.rule.action:
                t = st.actions.get(s.rule.action)
                if t is not None:
                    result[s.id] = {"done": True, "t": t, "quote": "Дія: " + ACTIONS[s.rule.action],
                                    "confidence": 1.0, "needs_review": False, "utterance_id": None}
                continue
            if s.rule.card_fields:
                rows = compare_card(st.card, self.card_truth, s.rule.card_fields)
                if rows and all(x["ok"] for x in rows):
                    result[s.id] = {"done": True, "t": st.card_t,
                                    "quote": "Картка: " + str(st.card.get("address", "")),
                                    "confidence": 1.0, "needs_review": False, "utterance_id": None}
                continue
            if s.rule.entity_confirmed:
                ent = st.entities.get(s.rule.entity_confirmed) or {}
                if isinstance(ent, dict) and ent.get("confirmed"):
                    u = next((x for x in ops if x.id == ent.get("confirmed_uid")), None)
                    if u:
                        result[s.id] = {"done": True, "t": u.t, "quote": u.text, "confidence": 0.95,
                                        "needs_review": False, "utterance_id": u.id}
                continue
            for u in ops:
                hit = self.check_step(s, u, st.entities)
                if hit:
                    result[s.id] = {"done": True, "t": u.t, "quote": u.text, "confidence": hit["confidence"],
                                    "needs_review": hit["confidence"] < 0.7, "utterance_id": u.id}
                    break
            if s.id not in result and live:
                result[s.id] = live.model_dump()
        return result


# (ключ картки, підпис у звіті, режим порівняння з card_truth). Склад полів: СГП р. II гл. 15 п. 2;
# СНС р. III гл. 1 п. 8. Режими: all — усі частини списку є в записаному; any — хоча б одне слово зі списку;
# int — ціле число; eq — точний збіг після нормалізації; contains — правда міститься в записаному;
# digits — останні 9 цифр телефону.
CARD_FIELDS = [
    ("address", "Місце події", "all"),
    ("incident_type", "Подія", "contains"),
    ("victims", "Людей у небезпеці / постраждалих", "int"),
    ("explosion", "Загроза вибуху", "eq"),
    ("floors", "Поверхів у будівлі", "int"),
    ("access", "Особливості під'їзду", "any"),
    ("caller_name", "Прізвище заявника", "contains"),
    ("phone", "Телефон заявника", "digits"),
]


def _as_list(exp: Any) -> list[Any]:
    return exp if isinstance(exp, list) else [exp]


def _field_ok(mode: str, exp: Any, got: Any) -> bool:
    if mode == "all":
        return all(norm(str(x)) in norm(str(got)) for x in _as_list(exp))
    if mode == "any":
        return any(norm(str(x)) in norm(str(got)) for x in _as_list(exp))
    if mode == "int":
        try:
            return int(str(got).strip()) == int(exp)
        except (TypeError, ValueError):
            return False
    if mode == "eq":
        return norm(str(got)) == norm(str(exp))
    if mode == "digits":
        dg, de = re.sub(r"\D", "", str(got)), re.sub(r"\D", "", str(exp))
        return len(dg) >= 9 and len(de) >= 9 and dg[-9:] == de[-9:]
    g, e = norm(str(got)), norm(str(exp))      # contains
    return e in g or g == e


def compare_card(card: dict[str, Any], truth: dict[str, Any],
                 fields: Optional[list[str]] = None) -> list[dict[str, Any]]:
    out = []
    for k, label, mode in CARD_FIELDS:
        if k not in truth or (fields is not None and k not in fields):
            continue
        exp = truth[k]
        got = card.get(k)
        ok = got not in (None, "") and _field_ok(mode, exp, got)
        out.append({"field": k, "label": label,
                    "expected": ", ".join(map(str, exp)) if isinstance(exp, list) else exp,
                    "got": got, "ok": ok})
    return out
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112/backend && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -c "
from app.agents.evaluator import compare_card
t = {'phone': '0631112233', 'floors': 9, 'access': ['шлагбаум', 'ворота'], 'address': ['Сихівська', '16'], 'explosion': 'ні'}
c = {'phone': '+38 (063) 111-22-33', 'floors': '9', 'access': 'шлагбаум на в\'їзді', 'address': 'Львів, Сихівська, 16', 'explosion': 'ні'}
print(all(r['ok'] for r in compare_card(c, t)), len(compare_card(c, t)), compare_card(c, t, ['floors'])[0]['label'])"
```
Очікується: `True 5 Поверхів у будівлі`.

### Крок 15. orchestrator.py: дії оператора
Файл: `/Users/artem/Desktop/trainer112/backend/app/orchestrator.py`
Дія: три заміни в одному файлі, по черзі.

ЗНАЙТИ:
```python
from .models import CallState, Event, Utterance
```

ЗАМІНИТИ НА:
```python
from .models import ACTIONS, CallState, Event, Utterance
```

ЗНАЙТИ:
```python
        self.evaluator = Evaluator(prep.steps)
```

ЗАМІНИТИ НА:
```python
        self.evaluator = Evaluator(prep.steps, prep.scenario.card_truth)
```

ЗНАЙТИ:
```python
        elif type_ == "card.updated":
            await self.emit("card.updated", source if source in ("operator_ui", "bot") else "operator_ui",
                            {"fields": payload.get("fields", {})})
```

ЗАМІНИТИ НА:
```python
        elif type_ == "card.updated":
            await self.emit("card.updated", source if source in ("operator_ui", "bot") else "operator_ui",
                            {"fields": payload.get("fields", {})})
        elif type_ == "operator.action":
            aid = payload.get("action")
            if aid in ACTIONS and aid not in self.state.actions:
                src = source if source in ("operator_ui", "bot") else "operator_ui"
                await self.emit("operator.action", src, {"action": aid})
                for m in self.evaluator.on_action(self.state, aid, now):
                    await self.emit("checklist.step", "evaluator", m)
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && grep -c "operator.action" backend/app/orchestrator.py
```
Очікується: `2`.

### Крок 16. service.py: випадковий сценарій на сервері
Файл: `/Users/artem/Desktop/trainer112/backend/app/service.py`
Дія: дві заміни в одному файлі, по черзі.

ЗНАЙТИ:
```python
                         from_t: Optional[int] = None, autostart: bool = True) -> CallOrchestrator:
```

ЗАМІНИТИ НА:
```python
                         from_t: Optional[int] = None, autostart: bool = True,
                         category: Optional[str] = None) -> CallOrchestrator:
```

ЗНАЙТИ:
```python
        sc = self.library.get(scenario_id)
```

ЗАМІНИТИ НА:
```python
        if scenario_id == "random":
            # «Будь-яка ситуація»: сервер сам обирає сценарій; курсант його назву до кінця дзвінка не бачить
            pool = sorted(sid for sid, s0 in self.library.items.items() if not category or s0.category == category)
            if not pool:
                raise KeyError("random")
            scenario_id = random.choice(pool)
            options = {**(options or {}), "blind": True}
        sc = self.library.get(scenario_id)
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && grep -c '"blind": True' backend/app/service.py
```
Очікується: `1`.

### Крок 17. main.py: назва, події курсанта, прихований сценарій, категорія
Файл: `/Users/artem/Desktop/trainer112/backend/app/main.py`
Дія: сім замін в одному файлі, по черзі.

ЗНАЙТИ:
```python
app = FastAPI(title="Тренажер операторів 112", version="0.1.0")
```

ЗАМІНИТИ НА:
```python
app = FastAPI(title="Тренажер оператора ПЗЧ", version="0.1.0")
```

ЗНАЙТИ:
```python
                  "card.updated", "call.restored", "barge_in.ignored"}
```

ЗАМІНИТИ НА:
```python
                  "card.updated", "operator.action", "call.restored", "barge_in.ignored"}
```

ЗНАЙТИ:
```python
    if role == "trainee":
        for k in ("checklist", "facts", "director", "entities", "emotion_series"):
            d.pop(k, None)
```

ЗАМІНИТИ НА:
```python
    if role == "trainee":
        for k in ("checklist", "facts", "director", "entities", "emotion_series"):
            d.pop(k, None)
        if orch.options.get("blind") and not orch.finished:
            # «Будь-яка ситуація»: назва і опис сценарію відкриваються лише після завершення дзвінка
            for k in ("scenario", "scenario_title", "scenario_brief", "category"):
                d.pop(k, None)
```

ЗНАЙТИ:
```python
            from_session=body.get("from_session"), from_t=body.get("from_t"), autostart=False)
```

ЗАМІНИТИ НА:
```python
            from_session=body.get("from_session"), from_t=body.get("from_t"), autostart=False,
            category=body.get("category"))
```

ЗНАЙТИ:
```python
                                            "card.updated", "call.end"):
```

ЗАМІНИТИ НА:
```python
                                            "card.updated", "operator.action", "call.end"):
```

ЗНАЙТИ:
```python
# ---------------------------------------------------------------- сесії і звіти
@app.get("/api/sessions")
def sessions(trainee: Optional[str] = None, include_bots: bool = False):
    out = TR.store.sessions(trainee)
    if not include_bots:
        out = [s for s in out if not str(s["trainee"]).startswith("bot")]
    return out
```

ЗАМІНИТИ НА:
```python
# ---------------------------------------------------------------- сесії і звіти
def _hide_blind(s: dict[str, Any]) -> dict[str, Any]:
    """Поки дзвінок «Будь-яка ситуація» не завершено, справжній id сценарію не показуємо."""
    if s.get("status") != "done" and (s.get("options") or {}).get("blind"):
        s["scenario_id"] = "random"
    return s


@app.get("/api/sessions")
def sessions(trainee: Optional[str] = None, include_bots: bool = False):
    out = TR.store.sessions(trainee)
    if not include_bots:
        out = [s for s in out if not str(s["trainee"]).startswith("bot")]
    return [_hide_blind(s) for s in out]
```

ЗНАЙТИ:
```python
    s["calibrations"] = TR.store.calibrations(sid)
    return s
```

ЗАМІНИТИ НА:
```python
    s["calibrations"] = TR.store.calibrations(sid)
    return _hide_blind(s)
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && grep -c "_hide_blind" backend/app/main.py && grep -c "operator.action" backend/app/main.py
```
Очікується: два рядки: `3` і `2`.

### Крок 18. bot.py: повний новий вміст
Файл: `/Users/artem/Desktop/trainer112/backend/app/bot.py`
Дія: ПЕРЕЗАПИСАТИ файл повністю (спочатку прочитайте наявний файл, потім запишіть новий вміст нижче).

ВМІСТ ФАЙЛУ:
```python
"""Бот-курсант (крок 7, E9-06): грає оператора за стилем і проганяє дзвінок у віртуальному часі.

Стилі:
  ideal            — виконує протокол за прикладами методиста, вчасно;
  forgets_address  — ніколи не питає і не підтверджує адресу (має валити критичний крок);
  rude             — грубить, повторює питання, не заспокоює;
  slow             — усе робить правильно, але з довгими паузами (запізнення).
Кроки-дії (`rule.action`) бот виконує натисканням кнопки, кроки за карткою (`rule.card_fields`) —
надсиланням картки. Очікування задаються в tests/test_regression.py і використовуються для автоперевірки сценаріїв.
"""
from __future__ import annotations

from typing import Any, Optional

from .models import CallState
from .orchestrator import CallOrchestrator, SimClock
from .nlu import words

STYLES = {
    "ideal": {"think_ms": 1500, "skip_tags": set(), "rude": False, "card": True, "reassure_early": True},
    "forgets_address": {"think_ms": 1800, "skip_tags": {"address"}, "rude": False, "card": True,
                        "reassure_early": True},
    "rude": {"think_ms": 1200, "skip_tags": set(), "rude": True, "card": False, "reassure_early": False},
    "slow": {"think_ms": 9000, "skip_tags": set(), "rude": False, "card": True, "reassure_early": False},
}
STYLE_TITLES = {"ideal": "Ідеальний", "forgets_address": "Забуває адресу", "rude": "Грубий", "slow": "Повільний"}


def address_phrase(st: CallState) -> Optional[str]:
    h = st.entities.get("address_heard") or {}
    parts = []
    if h.get("settlement"):
        parts.append(h["settlement"])
    if h.get("highway"):
        parts.append(f"траса {h['highway']}")
    if h.get("km"):
        parts.append(f"{h['km']} кілометр")
    if h.get("street"):
        parts.append(h["street"])
    if h.get("house"):
        parts.append(str(h["house"]))
    return ", ".join(parts) if parts else None


async def run_bot_call(orch: CallOrchestrator, style: str = "ideal", max_turns: int = 30) -> dict[str, Any]:
    cfg = STYLES[style]
    clock: SimClock = orch.clock  # type: ignore[assignment]
    assert isinstance(clock, SimClock)
    steps = [s for s in orch.prep.steps if not (set(s.tags) & cfg["skip_tags"])]
    steps.sort(key=lambda s: s.order)
    st = orch.state

    async def wait_and_advance(ms: int) -> None:
        await orch.wait_caller()
        # абонент говорить: віртуальний час іде
        target = max(clock.now() + ms, orch.caller_speaking_until + ms)
        while clock.now() < target and not orch.finished:
            step = min(1000, target - clock.now())
            clock.advance(step)
            await orch.tick()
            await orch.wait_caller()

    async def say(text: str) -> None:
        if orch.finished:
            return
        await orch.handle("operator.speech_start", {}, source="bot")
        dur = len(words(text)) * 380
        clock.advance(dur)
        await orch.handle("operator.final", {"text": text, "duration_ms": dur}, source="bot")
        await wait_and_advance(cfg["think_ms"])

    async def send_card() -> None:
        truth = orch.prep.scenario.card_truth
        fields: dict[str, Any] = {}
        for k, v in truth.items():
            fields[k] = " ".join(map(str, v)) if isinstance(v, list) else v
        await orch.handle("card.updated", {"fields": fields}, source="bot")

    await wait_and_advance(cfg["think_ms"])   # абонент відкриває розмову
    rude_lines = ["Та кажіть вже нормально, що сталося!", "Не верещіть, скільки можна!"]
    turns = 0
    for s in steps:
        if orch.finished or turns >= max_turns:
            break
        if st.checklist.get(s.id) and not s.rule.entity_confirmed:
            continue                      # уже виконано попередньою реплікою
        text = s.example
        if s.id == "greeting" and cfg["rude"]:
            text = "Частина. " + rude_lines[0]
        if s.rule.action:
            # дія оператора: кнопка «Подати сигнал «Тривога»», «Доповісти про виїзд»
            await orch.handle("operator.action", {"action": s.rule.action}, source="bot")
            await wait_and_advance(cfg["think_ms"])
            turns += 1
            continue
        if s.rule.card_fields:
            # запис у картку: бот заповнює картку за правдою сценарію
            if cfg["card"]:
                await send_card()
            continue
        if s.rule.entity_confirmed:
            # підтвердження адреси повтором; якщо абонент виправив — перепитати ще раз
            for _ in range(3):
                ap = address_phrase(st)
                if not ap:
                    await say("Повторіть, будь ласка, адресу: вулиця і номер будинку?")
                    turns += 1
                    continue
                await say(f"Повторюю: {ap}, правильно?")
                turns += 1
                if (st.entities.get("address") or {}).get("confirmed"):
                    break
            continue
        if s.id == "address_asked":
            await say(text)
            turns += 1
            h = st.entities.get("address_heard") or {}
            tries = 0
            while not (h.get("house") or h.get("km") or h.get("settlement")) and tries < 3 and not orch.finished:
                tries += 1
                if cfg["reassure_early"]:
                    await say("Я вас чую, допомога вже в дорозі. Спокійно, назвіть номер будинку чи орієнтир?")
                elif cfg["rude"]:
                    await say(rude_lines[1] + " Адреса яка?")
                else:
                    await say("Який номер будинку?")
                turns += 1
                h = st.entities.get("address_heard") or {}
            continue
        if "{address}" in text:
            text = text.replace("{address}", address_phrase(st) or "адреса")
        await say(text)
        turns += 1
        if cfg["rude"] and s.id == "people":
            await say(rude_lines[1])
            turns += 1
        if s.id in ("what_happened", "greeting") and cfg["reassure_early"] and st.caller.panic >= 7 \
                and s.id == "what_happened":
            await say("Я вас чую, я з вами. Допомога вже виїхала, спокійно.")
            turns += 1
    if cfg["card"] and not orch.finished:
        await send_card()
    if not orch.finished:
        await wait_and_advance(2000)
        rep = await orch.finish("operator")
    else:
        await orch.done.wait()
        rep = orch.report
    return rep or {}
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -m pytest -q -p no:cacheprovider tests/test_regression.py -k "ideal or evidence" 2>&1 | tail -3
```
Очікується: `passed` без `failed` (старі сценарії ще працюють зі старим протоколом).

### Крок 19. reporter.py: джерело кроку, причина заліку, тексти
Файл: `/Users/artem/Desktop/trainer112/backend/app/agents/reporter.py`
Дія: сім замін в одному файлі, по черзі.

ЗНАЙТИ:
```python
                         "needs_review": bool(m and m.get("needs_review")), "example": s.example})
```

ЗАМІНИТИ НА:
```python
                         "needs_review": bool(m and m.get("needs_review")), "example": s.example,
                         "source": s.source, "basis": s.basis})
```

ЗНАЙТИ:
```python
        passed = not missed_crit and score >= 60
```

ЗАМІНИТИ НА:
```python
        passed = not missed_crit and score >= 60
        if passed:
            pass_reason = f"Зараховано: усі критичні кроки виконано, бал {score:g}."
        elif missed_crit:
            pass_reason = "Не зараховано: пропущено критичні кроки: " + "; ".join(missed_crit) + "."
        else:
            pass_reason = f"Не зараховано: бал {score:g}, потрібно щонайменше 60."
```

ЗНАЙТИ:
```python
            "score": score, "passed": passed, "missed_critical": missed_crit, "checklist": rows,
```

ЗАМІНИТИ НА:
```python
            "score": score, "passed": passed, "pass_reason": pass_reason,
            "missed_critical": missed_crit, "checklist": rows,
```

ЗНАЙТИ:
```python
                recs.append({"prio": 1, "title": f"Запізно: {r['title']}",
                             "text": f"Виконано на {_fmt(r['t'])} при порозі {r['deadline_s']} с. "
                                     f"Ставте це питання раніше, одразу після «що сталося».",
```

ЗАМІНИТИ НА:
```python
                step_ = self.prep.step(r["step_id"])
                late_hint = ("Подавайте сигнал одразу, щойно відоме місце події (СНС р. III гл. 1 п. 9)."
                             if step_ and step_.rule.action else
                             "Ставте це питання раніше, одразу після «що сталося».")
                recs.append({"prio": 1, "title": f"Запізно: {r['title']}",
                             "text": f"Виконано на {_fmt(r['t'])} при порозі {r['deadline_s']} с. " + late_hint,
```

ЗНАЙТИ:
```python
"Різкі слова знижують довіру абонента і "
```

ЗАМІНИТИ НА:
```python
"Різкі слова знижують довіру заявника і "
```

ЗНАЙТИ:
```python
f"Тут абонент запанікував (+{best[0]:.1f})"
```

ЗАМІНИТИ НА:
```python
f"Тут заявник запанікував (+{best[0]:.1f})"
```

ЗНАЙТИ:
```python
"text": "Наляканий абонент сприймає тишу як те, що його не чують. Якщо треба час на "
```

ЗАМІНИТИ НА:
```python
"text": "Наляканий заявник сприймає тишу як те, що його не чують. Якщо треба час на "
```

ЗНАЙТИ:
```python
"content": "Ти інструктор операторів 112. Перепиши поля text рекомендацій "
```

ЗАМІНИТИ НА:
```python
"content": "Ти інструктор операторів ПЗЧ. Перепиши поля text рекомендацій "
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && grep -c "pass_reason" backend/app/agents/reporter.py && grep -c "абонент" backend/app/agents/reporter.py
```
Очікується: два рядки: `4` і `1` (одне службове «абонент» у коментарі лишається, це нормально).

### Крок 20. normalizer.py: довідник вулиць і населених пунктів Львова
Файл: `/Users/artem/Desktop/trainer112/backend/app/agents/normalizer.py`
Дія: дві заміни в одному файлі, по черзі.

ЗНАЙТИ:
```python
    "сагайдачного", "мазепи", "бандери", "липова", "річкова", "весела", "сонячна", "озерна",
]
```

ЗАМІНИТИ НА:
```python
    "сагайдачного", "мазепи", "бандери", "липова", "річкова", "весела", "сонячна", "озерна",
    "наукова", "сихівська", "стрийська", "личаківська", "городоцька", "кульпарківська",
]
```

ЗНАЙТИ:
```python
               "фастів", "вишгород", "березань", "гостомель", "макарів", "борова", "гатне", "петрівка"]
```

ЗАМІНИТИ НА:
```python
               "фастів", "вишгород", "березань", "гостомель", "макарів", "борова", "гатне", "петрівка",
               "брюховичі", "винники", "рудне", "сокільники", "пустомити", "львів"]
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112/backend && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -c "
from app.agents.normalizer import extract
print(extract('Сихівська, шістнадцять')['address'])
print(extract('Брюховичі, вулиця Польова, п\'ятнадцять')['address'])"
```
Очікується: перший рядок `{'street': 'Сихівська', 'house': '16'}`; другий рядок містить `'settlement': 'Брюховичі'` і `'house': '15'`.

### Крок 21. caller.py і director.py: тексти промптів
Файл: `/Users/artem/Desktop/trainer112/backend/app/agents/caller.py`
Дія: замінити фрагмент.

ЗНАЙТИ:
```python
CALLER_PROMPT = """Ти граєш людину, яка телефонує на лінію екстрених викликів. Ти НЕ асистент і не знаєш протоколів.
```

ЗАМІНИТИ НА:
```python
CALLER_PROMPT = """Ти граєш людину, яка телефонує до пожежно-рятувальної частини (101). Ти НЕ асистент і не знаєш протоколів.
```

### Крок 22. director.py: текст промпту
Файл: `/Users/artem/Desktop/trainer112/backend/app/agents/director.py`
Дія: замінити фрагмент.

ЗНАЙТИ:
```python
                 "Ти режисер навчальної симуляції дзвінка 112. Оціни останню репліку оператора і поверни лише JSON "
```

ЗАМІНИТИ НА:
```python
                 "Ти режисер навчальної симуляції дзвінка до пожежно-рятувальної частини. Оціни останню репліку оператора і поверни лише JSON "
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && grep -rn "112" backend/app --include=*.py | grep -v "__pycache__"
```
Очікується: рівно три рядки (усі нормальні): `metrics.py` (слово `trainer112`), `nlu.py` (шаблон `"112"` у списку привітань), `main.py` (порт 8112 у коментарі). Жодних інших рядків.

## КОНТРОЛЬНА ТОЧКА 1 (ядро бекенда)

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -m pytest -q -p no:cacheprovider . 2>&1 | tail -3
```
Очікується: `68 passed` (старі тести, старий протокол, нічого не зламано). Додатково:

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && for f in backend/app/*.py backend/app/agents/*.py; do /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -m py_compile "$f" || echo "ПОМИЛКА $f"; done; echo готово
```
Очікується: лише рядок `готово` (без слів `ПОМИЛКА`).

Якщо кількість тестів не `68 passed`, дивіться розділ «Якщо перевірка не пройшла» в кінці цього документа.

---

# ЧАСТИНА 2. Протокол НПРЧ і набір сценаріїв

Тут змінюються дані: базовий протокол і сценарії. Після кожного блоку є перевірка. Увага: між кроком 24 і кроком 35 окремі тести можуть тимчасово падати (сценарії переписуються по одному). Остаточний результат дивіться лише на контрольній точці 2.

### Крок 23. Перенесення непрофільних сценаріїв в архів
Файл: `/Users/artem/Desktop/trainer112/scenarios`
Дія: створити папку `archive` і перенести в неї три файли (файли НЕ видаляються; бібліотека читає лише `scenarios/*.yaml`, тому архів не завантажується).

КОМАНДА:
```bash
cd /Users/artem/Desktop/trainer112 && mkdir -p scenarios/archive && mv scenarios/cardiac-arrest-01.yaml scenarios/child-choking-01.yaml scenarios/domestic-violence-01.yaml scenarios/archive/
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && ls scenarios scenarios/archive
```
Очікується: у `scenarios` лишилося 7 файлів (`co-poisoning-01.yaml drowning-01.yaml elderly-fall-01.yaml gas-leak-03.yaml house-fire-01.yaml road-accident-02.yaml shelling-rubble-01.yaml`) і папка `archive`; в `archive` три файли (`cardiac-arrest-01.yaml child-choking-01.yaml domestic-violence-01.yaml`).

### Крок 24. Базовий протокол `standard.yaml` (повний новий вміст)
Файл: `/Users/artem/Desktop/trainer112/protocols/standard.yaml`
Дія: ПЕРЕЗАПИСАТИ файл повністю (спочатку прочитайте наявний файл, потім запишіть новий вміст нижче). Скорочення в полі `source`: СГП = Статут дій під час гасіння пожеж, СНС = Статут дій у надзвичайних ситуаціях, П116 = Порядок організації внутрішньої, гарнізонної та караульної служб. Нічого в цьому файлі не скорочуйте і не змінюйте.

ВМІСТ ФАЙЛУ:
```yaml
# Базовий протокол прийому повідомлення оператором ПЗЧ (НПРЧ ЛДУБЖД).
# Основа: СГП р. II гл. 15; СНС р. III гл. 1 пп. 7-10; П116 р. IV гл. 4. Ваги, дедлайни і критичність затверджує методист.
# Кожен крок має source (документ, пункт) і basis: норма | методична | потребує підтвердження.
# Сценарій успадковує ці кроки (protocol.base: standard) і може їх перевизначати.
steps:
  - id: greeting
    order: 1
    title: "Відрекомендувався: підрозділ, посада або звання"
    weight: 5
    deadline_s: 10
    source: "Порядок, затв. наказом МВС від 07.10.2014 № 1032 (втратив чинність 31.05.2022), р. V, п. 28, пп. 8. У чинних актах не знайдено"
    basis: "потребує підтвердження"
    rule:
      all_groups:
        - ["частин", "пожежн", "рятувальн", "пункт зв", "дснс", "101"]
        - ["оператор", "черговий", "диспетчер", "радіотелефоніст", "курсант", "сержант", "старшина", "прапорщик", "лейтенант", "капітан", "рядовий"]
    example: "Пожежно-рятувальна частина, оператор курсант Іваненко. Що сталося?"

  - id: what_happened
    order: 2
    title: "З'ясував, що сталося"
    weight: 10
    deadline_s: 20
    source: "Статут дій під час гасіння пожеж (наказ МВС від 26.04.2018 № 340), р. II, гл. 15, п. 2, абз. 1; Статут дій у НС (той самий наказ), р. III, гл. 1, п. 8, абз. 1"
    basis: "норма"
    rule: {intent: what}
    example: "Що сталося?"

  - id: address_asked
    order: 3
    title: "З'ясував місцезнаходження (адресу) об'єкта"
    weight: 15
    critical: true
    deadline_s: 30
    tags: [address]
    source: "Статут дій під час гасіння пожеж (наказ МВС від 26.04.2018 № 340), р. II, гл. 15, п. 2, абз. 2; Статут дій у НС (той самий наказ), р. III, гл. 1, п. 8, абз. 2"
    basis: "норма"
    rule: {intent: address}
    example: "Назвіть точну адресу: населений пункт, вулицю і номер будинку."

  - id: address_confirmed
    order: 4
    title: "Підтвердив адресу повтором"
    weight: 10
    critical: true
    deadline_s: 75
    tags: [address]
    source: "Статут дій під час гасіння пожеж (наказ МВС від 26.04.2018 № 340), р. II, гл. 2, п. 1, абз. 2 («точним прийомом інформації»). Прямої норми немає, це методична вимога"
    basis: "методична"
    rule: {entity_confirmed: address}
    example: "{address}, правильно?"

  - id: alarm
    order: 5
    title: "Подав сигнал «Тривога», щойно стало відоме місце"
    weight: 15
    critical: true
    deadline_s: 90
    source: "Порядок організації внутрішньої, гарнізонної та караульної служб (наказ МВС від 10.02.2022 № 116), р. IV, гл. 4, п. 1, абз. 1-2; Статут дій у НС (наказ МВС від 26.04.2018 № 340), р. III, гл. 1, п. 7, абз. 2 і п. 9; Статут дій під час гасіння пожеж (той самий наказ), р. II, гл. 15, п. 2, абз. 8"
    basis: "норма"
    rule: {action: alarm}
    example: "Натисніть «Подати сигнал «Тривога»», щойно відома адреса. Решту з'ясовуйте далі."

  - id: people
    order: 6
    title: "З'ясував загрозу життю людей (чи є люди, постраждалі)"
    weight: 15
    critical: true
    deadline_s: 100
    source: "Статут дій під час гасіння пожеж (наказ МВС від 26.04.2018 № 340), р. II, гл. 15, п. 2, абз. 3; Статут дій у НС (той самий наказ), р. III, гл. 1, п. 8, абз. 3"
    basis: "норма"
    rule: {intent: people}
    example: "Чи є там люди? Хтось постраждав?"

  - id: safety_advice
    order: 7
    title: "Дав заявнику пораду з безпеки"
    weight: 5
    source: "У нормативних актах не передбачено, це методична рекомендація"
    basis: "методична"
    rule:
      keywords: ["не заходьте", "відійдіть", "вийдіть", "залиште приміщення", "зачиніть двері", "не користуйтеся ліфтом", "безпечну відстань"]
      semantic: "оператор дав конкретну інструкцію з безпеки"
    example: "Не заходьте всередину і відійдіть на безпечну відстань."

  - id: danger
    order: 8
    title: "З'ясував загрозу вибуху (газові балони, пальне, хімія)"
    weight: 5
    deadline_s: 150
    source: "Статут дій під час гасіння пожеж (наказ МВС від 26.04.2018 № 340), р. II, гл. 15, п. 2, абз. 3"
    basis: "норма"
    rule: {intent: danger}
    example: "Чи є поруч газові балони або щось, що може вибухнути?"

  - id: fire_place
    order: 9
    title: "З'ясував об'єкт і місце загоряння (що саме горить)"
    weight: 5
    deadline_s: 150
    source: "Статут дій під час гасіння пожеж (наказ МВС від 26.04.2018 № 340), р. II, гл. 15, п. 2, абз. 2; Статут дій у НС (той самий наказ), р. III, гл. 1, п. 8, абз. 4"
    basis: "норма"
    rule:
      keywords: ["що горить", "що саме горить", "що палає", "відкритий вогонь", "видно вогонь", "місце загоряння", "де горить"]
      intent: location_detail
    example: "Що саме горить і чи видно відкритий вогонь?"

  - id: floors
    order: 10
    title: "З'ясував кількість поверхів будівлі"
    weight: 5
    deadline_s: 180
    source: "Статут дій під час гасіння пожеж (наказ МВС від 26.04.2018 № 340), р. II, гл. 15, п. 2, абз. 4"
    basis: "норма"
    rule: {intent: floors}
    example: "Скільки поверхів у будівлі?"

  - id: access
    order: 11
    title: "З'ясував особливості під'їзду"
    weight: 5
    deadline_s: 180
    source: "Статут дій під час гасіння пожеж (наказ МВС від 26.04.2018 № 340), р. II, гл. 15, п. 2, абз. 5"
    basis: "норма"
    rule: {intent: access}
    example: "Чи зможе пожежна машина під'їхати впритул? Є шлагбаум або ворота?"

  - id: caller_name
    order: 12
    title: "З'ясував прізвище заявника"
    weight: 5
    source: "Статут дій під час гасіння пожеж (наказ МВС від 26.04.2018 № 340), р. II, гл. 15, п. 2, абз. 6; Статут дій у НС (той самий наказ), р. III, гл. 1, п. 8, абз. 5"
    basis: "норма"
    rule: {intent: name}
    example: "Назвіть, будь ласка, ваше прізвище."

  - id: callback_phone
    order: 13
    title: "З'ясував номер телефону заявника"
    weight: 5
    source: "Статут дій під час гасіння пожеж (наказ МВС від 26.04.2018 № 340), р. II, гл. 15, п. 2, абз. 6; Статут дій у НС (той самий наказ), р. III, гл. 1, п. 8, абз. 5"
    basis: "норма"
    rule: {intent: phone}
    example: "Назвіть номер телефону, з якого ви телефонуєте."

  - id: registered
    order: 14
    title: "Зареєстрував повідомлення: адреса і подія в картці збігаються з фактами"
    weight: 5
    source: "Статут дій під час гасіння пожеж (наказ МВС від 26.04.2018 № 340), р. II, гл. 15, п. 3, абз. 2; Статут дій у НС (той самий наказ), р. III, гл. 1, п. 7, абз. 3"
    basis: "норма"
    rule: {card_fields: [address, incident_type]}
    example: "Заповніть картку: адреса і тип події мають відповідати повідомленню."

  - id: report
    order: 15
    title: "Доповів про виїзд караулу (ОКЦ / оператору базового ПРП)"
    weight: 5
    source: "Порядок організації внутрішньої, гарнізонної та караульної служб (наказ МВС від 10.02.2022 № 116), р. II, гл. 2, п. 7; р. III, гл. 2, пп. 5, 7; Статут дій у НС (наказ МВС від 26.04.2018 № 340), р. III, гл. 1, п. 7, абз. 5. Адресат доповіді в НПРЧ потребує підтвердження"
    basis: "норма"
    rule: {action: report}
    example: "Натисніть «Доповісти про виїзд», коли караул направлено."
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112/backend && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -c "
from app.scenarios import load_base_protocol
st = load_base_protocol('standard')
print(len(st), sum(s.weight for s in st), [s.id for s in st if s.critical], all(s.source for s in st))"
```
Очікується: `15 115.0 ['address_asked', 'address_confirmed', 'alarm', 'people'] True`.

### Крок 25. Сценарій `house-fire-01` (повний новий вміст)
Файл: `/Users/artem/Desktop/trainer112/scenarios/house-fire-01.yaml`
Дія: ПЕРЕЗАПИСАТИ файл повністю (спочатку прочитайте наявний файл).

ВМІСТ ФАЙЛУ:
```yaml
# Адреса навчальна, номер будинку умовний.
id: house-fire-01
title: Пожежа в приватному будинку
category: пожежа
difficulty: 2
brief: Чоловік бачить, як горить сусідський будинок у Брюховичах; всередині може бути людина.
skills: [адреса, люди всередині, сигнал Тривога]
max_duration_s: 300
silence_threshold_s: 4
legend:
  name: Андрій
  age: 38
  gender: male
  location: на вулиці перед будинком сусіда, селище Брюховичі біля Львова
  sees: з вікон другого поверху йде густий дим, полум'я на даху
  manner: кричить, говорить уривками, дихає важко після бігу
  fillers: ["блін", "короче", "слухайте"]
  voice: male_40_loud
  opening: ["Алло! Пожежа! Тут будинок горить!", "Горить! Будинок горить, приїжджайте!"]
  unknown: ["Не знаю я!", "Звідки я знаю?!"]
initial: {panic: 7, trust: 4}
facts:
  - id: fire
    say: ["Сусідський будинок горить, дим з вікон, полум'я вже на даху!"]
    reveal: {asked: [what, greeting], volunteer: true}
    truth: {incident_type: пожежа}
  - id: settlement
    say: ["Це Брюховичі! Ми в Брюховичах!"]
    reveal: {asked: [address]}
    critical: true
  - id: street
    say: ["Вулиця Польова!", "Польова вулиця, в кінці."]
    reveal: {asked: [address]}
    critical: true
  - id: house
    say: ["Будинок п'ятнадцять, двоповерховий, з зеленим парканом."]
    reveal: {asked: [house], max_panic: 9.5}
    critical: true
  - id: person_attic
    say: ["Там баба Ніна живе, вона сама, я її не бачив! Може на горищі!"]
    say_panic: ["Там баба Ніна! Вона там! Я не бачу її!"]
    reveal: {asked: [people]}
    critical: true
    truth: {victims: 1}
  - id: wants_to_enter
    say: ["Я зараз туди залізу, двері вибʼю!"]
    reveal: {after_fact: person_attic, asked: [instruct, reassure, any]}
  - id: gas_bottle
    say: ["У неї ж там газовий балон на кухні стоїть!"]
    reveal: {asked: [condition, instruct, location_detail, danger], after_fact: fire}
    truth: {explosion: так}
  - id: floors
    say: ["Два поверхи, і ще горище."]
    reveal: {asked: [floors]}
    truth: {floors: 2}
  - id: access
    say: ["До двору ґрунтовка, ворота відчинені."]
    reveal: {asked: [access]}
  - id: fire_place
    say: ["Дим з вікон другого поверху, а полум'я вже на даху!"]
    reveal: {asked: [location_detail]}
  - id: name
    say: ["Андрій Мельник."]
    reveal: {asked: [name]}
    truth: {caller_name: Мельник}
  - id: phone
    say: ["Нуль дев'яносто п'ять, сімсот сім, двадцять два, тридцять три."]
    reveal: {asked: [phone]}
events:
  - id: window_burst
    title: Вибухнуло вікно
    trigger: {at_s: 70}
    effects: {panic: 2, sound: glass, say: "О Боже! Вікно вибухнуло! Скло летить!"}
  - id: no_address
    title: Адресу не з'ясовано
    trigger: {after_s: 40, unless_step: address_asked}
    effects: {panic: 1.5, say: "Ну ви їдете чи ні?! Горить же!"}
complications:
  - id: second_voice
    title: Поруч кричить сусідка
    effects: {panic: 1, sound: crowd, say: "Тут сусідка кричить, що бачила бабу у вікні!"}
  - id: roof_collapse
    title: Обвал даху
    effects: {panic: 2, sound: crash, say: "Дах провалився! Половина даху впала!"}
branches:
  - {id: main, weight: 2, title: Стандарт}
  - id: no_person
    weight: 1
    title: Людини вдома немає
    facts:
      person_attic: {say: ["Баба Ніна там живе… ой, ні, вона ж у доньки сьогодні! Наче нікого нема."], truth: {victims: 0}}
protocol:
  base: standard
  steps:
    - id: safety_advice
      title: "Безпека: не заходити в будинок, відійти на безпечну відстань"
      deadline_s: 120
      rule: {keywords: ["не заходьте", "не лізьте", "відійдіть", "не намагайтеся", "безпечну відстань"]}
      example: "Не заходьте в будинок, це небезпечно. Відійдіть на безпечну відстань і зустріньте пожежних."
card_truth: {address: ["Брюховичі", "Польова", "15"], incident_type: пожежа, victims: 1, explosion: "так", floors: 2, access: ["ґрунтов", "ворота"], caller_name: Мельник, phone: "0957072233"}
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112/backend && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -c "
from app.scenarios import Library
lib = Library(); print(sorted(lib.items), lib.errors)"
```
Очікується: у списку є `house-fire-01`, а в словнику помилок НЕМАЄ ключа `house-fire-01` (інші сценарії можуть ще мати помилки або бути на старому протоколі, це нормально до кінця частини 2).

### Крок 26. Сценарій `gas-leak-03` (повний новий вміст)
Файл: `/Users/artem/Desktop/trainer112/scenarios/gas-leak-03.yaml`
Дія: ПЕРЕЗАПИСАТИ файл повністю (спочатку прочитайте наявний файл).

ВМІСТ ФАЙЛУ:
```yaml
# Адреса навчальна, номер будинку умовний.
id: gas-leak-03
title: Запах газу в квартирі
category: газ
difficulty: 2
brief: Жінка відчуває сильний запах газу в під'їзді та квартирі багатоповерхівки у Львові, з нею онук.
skills: [адреса, загроза вибуху, інструкції з безпеки]
max_duration_s: 300
silence_threshold_s: 4

# ── Шар 1. Легенда (бачить лише Абонент) ───────────────────────────────
legend:
  name: Галина Петрівна
  age: 63
  gender: female
  location: квартира на третьому поверсі дев'ятиповерхового будинку у Львові
  sees: на кухні сильно пахне газом, плита вимкнена, онук у кімнаті
  manner: говорить швидко, плутається, перепитує, суржик
  fillers: ["ой", "ну", "божечки", "значить"]
  voice: female_60_tremble
  opening:
    - "Алло! Алло, це пожежні? Тут газом пахне, страшно!"
    - "Алло! Допоможіть, у нас газом смердить на всю квартиру!"
  unknown: ["Я не знаю, синочку!", "Ой, не знаю я…"]

initial: {panic: 7, trust: 4}

# ── Шар 2. Факти з умовами розкриття (Абонент + Режисер) ───────────────
facts:
  - id: smell_gas
    say: ["Газом пахне, дуже сильно, аж голова паморочиться."]
    reveal: {asked: [what, greeting, danger], volunteer: true}
    truth: {incident_type: газ}
  - id: street
    say: ["Наукова вулиця!", "Ми на Науковій живемо."]
    say_panic: ["Наукова! Наукова вулиця!"]
    reveal: {asked: [address]}
    critical: true
  - id: house
    say: ["Будинок сімнадцять а.", "Сімнадцять а, третій під'їзд."]
    reveal: {asked: [house], max_panic: 9}
    critical: true
  - id: house_correction
    say: ["Ой ні, ні! Не сімнадцять, а сімнадцять а! Сімнадцять а!"]
    reveal: {asked: [confirm], after_fact: house, min_trust: 11}
  - id: apartment
    say: ["Квартира двадцять дев'ять, третій поверх."]
    reveal: {asked: [apartment]}
  - id: floors
    say: ["Будинок дев'ятиповерховий, дев'ять поверхів."]
    reveal: {asked: [floors]}
    truth: {floors: 9}
  - id: access
    say: ["Двір заставлений машинами, там тісно."]
    reveal: {asked: [access]}
  - id: people_inside
    say: ["Я і онучок, Максимко, йому п'ять років. Він у кімнаті."]
    reveal: {asked: [people]}
    critical: true
    truth: {victims: 2}
  - id: name
    say: ["Галина Петрівна Коваль."]
    reveal: {asked: [name]}
    truth: {caller_name: Коваль}
  - id: phone
    say: ["Номер нуль шістдесят сім, сто двадцять три, сорок п'ять, шістдесят сім."]
    reveal: {asked: [phone]}
  - id: stove_off
    say: ["Плита вимкнена, я перевіряла! Звідки воно тягне — не знаю."]
    reveal: {asked: [condition, instruct], after_fact: smell_gas}
  - id: neighbor
    say: ["Ой, сусід із четвертого теж вийшов, каже в нього теж пахне!"]
    reveal: {after_s: 140}

# ── Шар 3. Сюжетні події і гілки (бачить Режисер) ──────────────────────
events:
  - id: panic_no_address
    title: Адресу не з'ясовано за 45 с
    trigger: {after_s: 45, unless_step: address_asked}
    effects: {panic: 2, say: "Ну чого ви мовчите?! Приїжджайте швидше!"}
  - id: dizzy
    title: Абонентці паморочиться голова
    trigger: {at_s: 100}
    effects: {panic: 1, say: "Ой… мені погано, голова крутиться…", caption: "абонентка важко дихає"}
  - id: child_cries
    title: Плач дитини поруч
    trigger: {after_fact: people_inside, delay_s: 8}
    effects: {panic: 1, sound: child_cry, caption: "чути плач дитини"}

complications:
  - id: doorbell
    title: Сусід дзвонить у двері
    effects: {panic: 1, sound: doorbell, say: "Ой, хтось дзвонить у двері! Відчиняти?!"}
  - id: light_switch
    title: Абонентка хоче увімкнути світло
    effects: {panic: 1, say: "Тут темно в коридорі, я зараз світло ввімкну…"}
  - id: line_drop
    title: Обрив зв'язку
    effects: {panic: 2, silent_s: 6, sound: beeps, caption: "зв'язок обірвався"}

branches:
  - id: main
    weight: 2
    title: Стандарт
  - id: wrong_address
    weight: 1
    title: Плутає номер будинку
    facts:
      house: {say: ["Будинок сімнадцять!"], say_panic: ["Сімнадцять!"]}
      house_correction: {reveal: {asked: [confirm], after_fact: house, min_trust: 0}}

# ── Шар 4. Протокол і ваги (бачить Оцінювач) ───────────────────────────
protocol:
  base: standard
  steps:
    - id: safety_advice
      title: "Безпека: не вмикати світло і вогонь, вийти з квартири"
      deadline_s: 120
      rule:
        keywords: ["не вмикайте", "не запалюйте", "не користуйтеся", "вийдіть", "виходьте", "відкрийте вікна"]
      example: "Не вмикайте світло і нічого не запалюйте. Відкрийте вікна, беріть онука і виходьте з квартири."
    - id: fire_place
      title: "З'ясував, де саме пахне газом і що видно"
      example: "Що видно чи чутно: де найсильніше пахне газом?"
    - id: apartment_floor
      order: 4
      title: Уточнив квартиру і поверх
      weight: 5
      source: "Статут дій під час гасіння пожеж (наказ МВС від 26.04.2018 № 340), р. II, гл. 15, п. 2, абз. 2"
      basis: "норма"
      rule: {intent: apartment}
      example: "Яка квартира і поверх?"
      tags: [address]

card_truth: {address: ["Наукова", "17а"], incident_type: газ, victims: 2, explosion: "так", floors: 9, access: ["машин", "заставл"], caller_name: Коваль, phone: "0671234567"}
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112/backend && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -c "
from app.scenarios import Library
print(Library().errors.get('gas-leak-03'))"
```
Очікується: `None`.

### Крок 27. Сценарій `road-accident-02` (повний новий вміст)
Файл: `/Users/artem/Desktop/trainer112/scenarios/road-accident-02.yaml`
Дія: ПЕРЕЗАПИСАТИ файл повністю (спочатку прочитайте наявний файл). Увага: літера `М` в `М-10` кирилична.

ВМІСТ ФАЙЛУ:
```yaml
# Адреса навчальна: траса М-10 (Львів - Краковець), 15-й кілометр, точка умовна.
id: road-accident-02
title: ДТП на трасі з постраждалими
category: ДТП
difficulty: 2
brief: Водійка зупинилась біля перекинутого авто на трасі Львів - Краковець, є постраждалі, тече пальне.
skills: [місце на трасі, кількість постраждалих, безпека на дорозі, деблокування]
max_duration_s: 300
silence_threshold_s: 4
legend:
  name: Олена
  age: 29
  gender: female
  location: на узбіччі траси М-10 між Львовом і Краковцем
  sees: перекинутий легковик у кюветі, з нього тече пальне, двоє людей затиснуті в салоні
  manner: намагається тримати себе в руках, але голос тремтить, швидко говорить
  fillers: ["е-е", "ну", "так от"]
  voice: female_30
  opening: ["Алло, тут аварія! Машина перекинулась!", "Алло! ДТП на трасі, машина в кюветі!"]
  unknown: ["Я не знаю, я ж не лікар!", "Не бачу звідси…"]
initial: {panic: 6, trust: 5}
facts:
  - id: crash
    say: ["Легкова машина перекинулась і злетіла в кювет."]
    reveal: {asked: [what, greeting], volunteer: true}
    truth: {incident_type: ДТП}
  - id: highway
    say: ["Траса М-10, на Краковець, п'ятнадцятий кілометр, біля заправки."]
    say_panic: ["Траса М-10! П'ятнадцятий кілометр!"]
    reveal: {asked: [address, location_detail]}
    critical: true
  - id: direction
    say: ["Напрямок на Краковець, права смуга."]
    reveal: {asked: [location_detail, house]}
  - id: victims
    say: ["У салоні двоє, водій і пасажирка, вони стогнуть, їх затиснуло."]
    reveal: {asked: [people]}
    critical: true
    truth: {victims: 2}
  - id: bleeding
    say: ["У водія кров на голові, він в свідомості, але не відповідає чітко."]
    reveal: {asked: [condition], after_fact: victims}
  - id: fuel
    say: ["Ой, з машини щось тече, пахне бензином!"]
    reveal: {after_s: 50, asked: [condition, danger]}
  - id: situation
    say: ["Машина лежить на боку, з-під капота тече пальне, вогню поки нема, але двері заклинило."]
    reveal: {asked: [location_detail]}
  - id: access
    say: ["Машина на узбіччі, під'їхати можна з боку Львова, там розширення."]
    reveal: {asked: [access]}
  - id: name
    say: ["Олена Ткач."]
    reveal: {asked: [name]}
    truth: {caller_name: Ткач}
  - id: phone
    say: ["Нуль шістдесят три, чотириста п'ятдесят, дванадцять, нуль один."]
    reveal: {asked: [phone]}
events:
  - id: fuel_smell
    title: Запах пального посилюється
    trigger: {at_s: 80}
    effects: {panic: 1.5, say: "Бензином пахне все сильніше! А люди там всередині!"}
  - id: truck_horn
    title: Гул вантажівки
    trigger: {at_s: 40}
    effects: {sound: truck, caption: "повз проїжджає вантажівка"}
complications:
  - id: smoke
    title: З-під капота пішов дим
    effects: {panic: 2, sound: hiss, say: "З-під капота дим! Може, їх витягти?!"}
  - id: passerby
    title: Перехожий хоче витягати людей
    effects: {panic: 1, sound: crowd, say: "Тут чоловік зупинився, хоче їх витягувати!"}
branches:
  - {id: main, weight: 2, title: Стандарт}
  - id: three_victims
    weight: 1
    title: Третя людина на узбіччі
    facts:
      victims: {say: ["Двоє в салоні, і ще одна жінка лежить на узбіччі, її викинуло!"], truth: {victims: 3}}
protocol:
  base: standard
  remove: [floors]
  steps:
    - id: address_asked
      title: З'ясував місце (траса, кілометр, напрямок)
      example: "Де саме ви знаходитесь: яка траса, який кілометр і напрямок?"
    - id: fire_place
      title: "З'ясував, що саме сталося на місці (перекидання, займання, затиснуті)"
      example: "Що видно на місці: машина горить чи тече пальне, когось затиснуло?"
    - id: safety_advice
      title: "Безпека: не підходити до авто, не курити, аварійна сигналізація"
      deadline_s: 120
      rule: {keywords: ["не підходьте", "не куріть", "аварійн", "знак аварійної", "не витягуйте"]}
      example: "Не підходьте до машини і не куріть, тече пальне. Увімкніть аварійну сигналізацію і виставте знак."
    - id: victims_condition
      order: 6
      title: З'ясував стан постраждалих
      weight: 10
      source: "Статут дій у НС (наказ МВС від 26.04.2018 № 340), р. III, гл. 1, п. 8, абз. 3"
      basis: "норма"
      rule: {intent: condition}
      example: "Вони в свідомості? Чи є кровотеча?"
card_truth: {address: ["М-10", "15"], incident_type: ДТП, victims: 2, explosion: "так", access: ["узбіч"], caller_name: Ткач, phone: "0634501201"}
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112/backend && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -c "
from app.scenarios import Library
print(Library().errors.get('road-accident-02'))"
```
Очікується: `None`.

### Крок 28. Сценарій `shelling-rubble-01` (повний новий вміст)
Файл: `/Users/artem/Desktop/trainer112/scenarios/shelling-rubble-01.yaml`
Дія: ПЕРЕЗАПИСАТИ файл повністю (спочатку прочитайте наявний файл).

ВМІСТ ФАЙЛУ:
```yaml
# Адреса навчальна, номер будинку умовний.
id: shelling-rubble-01
title: Обстріл, людина під завалом
category: обстріл
difficulty: 3
brief: Після прильоту частково зруйновано під'їзд п'ятиповерхівки у Львові. Чоловік чує голос сусідки з-під завалу.
skills: [місце, люди під завалами, безпека рятівника]
max_duration_s: 360
silence_threshold_s: 4
legend:
  name: Віктор
  age: 47
  gender: male
  location: двір біля зруйнованого під'їзду
  sees: обвалився кут будинку, пил, з-під плит чути голос
  manner: говорить голосно через шум, кашляє від пилу, рішучий
  fillers: ["слухай", "короче", "кхе"]
  voice: male_50_rough
  opening: ["Алло! Приліт у будинок, людей завалило!", "Тут прилетіло! Під'їзд обвалився!"]
  unknown: ["Не знаю! Тут пил, нічого не видно!", "Не бачу я!"]
initial: {panic: 7, trust: 5}
facts:
  - id: strike
    say: ["Прилетіло в будинок, кут обвалився, третій під'їзд!"]
    reveal: {asked: [what, greeting], volunteer: true}
    truth: {incident_type: обстріл}
  - id: settlement
    say: ["Це Львів!"]
    reveal: {asked: [address]}
    critical: true
  - id: street
    say: ["Личаківська вулиця, будинок вісім."]
    reveal: {asked: [address, house], after_fact: settlement}
    critical: true
  - id: under_rubble
    say: ["З-під плит жінка кричить, сусідка з другого поверху!"]
    reveal: {asked: [people]}
    critical: true
    truth: {victims: 1}
  - id: more_people
    say: ["Ще люди виходять, у когось кров на голові."]
    reveal: {asked: [people, condition], after_fact: under_rubble}
  - id: gas_smell
    say: ["Тут ще й газом тягне!"]
    reveal: {asked: [condition, location_detail, danger], after_fact: strike}
  - id: floors
    say: ["Будинок п'ятиповерховий, п'ять поверхів."]
    reveal: {asked: [floors]}
    truth: {floors: 5}
  - id: access
    say: ["Уламки на проїзді, заїзд тільки з двору."]
    reveal: {asked: [access]}
  - id: wants_to_dig
    say: ["Я зараз полізу її відкопувати!"]
    reveal: {asked: [instruct, reassure, any], after_fact: under_rubble}
  - id: name
    say: ["Віктор Гаврилюк."]
    reveal: {asked: [name]}
    truth: {caller_name: Гаврилюк}
  - id: phone
    say: ["Нуль шістдесят сім, вісімсот, вісімдесят, вісімдесят."]
    reveal: {asked: [phone]}
events:
  - id: siren
    title: Повторна тривога
    trigger: {at_s: 60}
    effects: {panic: 1.5, sound: siren, say: "Знову сирена! Можуть ще прилетіти?!"}
  - id: no_address
    title: Адресу не з'ясовано
    trigger: {after_s: 40, unless_step: address_asked}
    effects: {panic: 1.5, say: "Ну ви записали?! Люди під завалами!"}
complications:
  - id: aftershock
    title: Обвал ще частини стіни
    effects: {panic: 2.5, sound: crash, say: "Ще шматок стіни впав! Пил кругом!"}
branches:
  - {id: main, weight: 1, title: Стандарт}
protocol:
  base: standard
  steps:
    - id: fire_place
      title: "З'ясував, що саме зруйновано і чи є загоряння"
      example: "Що видно на місці прильоту: що зруйновано, чи є вогонь?"
    - id: safety_advice
      title: "Безпека: не розбирати завал самостійно, відійти, в укриття"
      deadline_s: 120
      rule: {keywords: ["не розбирайте", "не лізьте", "відійдіть", "укритт", "не намагайтеся"]}
      example: "Не лізьте на завал і не розбирайте його самі, може обвалитися ще. Відійдіть від будинку, рятувальники вже їдуть."
card_truth: {address: ["Личаківська", "8"], incident_type: обстріл, victims: 1, explosion: "так", floors: 5, access: ["уламк", "двор"], caller_name: Гаврилюк, phone: "0678008080"}
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112/backend && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -c "
from app.scenarios import Library
print(Library().errors.get('shelling-rubble-01'))"
```
Очікується: `None`.

### Крок 29. Сценарій `co-poisoning-01` (повний новий вміст)
Файл: `/Users/artem/Desktop/trainer112/scenarios/co-poisoning-01.yaml`
Дія: ПЕРЕЗАПИСАТИ файл повністю (спочатку прочитайте наявний файл).

ВМІСТ ФАЙЛУ:
```yaml
# Адреса навчальна, номер будинку умовний.
id: co-poisoning-01
title: Задимів газовий котел, ознаки отруєння чадним газом
category: газ
difficulty: 2
brief: У приватному будинку в Сокільниках задимів газовий котел, у родини головний біль і нудота після того, як його увімкнули.
skills: [розпізнати загрозу, евакуація, кількість людей]
max_duration_s: 300
silence_threshold_s: 4
legend:
  name: Олег
  age: 45
  gender: male
  location: приватний будинок у селі Сокільники біля Львова
  sees: дружина лежить на дивані, діти скаржаться на голову, газовий котел працює і трохи димить
  manner: спершу спокійний і не розуміє небезпеки, потім лякається
  fillers: ["ну", "слухайте", "от"]
  voice: male_40
  opening: ["Добрий вечір… у нас всі якісь отруєні, голова болить і нудить.", "Алло… тут дружині погано, і дітям теж…"]
  unknown: ["Не знаю…", "Та звідки я знаю, я ж не лікар."]
initial: {panic: 3, trust: 5}
facts:
  - id: symptoms
    say: ["У всіх голова болить, нудить, дружина ледь встає."]
    reveal: {asked: [what, greeting], volunteer: true}
    truth: {incident_type: газ}
  - id: settlement
    say: ["Це село Сокільники, під Львовом."]
    reveal: {asked: [address]}
    critical: true
  - id: street
    say: ["Вулиця Лісова, будинок чотири."]
    reveal: {asked: [address, house], after_fact: settlement}
    critical: true
  - id: boiler
    say: ["Котел газовий увімкнули ввечері, перший раз цієї зими, і він димить."]
    reveal: {asked: [condition, location_detail, what, danger], after_fact: symptoms}
    critical: true
  - id: floors
    say: ["Один поверх, звичайна хата."]
    reveal: {asked: [floors]}
    truth: {floors: 1}
  - id: access
    say: ["До двору можна під'їхати, ворота відчинимо."]
    reveal: {asked: [access]}
  - id: family
    say: ["Нас четверо: я, дружина і двоє діток, сім і десять років."]
    reveal: {asked: [people]}
    critical: true
    truth: {victims: 4}
  - id: wife_unconscious
    say: ["Дружина не відповідає! Оля! Вона не відповідає!"]
    reveal: {after_s: 70}
  - id: name
    say: ["Олег Савчук."]
    reveal: {asked: [name]}
    truth: {caller_name: Савчук}
  - id: phone
    say: ["Нуль дев'яносто вісім, сто, двадцять, тридцять."]
    reveal: {asked: [phone]}
events:
  - id: wife_faints
    title: Дружина втрачає свідомість
    trigger: {at_s: 70}
    effects: {panic: 4, say: "Оля! Дружина не відповідає! Вона не відповідає!", reveal: [wife_unconscious]}
complications:
  - id: kid_vomits
    title: Дитину нудить
    effects: {panic: 1.5, say: "Малого знудило! Що робити?!"}
branches:
  - {id: main, weight: 1, title: Стандарт}
protocol:
  base: standard
  steps:
    - id: fire_place
      title: "З'ясував, що саме трапилося з котлом і чи є дим або вогонь"
      example: "Що видно біля котла: дим, полум'я, чутно запах?"
    - id: safety_advice
      title: "Безпека: негайно всім вийти на свіже повітря, вимкнути котел якщо безпечно"
      deadline_s: 120
      rule: {keywords: ["вийдіть на", "виведіть", "на свіже повітря", "на вулицю", "виходьте"]}
      example: "Негайно виведіть усіх на вулицю, на свіже повітря. Двері залиште відчиненими, у будинок не повертайтеся."
card_truth: {address: ["Сокільники", "Лісова", "4"], incident_type: газ, victims: 4, explosion: "так", floors: 1, caller_name: Савчук, phone: "0981002030"}
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112/backend && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -c "
from app.scenarios import Library
print(Library().errors.get('co-poisoning-01'))"
```
Очікується: `None`.

### Крок 30. Сценарій `drowning-01` (повний новий вміст)
Файл: `/Users/artem/Desktop/trainer112/scenarios/drowning-01.yaml`
Дія: ПЕРЕЗАПИСАТИ файл повністю (спочатку прочитайте наявний файл).

ВМІСТ ФАЙЛУ:
```yaml
# Місце навчальне: Винники, Винниківське озеро, пляж.
id: drowning-01
title: Дитина тоне на озері
category: рятування
difficulty: 2
brief: Підліток телефонує з пляжу біля Винниківського озера, друг пірнув і не виринає.
skills: [орієнтири на місцевості, швидкість, заборона ризикувати собою]
max_duration_s: 300
silence_threshold_s: 4
legend:
  name: Денис
  age: 14
  gender: male
  location: пляж біля Винниківського озера, місто Винники
  sees: друг пірнув з тарзанки, на воді бульбашки, нікого не видно
  manner: підліток, говорить швидко, плутає слова, кричить на друга
  fillers: ["ну", "типу", "короче"]
  voice: male_14
  opening: ["Алло! Тут друг пірнув і не виринає!", "Допоможіть! Він під водою!"]
  unknown: ["Я не знаю!", "Не знаю, я не місцевий…"]
initial: {panic: 8, trust: 4}
facts:
  - id: drowning
    say: ["Мій друг Вова пірнув з тарзанки і не виринає вже хвилину!"]
    reveal: {asked: [what, greeting], volunteer: true}
    truth: {incident_type: рятування}
  - id: settlement
    say: ["Це Винники, Винниківське озеро!"]
    reveal: {asked: [address]}
    critical: true
  - id: landmark
    say: ["Пляж біля стоянки, там де тарзанка на вербі."]
    reveal: {asked: [location_detail, house, address], after_fact: settlement}
    critical: true
  - id: access
    say: ["Машина може заїхати до пляжу з боку стоянки."]
    reveal: {asked: [access]}
  - id: people
    say: ["Нас тут троє було, ще Саша є, але він теж не вміє плавати добре."]
    reveal: {asked: [people]}
    truth: {victims: 1}
  - id: wants_to_dive
    say: ["Я зараз сам пірну за ним!"]
    reveal: {after_s: 30, asked: [instruct, reassure, any]}
  - id: name
    say: ["Денис Романюк."]
    reveal: {asked: [name]}
    truth: {caller_name: Романюк}
  - id: phone
    say: ["Нуль дев'яносто сім, п'ятсот п'ятдесят, нуль нуль, одинадцять."]
    reveal: {asked: [phone]}
  - id: adults
    say: ["Дорослих тут нема, тільки рибалка далеко на тому березі!"]
    reveal: {asked: [people, condition], after_fact: people}
events:
  - id: surfaced
    title: Друг на мить виринув
    trigger: {at_s: 75}
    effects: {panic: 1, sound: splash, say: "Он він! Виринув! Ой, знову під воду пішов!"}
  - id: no_location
    title: Місце не з'ясовано
    trigger: {after_s: 40, unless_step: address_asked}
    effects: {panic: 2, say: "Ну скоро?! Він же втопиться!"}
complications:
  - id: friend_jumps
    title: Інший друг стрибає у воду
    effects: {panic: 2, sound: splash, say: "Саша стрибнув у воду за ним! Що робити?!"}
branches:
  - {id: main, weight: 1, title: Стандарт}
protocol:
  base: standard
  remove: [floors]
  steps:
    - id: address_asked
      title: З'ясував місце і орієнтири
      example: "Де ви знаходитесь: яке місце, біля чого саме озеро?"
    - id: address_confirmed
      deadline_s: 80
    - id: fire_place
      title: "З'ясував точне місце на воді (де людину бачили востаннє)"
      example: "Що видно на воді: з якого боку людину бачили востаннє?"
    - id: safety_advice
      title: "Безпека: не стрибати у воду, кинути щось плавуче, кликати дорослих"
      deadline_s: 120
      rule: {keywords: ["не стрибайте", "не пірнайте", "не заходьте у воду", "киньте"]}
      example: "Не стрибайте у воду самі. Киньте йому щось, що плаває, і кличте дорослих."
card_truth: {address: ["Винники"], incident_type: рятування, victims: 1, access: ["стоянк", "пляж"], caller_name: Романюк, phone: "0975500011"}
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112/backend && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -c "
from app.scenarios import Library
print(Library().errors.get('drowning-01'))"
```
Очікується: `None`.

### Крок 31. Сценарій `elderly-fall-01` (повний новий вміст)
Файл: `/Users/artem/Desktop/trainer112/scenarios/elderly-fall-01.yaml`
Дія: ПЕРЕЗАПИСАТИ файл повністю (спочатку прочитайте наявний файл).

ВМІСТ ФАЙЛУ:
```yaml
# Адреса навчальна, номер будинку умовний.
id: elderly-fall-01
title: Літня жінка за зачиненими дверима
category: рятування
difficulty: 1
brief: Самотня пенсіонерка у Львові впала вдома і не може встати, двері замкнені зсередини, ключів ні в кого немає. Вона дезорієнтована, недовірлива, називає стару назву вулиці.
skills: [терпіння, довіра, уточнення адреси, доступ до квартири]
max_duration_s: 300
silence_threshold_s: 5
legend:
  name: Віра Іванівна
  age: 81
  gender: female
  location: власна квартира на першому поверсі п'ятиповерхівки у Львові
  sees: лежить на підлозі в коридорі, телефон дотягнула з тумбочки
  manner: говорить повільно, тихо, часто перепитує, не довіряє «молодим»
  fillers: ["дитино", "ох", "як його"]
  voice: female_80
  opening: ["Ох… алло… це лікарня?", "Алло… дитино… я впала…"]
  unknown: ["Ох, не пам'ятаю я, дитино…", "Що ви кажете? Не чую…"]
initial: {panic: 4, trust: 3}
facts:
  - id: fell
    say: ["Я впала в коридорі… встати не можу, нога болить."]
    reveal: {asked: [what, greeting], volunteer: true}
    truth: {incident_type: рятування}
  - id: street
    say: ["Пушкінська вулиця… ой, її ж перейменували… Сагайдачного тепер."]
    reveal: {asked: [address], min_trust: 3.5}
    critical: true
  - id: house
    say: ["Будинок сорок, квартира сім."]
    reveal: {asked: [house], min_trust: 4.5}
    critical: true
  - id: door_locked
    say: ["Двері замкнені зсередини, а ключів ні в кого нема, я ж сама живу."]
    reveal: {asked: [instruct, apartment, location_detail]}
  - id: floors
    say: ["П'ять поверхів, а я на першому."]
    reveal: {asked: [floors]}
    truth: {floors: 5}
  - id: access
    say: ["До під'їзду можна підійти з двору, там відкрито."]
    reveal: {asked: [access]}
  - id: alone
    say: ["Сама я живу, дитино, нікого нема."]
    reveal: {asked: [people]}
    truth: {victims: 1}
  - id: hip
    say: ["Стегно болить, ліве, як ворухнусь — аж в очах темніє."]
    reveal: {asked: [condition]}
  - id: name
    say: ["Віра Іванівна Шевчук."]
    reveal: {asked: [name]}
    truth: {caller_name: Шевчук}
  - id: phone
    say: ["Номер… ох… нуль сорок чотири… ні, не пам'ятаю."]
    reveal: {asked: [phone]}
events:
  - id: dizzy
    title: Паморочиться голова
    trigger: {at_s: 90}
    effects: {panic: 1.5, say: "Ох… щось голова паморочиться…"}
complications:
  - id: hangs_up
    title: Хоче покласти слухавку
    effects: {trust: -1.5, say: "Та нащо вам все це… Покладу я слухавку, полежу."}
branches:
  - {id: main, weight: 1, title: Стандарт}
protocol:
  base: standard
  remove: [fire_place]
  steps:
    - id: address_asked
      deadline_s: 40
    - id: address_confirmed
      deadline_s: 100
    - id: safety_advice
      title: "Безпека: не намагатися вставати, вкритися, чекати"
      deadline_s: 150
      rule: {keywords: ["не вставайте", "не намагайтеся встати", "не рухайтеся", "лежіть"]}
      example: "Не намагайтеся вставати, лежіть спокійно. Чи можете дотягнутися до ковдри?"
    - id: door_access
      order: 7
      title: З'ясував доступ у квартиру (двері, ключ)
      weight: 5
      source: "Статут дій у НС (наказ МВС від 26.04.2018 № 340), р. III, гл. 1, п. 8, абз. 4"
      basis: "норма"
      rule: {keywords: ["двері", "ключ", "відчинити", "доступ"]}
      example: "Двері замкнені? Як бригада зможе зайти до вас?"
card_truth: {address: ["Сагайдачного", "40"], incident_type: рятування, victims: 1, floors: 5, caller_name: Шевчук}
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112/backend && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -c "
from app.scenarios import Library
print(Library().errors.get('elderly-fall-01'))"
```
Очікується: `None`.

### Крок 32. Новий сценарій `apartment-fire-01`
Файл: `/Users/artem/Desktop/trainer112/scenarios/apartment-fire-01.yaml`
Дія: СТВОРИТИ новий файл (раніше його не було).

ВМІСТ ФАЙЛУ:
```yaml
# Адреса навчальна, номер будинку умовний.
id: apartment-fire-01
title: Пожежа в квартирі багатоповерхівки
category: пожежа
difficulty: 2
brief: Сусідка з верхнього поверху бачить дим і полум'я з вікна квартири у Львові, у квартирі живе літній чоловік.
skills: [адреса, люди в квартирі, сигнал Тривога, безпека в під'їзді]
max_duration_s: 300
silence_threshold_s: 4
legend:
  name: Оксана
  age: 45
  gender: female
  location: власна квартира на шостому поверсі дев'ятиповерхового будинку у Львові
  sees: дим іде в коридор і в під'їзд, з вікна нижньої квартири видно полум'я
  manner: говорить швидко і голосно, нервує, перепитує
  fillers: ["ой", "ну", "значить"]
  voice: female_40_loud
  opening: ["Алло! Пожежа! У сусіда знизу горить квартира!", "Алло! Горить квартира, дим іде в під'їзд!"]
  unknown: ["Не знаю я!", "Ой, звідки ж мені знати?!"]
initial: {panic: 7, trust: 4}
facts:
  - id: fire
    say: ["У сусіда знизу горить кухня, з вікна дим і полум'я!"]
    reveal: {asked: [what, greeting], volunteer: true}
    truth: {incident_type: пожежа}
  - id: settlement
    say: ["Це Львів!"]
    reveal: {asked: [address]}
    critical: true
  - id: street
    say: ["Вулиця Сихівська!", "Сихівська вулиця."]
    reveal: {asked: [address]}
    critical: true
  - id: house
    say: ["Будинок шістнадцять."]
    reveal: {asked: [house], max_panic: 9.5}
    critical: true
  - id: apartment
    say: ["Горить на п'ятому поверсі, а я на шостому."]
    reveal: {asked: [apartment]}
  - id: old_neighbor
    say: ["Там живе літній сусід, дід Петро, він сам! Двері не відчиняє!"]
    say_panic: ["Там дід Петро! Він сам! Двері не відчиняє!"]
    reveal: {asked: [people]}
    critical: true
    truth: {victims: 1}
  - id: stairs_smoke
    say: ["На сходах густий дим, нічого не видно!"]
    reveal: {asked: [location_detail, condition]}
  - id: floors
    say: ["Дев'ять поверхів."]
    reveal: {asked: [floors]}
    truth: {floors: 9}
  - id: access
    say: ["Двір заставлений автомобілями, пожежній машині буде тісно."]
    reveal: {asked: [access]}
  - id: gas_stove
    say: ["Плита там газова, а балонів у будинку нема."]
    reveal: {asked: [danger, condition, instruct], after_fact: fire}
    truth: {explosion: "ні"}
  - id: wants_to_go_down
    say: ["Я зараз побіжу вниз по сходах!"]
    reveal: {asked: [instruct, reassure, any], after_fact: old_neighbor}
  - id: name
    say: ["Оксана Гнатів."]
    reveal: {asked: [name]}
    truth: {caller_name: Гнатів}
  - id: phone
    say: ["Нуль шістдесят три, сто одинадцять, дванадцять, двадцять три."]
    reveal: {asked: [phone]}
events:
  - id: smoke_in_flat
    title: Дим вже в коридорі
    trigger: {at_s: 60}
    effects: {panic: 2, say: "Дим уже в мене в коридорі! Дихати нічим!"}
  - id: no_address
    title: Адресу не з'ясовано
    trigger: {after_s: 40, unless_step: address_asked}
    effects: {panic: 1.5, say: "Ну ви їдете чи ні?! Горить же!"}
complications:
  - id: neighbors
    title: Сусіди збігаються в під'їзд
    effects: {panic: 1, sound: crowd, say: "Тут сусіди вибігли на сходи, кричать!"}
  - id: glass
    title: Тріснуло скло
    effects: {panic: 1.5, sound: glass, say: "Вікно лопнуло! Скло падає у двір!"}
branches:
  - {id: main, weight: 1, title: Стандарт}
protocol:
  base: standard
  steps:
    - id: fire_place
      title: "З'ясував, де саме горить і що видно (дим, полум'я)"
      example: "Що видно: дим чи полум'я, на якому поверсі горить?"
    - id: safety_advice
      title: "Безпека: зачинити двері, не виходити в дим, не користуватися ліфтом"
      deadline_s: 120
      rule: {keywords: ["зачиніть двері", "не виходьте", "не спускайтеся", "намочіть", "не користуйтеся ліфтом"]}
      example: "Зачиніть вхідні двері і не виходьте в дим. Намочіть ганчірку і заткніть щілини, не користуйтеся ліфтом."
card_truth: {address: ["Львів", "Сихівська", "16"], incident_type: пожежа, victims: 1, explosion: "ні", floors: 9, access: ["машин", "заставл"], caller_name: Гнатів, phone: "0631112233"}
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112/backend && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -c "
from app.scenarios import Library
print(Library().errors.get('apartment-fire-01'))"
```
Очікується: `None`.

### Крок 33. Новий сценарій `grass-fire-01`
Файл: `/Users/artem/Desktop/trainer112/scenarios/grass-fire-01.yaml`
Дія: СТВОРИТИ новий файл (раніше його не було).

ВМІСТ ФАЙЛУ:
```yaml
# Адреса навчальна, орієнтир умовний: номера будинку немає.
id: grass-fire-01
title: Горить суха трава біля дачних будинків
category: пожежа
difficulty: 1
brief: Пенсіонер бачить, як у кінці вулиці в Рудному горить суха трава, вітер жене вогонь до дач.
skills: [адреса без номера будинку, орієнтир, сигнал Тривога]
max_duration_s: 300
silence_threshold_s: 5
legend:
  name: Василь
  age: 67
  gender: male
  location: біля своєї дачі в кінці вулиці в селі Рудне біля Львова
  sees: суха трава горить у полі за останніми будинками, вітер жене вогонь до дач
  manner: говорить повільно, хвилюється, перепитує
  fillers: ["ну", "слухайте", "значить"]
  voice: male_60
  opening: ["Алло, пожежні? Тут трава горить, до дач іде!", "Алло! Поле горить біля наших дач!"]
  unknown: ["Не знаю, синку.", "Ой, не скажу."]
initial: {panic: 5, trust: 5}
facts:
  - id: fire
    say: ["Суха трава горить, вітер несе вогонь просто до дач!"]
    reveal: {asked: [what, greeting], volunteer: true}
    truth: {incident_type: пожежа}
  - id: settlement
    say: ["Це село Рудне!"]
    reveal: {asked: [address]}
    critical: true
  - id: street
    say: ["Вулиця Лісова, в самому кінці, де поле."]
    reveal: {asked: [address]}
    critical: true
  - id: no_people
    say: ["У полі нікого не бачу, а в крайній дачі може бути сусід."]
    reveal: {asked: [people]}
    critical: true
    truth: {victims: 0}
  - id: gas_bottle
    say: ["Біля крайньої дачі стоїть газовий балон, вогонь уже недалеко!"]
    reveal: {asked: [danger, condition, instruct], after_fact: fire}
    truth: {explosion: "так"}
  - id: access
    say: ["Ґрунтова дорога, після дощу розкисла, вантажівка пройде тільки з боку асфальту."]
    reveal: {asked: [access]}
  - id: name
    say: ["Василь Дячук."]
    reveal: {asked: [name]}
    truth: {caller_name: Дячук}
  - id: phone
    say: ["Нуль шістдесят шість, двісті тридцять чотири, п'ятдесят шість, сімдесят вісім."]
    reveal: {asked: [phone]}
events:
  - id: wind
    title: Вітер посилюється
    trigger: {at_s: 70}
    effects: {panic: 1.5, say: "Вітер дужчає! Вогонь біжить до дач!"}
  - id: no_address
    title: Адресу не з'ясовано
    trigger: {after_s: 45, unless_step: address_asked}
    effects: {panic: 1, say: "Ну що ви мовчите? Горить же!"}
complications:
  - id: wants_to_beat
    title: Хоче збивати вогонь сам
    effects: {panic: 1, say: "Я піду лопатою збивати вогонь!"}
branches:
  - {id: main, weight: 1, title: Стандарт}
protocol:
  base: standard
  remove: [floors]
  steps:
    - id: fire_place
      title: "З'ясував, що горить і куди рухається вогонь"
      example: "Що горить і в який бік іде вогонь?"
    - id: safety_advice
      title: "Безпека: відійти, самому не гасити, триматися з навітряного боку"
      deadline_s: 120
      rule: {keywords: ["відійдіть", "не гасіть самі", "безпечну відстань", "з навітряного боку", "не намагайтеся"]}
      example: "Відійдіть на безпечну відстань, самі не гасіть. Стійте з навітряного боку."
card_truth: {address: ["Рудне", "Лісова"], incident_type: пожежа, victims: 0, explosion: "так", access: ["ґрунтов", "асфальт"], caller_name: Дячук, phone: "0663234567"}
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112/backend && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -c "
from app.scenarios import Library
print(Library().errors.get('grass-fire-01'))"
```
Очікується: `None`.

### Крок 34. Новий сценарій `car-fire-01`
Файл: `/Users/artem/Desktop/trainer112/scenarios/car-fire-01.yaml`
Дія: СТВОРИТИ новий файл (раніше його не було). Увага: літери в `ГБО` кириличні.

ВМІСТ ФАЙЛУ:
```yaml
# Адреса навчальна, номер будинку умовний.
id: car-fire-01
title: Горить автомобіль на парковці
category: пожежа
difficulty: 2
brief: Охоронець відкритої парковки у Львові бачить, що горить легковик на газу, поряд стоять інші машини.
skills: [адреса, небезпека газового балона, безпека людей навколо]
max_duration_s: 300
silence_threshold_s: 4
legend:
  name: Ігор
  age: 29
  gender: male
  location: будка охорони на відкритій парковці у Львові
  sees: з-під капота легковика полум'я, поряд ще три машини, люди знімають на телефон
  manner: говорить швидко, намагається бути чітким, але хвилюється
  fillers: ["так", "ну", "значить"]
  voice: male_30
  opening: ["Алло! На парковці горить машина!", "Алло, пожежна? Авто горить на стоянці!"]
  unknown: ["Не знаю.", "Звідки ж мені знати?"]
initial: {panic: 6, trust: 5}
facts:
  - id: fire
    say: ["Горить легковик, з-під капота вже полум'я!"]
    reveal: {asked: [what, greeting], volunteer: true}
    truth: {incident_type: пожежа}
  - id: settlement
    say: ["Це Львів!"]
    reveal: {asked: [address]}
    critical: true
  - id: street
    say: ["Вулиця Стрийська, відкрита парковка."]
    reveal: {asked: [address]}
    critical: true
  - id: house
    say: ["Будинок тридцять."]
    reveal: {asked: [house], max_panic: 9.5}
    critical: true
  - id: no_people
    say: ["В автівці нікого нема, але люди стоять близько і знімають на телефон."]
    reveal: {asked: [people]}
    critical: true
    truth: {victims: 0}
  - id: gas_equipment
    say: ["Автівка на газу, там балон, це вже може вибухнути!"]
    reveal: {asked: [danger, condition, instruct], after_fact: fire}
    truth: {explosion: "так"}
  - id: neighbors_cars
    say: ["Поряд ще три машини стоять, впритул."]
    reveal: {asked: [location_detail]}
  - id: access
    say: ["В'їзд через шлагбаум, охорона відкриє."]
    reveal: {asked: [access]}
  - id: name
    say: ["Ігор Бойко."]
    reveal: {asked: [name]}
    truth: {caller_name: Бойко}
  - id: phone
    say: ["Нуль дев'яносто п'ять, дев'ятсот вісімдесят, сімдесят, сорок."]
    reveal: {asked: [phone]}
events:
  - id: crowd_closer
    title: Люди підходять ближче
    trigger: {at_s: 50}
    effects: {panic: 1.5, sound: crowd, say: "Люди підходять ближче знімати! Куди ви лізете?!"}
  - id: no_address
    title: Адресу не з'ясовано
    trigger: {after_s: 40, unless_step: address_asked}
    effects: {panic: 1.5, say: "Ну ви їдете чи ні? Горить же!"}
complications:
  - id: pop
    title: Хлопок під капотом
    effects: {panic: 2, sound: crash, say: "Щось хлопнуло під капотом! Полум'я вище!"}
branches:
  - {id: main, weight: 1, title: Стандарт}
protocol:
  base: standard
  remove: [floors]
  steps:
    - id: fire_place
      title: "З'ясував, що горить і чи є поруч інші автомобілі"
      example: "Що видно: що саме горить, чи стоять поруч інші машини?"
    - id: safety_advice
      title: "Безпека: відвести людей, не підходити до авто з газом"
      deadline_s: 120
      rule: {keywords: ["відійдіть", "відведіть людей", "не підходьте", "безпечну відстань"]}
      example: "Відведіть людей на безпечну відстань і не підходьте до автівки, там газовий балон."
card_truth: {address: ["Стрийська", "30"], incident_type: пожежа, victims: 0, explosion: "так", access: ["шлагбаум"], caller_name: Бойко, phone: "0959807040"}
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112/backend && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -c "
from app.scenarios import Library
print(Library().errors.get('car-fire-01'))"
```
Очікується: `None`.

### Крок 35. Перевірка наявності джерела (source) у кроків протоколу
Файл: `/Users/artem/Desktop/trainer112/backend/app/scenarios.py`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```python
        errors.append("protocol: потрібен хоча б один критичний крок")
```

ЗАМІНИТИ НА:
```python
        errors.append("protocol: потрібен хоча б один критичний крок")
    for s in steps:
        if not s.source:
            errors.append(f"protocol.{s.id}: не вказано джерело (source)")
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112/backend && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -c "
from app.scenarios import Library
lib = Library()
print(len(lib.items), sorted(lib.errors))"
```
Очікується: `10 []`.

### Крок 36. Тести API: фраза оператора
Файл: `/Users/artem/Desktop/trainer112/tests/test_api.py`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```python
"Служба 112. Що сталося? Назвіть адресу."
```

ЗАМІНИТИ НА:
```python
"Пожежно-рятувальна частина, оператор курсант Тест. Що сталося? Назвіть адресу."
```

### Крок 37. Тести API: два нові тести
Файл: `/Users/artem/Desktop/trainer112/tests/test_api.py`
Дія: замінити один фрагмент (додати два тести в кінець файлу).

ЗНАЙТИ:
```python
    r = c.post("/api/scenarios/gas-leak-03/botcheck").json()
    assert r["ok"], r
```

ЗАМІНИТИ НА:
```python
    r = c.post("/api/scenarios/gas-leak-03/botcheck").json()
    assert r["ok"], r


def test_random_call_hides_scenario():
    with TestClient(app) as c:
        cid = c.post("/api/calls", json={"trainee": "Т", "scenario_id": "random"}).json()["call_id"]
        with c.websocket_connect(f"/ws/call/{cid}?role=trainee") as ws:
            snap = ws.receive_json()["payload"]
            for k in ("scenario_title", "scenario_brief", "category", "scenario"):
                assert k not in snap, k
            rows = c.get("/api/sessions?trainee=Т").json()
            assert [x for x in rows if x["id"] == cid][0]["scenario_id"] == "random"
            ws.send_json({"type": "call.accept"})
            recv_until(ws, "tts.say")
            ws.send_json({"type": "call.end", "payload": {"reason": "operator"}})
            recv_until(ws, "report.ready")
    s = c.get(f"/api/sessions/{cid}").json()
    assert s["report"]["scenario_title"]
    assert s["scenario_id"] != "random"


def test_action_alarm_marks_step():
    with TestClient(app) as c:
        cid = c.post("/api/calls", json={"trainee": "Т3", "scenario_id": "house-fire-01", "seed": 2}).json()["call_id"]
        with c.websocket_connect(f"/ws/call/{cid}?role=trainee") as ws:
            ws.receive_json()
            ws.send_json({"type": "call.accept"})
            recv_until(ws, "tts.say")
            ws.send_json({"type": "operator.action", "payload": {"action": "alarm"}})
            ws.send_json({"type": "call.end", "payload": {"reason": "operator"}})
            recv_until(ws, "report.ready")
    s = c.get(f"/api/sessions/{cid}").json()
    step = [x for x in s["report"]["checklist"] if x["step_id"] == "alarm"][0]
    assert step["done"] is True
    assert step["quote"].startswith("Дія:")
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -m pytest -q -p no:cacheprovider tests/test_api.py 2>&1 | tail -3
```
Очікується: рядок `5 passed` (і, можливо, 1 warning).

### Крок 38. Тести модулів: імпорти
Файл: `/Users/artem/Desktop/trainer112/tests/test_units.py`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```python
from app.agents.normalizer import Normalizer, extract, words_to_numbers
```

ЗАМІНИТИ НА:
```python
from app.agents.evaluator import compare_card
from app.agents.normalizer import Normalizer, extract, words_to_numbers
```

### Крок 39. Тести модулів: нові тести
Файл: `/Users/artem/Desktop/trainer112/tests/test_units.py`
Дія: замінити один фрагмент (додати нові тести після `test_intents_require_question`).

ЗНАЙТИ:
```python
    assert "address" not in intents("Виходьте з квартири.")
```

ЗАМІНИТИ НА:
```python
    assert "address" not in intents("Виходьте з квартири.")


def test_every_protocol_step_has_source():
    from app.scenarios import resolve_steps
    lib = Library()
    assert lib.errors == {}
    for sid, sc in lib.items.items():
        for s in resolve_steps(sc.protocol):
            assert s.source, (sid, s.id)
            assert s.basis in ("норма", "методична", "потребує підтвердження"), (sid, s.id, s.basis)


def test_nlu_floors_vs_people():
    got = intents("Скільки поверхів у будівлі?")
    assert "floors" in got and "people" not in got and "address" not in got
    assert "people" in intents("Скільки людей у квартирі?")


def test_nlu_access_and_danger():
    assert "access" in intents("Чи може пожежна машина під'їхати до будинку?")
    assert "access" in intents("Там є шлагбаум або ворота?")
    assert "danger" in intents("Чи є поруч газовий балон?")
    assert "danger" in intents("Чи є загроза вибуху?")


def test_nlu_greeting_of_fire_unit():
    assert "greeting" in intents("Пожежно-рятувальна частина, черговий слухає. Що сталося?")


def test_compare_card_modes():
    truth = {"phone": "0631112233", "floors": 9, "access": ["шлагбаум", "ворота"]}
    card = {"phone": "+38 (063) 111-22-33", "floors": "9", "access": "шлагбаум на в'їзді"}
    res = {r["field"]: r["ok"] for r in compare_card(card, truth)}
    assert res == {"floors": True, "access": True, "phone": True}
    bad = {"phone": "0631112200", "floors": "8", "access": "гараж"}
    res = {r["field"]: r["ok"] for r in compare_card(bad, truth)}
    assert res == {"floors": False, "access": False, "phone": False}


def test_normalizer_lviv_addresses():
    assert extract("Сихівська, шістнадцять")["address"] == {"street": "Сихівська", "house": "16"}
    got = extract("Брюховичі, вулиця Польова, п'ятнадцять")["address"]
    assert got["settlement"] == "Брюховичі" and got["house"] == "15"


def test_archive_scenarios_are_not_loaded():
    lib = Library()
    for sid in ("cardiac-arrest-01", "child-choking-01", "domestic-violence-01"):
        assert sid not in lib.items
        assert (SCENARIO_DIR / "archive" / f"{sid}.yaml").exists()
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -m pytest -q -p no:cacheprovider tests/test_units.py 2>&1 | tail -3
```
Очікується: рядок `18 passed` (і, можливо, 1 warning).

### Контрольна точка 2. Бекенд і тести завершено
ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -m pytest -q -p no:cacheprovider . 2>&1 | tail -3
```
Очікується: рядок `73 passed` (і, можливо, `1 warning`). Жодного `failed` чи `error`.

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112/backend && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -c "
import asyncio
from app.bot import run_bot_call
from app.service import Trainer
async def main():
    tr = Trainer(db_path=':memory:')
    bad = 0
    n = 0
    for sid, sc in sorted(tr.library.items.items()):
        for b in sc.branches:
            for seed in (1, 2, 3):
                n += 1
                o = await tr.start_call('bot', sid, seed=seed, branch=b.id, sim=True)
                rep = await run_bot_call(o, 'ideal')
                if not rep['passed'] or rep['score'] < 90 or rep['guard_blocked']:
                    bad += 1
                    print('FAIL ideal', sid, b.id, seed, rep['score'], rep['missed_critical'])
                o = await tr.start_call('bot', sid, seed=seed, branch=b.id, sim=True)
                rep = await run_bot_call(o, 'forgets_address')
                if rep['passed']:
                    bad += 1
                    print('FAIL forgets', sid, b.id, seed)
    print('запусків', n, 'невдач', bad)
asyncio.run(main())"
```
Очікується: останній рядок `запусків 39 невдач 0` (10 сценаріїв, 13 гілок разом, по 3 зерна). Якщо кількість запусків інша, але `невдач 0`, це теж нормально; важливо, щоб не було жодного рядка `FAIL`.

---

# ЧАСТИНА 3. Фронтенд

Усі кроки цієї частини змінюють лише видимі тексти й екран виклику. Ключі `t112.*`, `trainer112`, `window.__T112_FILES` і шляхи `/t112/` НЕ чіпайте.

### Крок 40. `index.html`: назва вкладки
Файл: `/Users/artem/Desktop/trainer112/frontend/index.html`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```html
  <title>Тренажер 112</title>
```

ЗАМІНИТИ НА:
```html
  <title>Тренажер оператора ПЗЧ</title>
```

### Крок 41. `index.html`: значок вкладки
Файл: `/Users/artem/Desktop/trainer112/frontend/index.html`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```html
%3E112%3C/text%3E
```

ЗАМІНИТИ НА:
```html
%3E101%3C/text%3E
```

### Крок 42. `core.js`: колір категорії «рятування»
Файл: `/Users/artem/Desktop/trainer112/frontend/js/core.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
  "насильство": "violet", "отруєння": "amber", "обстріл": "red",
```

ЗАМІНИТИ НА:
```javascript
  "насильство": "violet", "отруєння": "amber", "обстріл": "red", "рятування": "blue",
```

### Крок 43. `core.js`: іконка категорії «рятування»
Файл: `/Users/artem/Desktop/trainer112/frontend/js/core.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
  "обстріл":    { icon: "alert",  tint: "#f1f1f1", label: "Обстріл" },
```

ЗАМІНИТИ НА:
```javascript
  "обстріл":    { icon: "alert",  tint: "#f1f1f1", label: "Обстріл" },
  "рятування":  { icon: "shield", tint: "#e3f4f8", label: "Рятування" },
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && node --check frontend/js/core.js && echo core-ok
```
Очікується: `core-ok`.

### Крок 44. `app.js`: значок і назва в шапці
Файл: `/Users/artem/Desktop/trainer112/frontend/js/app.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
h("span.brand-badge", "112"), "Тренажер оператора"));
```

ЗАМІНИТИ НА:
```javascript
h("span.brand-badge", "101"), "Тренажер оператора ПЗЧ"));
```

### Крок 45. `app.js`: плитка курсанта на вході
Файл: `/Users/artem/Desktop/trainer112/frontend/js/app.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
"Приймає дзвінки, отримує розбір і рекомендації"
```

ЗАМІНИТИ НА:
```javascript
"Приймає повідомлення на пункті зв'язку частини, отримує розбір"
```

### Крок 46. `app.js`: заголовок входу
Файл: `/Users/artem/Desktop/trainer112/frontend/js/app.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
    h("h1", "Тренажер оператора 112"),
    h("p.muted", "Керована симуляція екстреного дзвінка з розбором після кожної сесії."),
```

ЗАМІНИТИ НА:
```javascript
    h("h1", "Тренажер оператора ПЗЧ"),
    h("p.muted", "Прийом повідомлень про пожежу та інші події. Навчальна пожежно-рятувальна частина ЛДУБЖД."),
```

### Крок 47. `app.js`: головна сторінка, секція «Почати тренування»
Файл: `/Users/artem/Desktop/trainer112/frontend/js/app.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
      h("p.muted.m-0", "Оберіть сценарій. Дзвінок почнеться, щойно ви приймете виклик.")),
    progressCard(mine))));
```

ЗАМІНИТИ НА:
```javascript
      h("p.muted.m-0", "Почніть тренування або оберіть ситуацію в бібліотеці нижче.")),
    progressCard(mine))));

  app.append(h("section.section.panel",
    h("h2", "Почати тренування"),
    h("p.muted", "Система сама обере ситуацію. Яку саме, ви дізнаєтеся після завершення дзвінка."),
    h("div.row",
      h("button.btn.primary.big", { type: "button", on: { click: (e) => startRandom(user, e.currentTarget) } }, ic("phone"), "Почати тренування"),
      h("button.btn.big", { type: "button", on: { click: () => { const el = document.getElementById("library"); if (el) el.scrollIntoView({ behavior: "smooth" }); } } }, "Обрати ситуацію"))));
```

### Крок 48. `app.js`: бібліотека ситуацій
Файл: `/Users/artem/Desktop/trainer112/frontend/js/app.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
  app.append(h("div.section",
    h("div.section-title", h("h2", "Бібліотека сценаріїв"), h("span.muted.small", plural(valid.length, ["сценарій", "сценарії", "сценаріїв"]))),
```

ЗАМІНИТИ НА:
```javascript
  app.append(h("div.section", { id: "library" },
    h("div.section-title", h("h2", "Бібліотека ситуацій"), h("span.muted.small", plural(valid.length, ["ситуація", "ситуації", "ситуацій"]))),
```

### Крок 49. `app.js`: історія, випадкова ситуація
Файл: `/Users/artem/Desktop/trainer112/frontend/js/app.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
        h("td", (byId[s.scenario_id] || {}).title || s.scenario_id, s.parent_id
```

ЗАМІНИТИ НА:
```javascript
        h("td", s.scenario_id === "random" ? "Випадкова ситуація" : (byId[s.scenario_id] || {}).title || s.scenario_id, s.parent_id
```

### Крок 50. `app.js`: функція `startRandom`
Файл: `/Users/artem/Desktop/trainer112/frontend/js/app.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
export { toast, fmtT };
```

ЗАМІНИТИ НА:
```javascript
export async function startRandom(user, btn = null) {
  if (starting) return;
  starting = true; if (btn) btn.disabled = true;
  try {
    const r = await api.post("/api/calls", { trainee: user.name, scenario_id: "random", options: { show_indicators: false, adaptive: true } });
    location.hash = `#/call/${r.call_id}`;
  } catch (e) { toast(friendly(e), 5000); if (btn) btn.disabled = false; } finally { starting = false; }
}
export { toast, fmtT };
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && node --check frontend/js/app.js && echo app-ok && grep -c "startRandom" frontend/js/app.js
```
Очікується: `app-ok`, а під ним `2` (рядок з кнопкою з кроку 47 і рядок `export async function startRandom` з кроку 50). Якщо число інше, повторно перевірте кроки 47 і 50.

### Крок 51. `callScreen.js`: назва екрана і лінії
Файл: `/Users/artem/Desktop/trainer112/frontend/js/callScreen.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
  title: 'Виклик 112',
  line: 'Лінія 112',
```

ЗАМІНИТИ НА:
```javascript
  title: 'Прийом повідомлення',
  line: 'Лінія 101',
```

### Крок 52. `callScreen.js`: текст вхідного виклику
Файл: `/Users/artem/Desktop/trainer112/frontend/js/callScreen.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
    p: 'Абонент на лінії. Перевірте мікрофон і приймайте виклик.',
```

ЗАМІНИТИ НА:
```javascript
    p: 'Заявник на лінії. Перевірте мікрофон і прийміть виклик.',
```

### Крок 53. `callScreen.js`: тексти картки виклику
Файл: `/Users/artem/Desktop/trainer112/frontend/js/callScreen.js`
Дія: замінити один фрагмент (весь блок `card: { ... },`).

ЗНАЙТИ:
```javascript
  card: {
    title: 'Картка виклику',
    where: 'Де це сталося',
    what: 'Що сталося',
    victims: 'Постраждалі',
    who: 'Хто телефонує',
    notes: 'Нотатки',
    city: 'Населений пункт',
    street: 'Вулиця',
    house: 'Будинок',
    flat: 'Квартира',
    landmark: 'Орієнтир',
    count: 'Скільки людей постраждало',
    state: 'Стан постраждалих',
    name: 'Ім’я абонента',
    phone: 'Телефон',
    notesLbl: 'Важливі деталі',
  },
```

ЗАМІНИТИ НА:
```javascript
  card: {
    title: 'Картка виклику',
    where: 'Місце події',
    what: 'Подія',
    victims: 'Загрози',
    building: 'Будівля і під’їзд',
    who: 'Заявник',
    notes: 'Інші відомості',
    actions: 'Дії після прийому',
    city: 'Населений пункт',
    street: 'Вулиця',
    house: 'Будинок',
    flat: 'Квартира',
    landmark: 'Об’єкт, місце загоряння, орієнтир',
    count: 'Людей у небезпеці / постраждалих',
    explosion: 'Загроза вибуху',
    floors: 'Поверхів у будівлі',
    access: 'Особливості під’їзду',
    name: 'Прізвище заявника',
    phone: 'Телефон',
    notesLbl: 'Додаткові відомості',
  },
  actions: { alarm: 'Подати сигнал «Тривога»', report: 'Доповісти про виїзд' },
```

### Крок 54. `callScreen.js`: підписи розмови
Файл: `/Users/artem/Desktop/trainer112/frontend/js/callScreen.js`
Дія: замінити три фрагменти. Виконайте пари по черзі.

ЗНАЙТИ:
```javascript
    caller: 'Абонент',
    last: 'Остання репліка',
```

ЗАМІНИТИ НА:
```javascript
    caller: 'Заявник',
    last: 'Остання репліка',
```

ЗНАЙТИ:
```javascript
  who: { caller: 'Абонент', op: 'Ви', scene: 'Звук' },
```

ЗАМІНИТИ НА:
```javascript
  who: { caller: 'Заявник', op: 'Ви', scene: 'Звук' },
```

ЗНАЙТИ:
```javascript
placeholder: 'Напишіть, що скажете абоненту'
```

ЗАМІНИТИ НА:
```javascript
placeholder: 'Напишіть, що скажете заявнику'
```

### Крок 55. `callScreen.js`: типи подій і списки
Файл: `/Users/artem/Desktop/trainer112/frontend/js/callScreen.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
export const INCIDENT_TYPES = ['Пожежа', 'ДТП', 'Запах газу', 'Медична допомога', 'Утоплення', 'Насильство', 'Отруєння', 'Обстріл', 'Інше'];
export const VICTIM_STATES = ['Невідомо', 'Немає', 'Легкі', 'Середні', 'Тяжкі'];
```

ЗАМІНИТИ НА:
```javascript
export const INCIDENT_TYPES = ['Пожежа', 'ДТП', 'Газ, загазованість', 'Рятування людей', 'Обстріл, руйнування', 'Інша подія'];
export const EXPLOSION = ['Невідомо', 'Немає', 'Є'];
export const ACTION_IDS = ['alarm', 'report'];
```

### Крок 56. `callScreen.js`: значення за замовчуванням
Файл: `/Users/artem/Desktop/trainer112/frontend/js/callScreen.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
  card: {}, dirty: {}, saveStatus: 'idle',
```

ЗАМІНИТИ НА:
```javascript
  card: {}, dirty: {}, saveStatus: 'idle',
  actions: {},                  // { alarm: мс, report: мс } після натискання
```

### Крок 57. `callScreen.js`: вибір «Загроза вибуху» і кнопки дій (створення елементів)
Файл: `/Users/artem/Desktop/trainer112/frontend/js/callScreen.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
    const state = h('select', { id: 'f-victims_state', 'data-field': 'victims_state' },
      VICTIM_STATES.map(v => h('option', { value: v }, v)));
    state.addEventListener('change', () => props.onEditCard?.('victims_state', state.value));
    ref.fields.victims_state = state;
```

ЗАМІНИТИ НА:
```javascript
    const expl = h('select', { id: 'f-explosion', 'data-field': 'explosion' },
      EXPLOSION.map(v => h('option', { value: v }, v)));
    expl.addEventListener('change', () => props.onEditCard?.('explosion', expl.value));
    ref.fields.explosion = expl;
    ref.actionBtns = {};
    const actionButtons = ACTION_IDS.map(id => {
      const b = h('button', { type: 'button', class: 'btn', 'data-action': id }, MSG.actions[id]);
      b.addEventListener('click', () => props.onAction?.(id));
      ref.actionBtns[id] = b;
      return b;
    });
```

### Крок 58. `callScreen.js`: нова розмітка групи «Загрози» та далі
Файл: `/Users/artem/Desktop/trainer112/frontend/js/callScreen.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
      fieldInput('victims', M.count, { type: 'number', attrs: { min: '0', inputmode: 'numeric' } }),
      h('div', { class: 'field' }, h('label', { for: 'f-victims_state' }, M.state), state),
      h('div', { class: 'fgroup eyebrow' }, M.who),
      fieldInput('caller_name', M.name, { attrs: { placeholder: 'Як звати' } }),
      fieldInput('phone', M.phone, { type: 'tel', attrs: { inputmode: 'tel', placeholder: '+380…' } }),
      h('div', { class: 'fgroup eyebrow' }, M.notes),
      fieldInput('notes', M.notesLbl, { tag: 'textarea', attrs: { rows: 4 } }, 'f-wide'));
```

ЗАМІНИТИ НА:
```javascript
      fieldInput('victims', M.count, { type: 'number', attrs: { min: '0', inputmode: 'numeric' } }),
      h('div', { class: 'field' }, h('label', { for: 'f-explosion' }, M.explosion), expl),
      h('div', { class: 'fgroup eyebrow' }, M.building),
      fieldInput('floors', M.floors, { type: 'number', attrs: { min: '0', inputmode: 'numeric' } }),
      fieldInput('access', M.access, { attrs: { placeholder: 'Шлагбаум, ворота, двір…' } }),
      h('div', { class: 'fgroup eyebrow' }, M.who),
      fieldInput('caller_name', M.name, { attrs: { placeholder: 'Прізвище' } }),
      fieldInput('phone', M.phone, { type: 'tel', attrs: { inputmode: 'tel', placeholder: '+380…' } }),
      h('div', { class: 'fgroup eyebrow' }, M.notes),
      fieldInput('notes', M.notesLbl, { tag: 'textarea', attrs: { rows: 4 } }, 'f-wide'),
      h('div', { class: 'fgroup eyebrow' }, M.actions),
      h('div', { class: 'field f-wide', style: 'display:flex;gap:var(--s-3);flex-wrap:wrap' }, ...actionButtons));
```

### Крок 59. `callScreen.js`: підказка міста в картці
Файл: `/Users/artem/Desktop/trainer112/frontend/js/callScreen.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
placeholder: 'Наприклад, Кропивницький'
```

ЗАМІНИТИ НА:
```javascript
placeholder: 'Наприклад, Львів'
```

### Крок 60. `callScreen.js`: оновлення кнопок дій у `render()`
Файл: `/Users/artem/Desktop/trainer112/frontend/js/callScreen.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
    if (!same(p.saveStatus, o.saveStatus)) { ref.saveStatus.dataset.state = p.saveStatus; ref.saveStatus.textContent = MSG.save[p.saveStatus] || ''; }
```

ЗАМІНИТИ НА:
```javascript
    if (!same(p.saveStatus, o.saveStatus)) { ref.saveStatus.dataset.state = p.saveStatus; ref.saveStatus.textContent = MSG.save[p.saveStatus] || ''; }

    // кнопки дій: після натискання неактивні, з часом виконання
    for (const id of ACTION_IDS) {
      const t = (p.actions || {})[id];
      const b = ref.actionBtns[id];
      b.disabled = !liveOk || t != null;
      const text = t != null ? `✓ ${MSG.actions[id]} · ${formatTime(t / 1000)}` : MSG.actions[id];
      if (b.textContent !== text) b.textContent = text;
    }
```

### Крок 61. `callScreen.js`: літера в аватарі заявника
Файл: `/Users/artem/Desktop/trainer112/frontend/js/callScreen.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
h('span', { class: 'avatar', 'aria-hidden': 'true' }, 'А')
```

ЗАМІНИТИ НА:
```javascript
h('span', { class: 'avatar', 'aria-hidden': 'true' }, 'З')
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && node --check frontend/js/callScreen.js && echo screen-ok && grep -n "VICTIM_STATES\|victims_state\|112" frontend/js/callScreen.js | wc -l
```
Очікується: `screen-ok`, а під ним число `0` (перед нулем можуть бути пробіли).

### Крок 62. `cardAdapter.js`: повне переписування
Файл: `/Users/artem/Desktop/trainer112/frontend/js/cardAdapter.js`
Дія: ПЕРЕЗАПИСАТИ файл повністю (спочатку прочитайте наявний файл).

ВМІСТ ФАЙЛУ:
```javascript
// Перетворення картки виклику між полями інтерфейсу (місто, вулиця, будинок…) і контрактом бекенда
// (одне поле address, тип події малими літерами). Додаткові ключі ui_* бекенд ігнорує, а звіряння
// з фактами сценарію працює по складеній адресі.

export const INCIDENT_TO_WIRE = {
  "Пожежа": "пожежа", "ДТП": "ДТП", "Газ, загазованість": "газ", "Рятування людей": "рятування",
  "Обстріл, руйнування": "обстріл", "Інша подія": "інше",
};
const FROM_WIRE = Object.fromEntries(Object.entries(INCIDENT_TO_WIRE).map(([k, v]) => [v, k]));

export const EXPLOSION_TO_WIRE = { "Невідомо": "невідомо", "Немає": "ні", "Є": "так" };
const EXPLOSION_FROM_WIRE = Object.fromEntries(Object.entries(EXPLOSION_TO_WIRE).map(([k, v]) => [v, k]));

const clean = (v) => String(v ?? "").trim();

// ціле число не менше нуля або порожній рядок
function intOrEmpty(v) {
  const n = clean(v);
  return n === "" || Number.isNaN(Number(n)) ? "" : Math.max(0, Math.trunc(Number(n)));
}

export function composeAddress(c) {
  const street = clean(c.street), house = clean(c.house), flat = clean(c.flat);
  const parts = [clean(c.city), street, house, flat ? `кв. ${flat}` : "", clean(c.landmark)];
  return parts.filter(Boolean).join(", ");
}

export function toWire(ui) {
  const out = {
    incident_type: INCIDENT_TO_WIRE[ui.incident_type] || "",
    address: composeAddress(ui),
    victims: intOrEmpty(ui.victims),
    explosion: EXPLOSION_TO_WIRE[ui.explosion] || "",
    floors: intOrEmpty(ui.floors),
    access: clean(ui.access),
    caller_name: clean(ui.caller_name),
    phone: clean(ui.phone),
    notes: clean(ui.notes),
  };
  for (const k of ["city", "street", "house", "flat", "landmark"]) out[`ui_${k}`] = clean(ui[k]);
  return out;
}

export function fromWire(card) {
  const w = card || {};
  const hasUi = ["city", "street", "house", "flat", "landmark"].some((k) => w[`ui_${k}`] !== undefined);
  const ui = {
    incident_type: FROM_WIRE[w.incident_type] || "",
    victims: w.victims === undefined || w.victims === null ? "" : String(w.victims),
    explosion: EXPLOSION_FROM_WIRE[w.explosion] || "Невідомо",
    floors: w.floors === undefined || w.floors === null ? "" : String(w.floors),
    access: w.access || "",
    caller_name: w.caller_name || "",
    phone: w.phone || "",
    notes: w.notes || "",
  };
  for (const k of ["city", "street", "house", "flat", "landmark"]) ui[k] = hasUi ? (w[`ui_${k}`] || "") : "";
  if (!hasUi && w.address) ui.city = w.address;
  return ui;
}
```

### Крок 63. Тест `cardAdapter.test.js`: повне переписування
Файл: `/Users/artem/Desktop/trainer112/frontend/tests/cardAdapter.test.js`
Дія: ПЕРЕЗАПИСАТИ файл повністю (спочатку прочитайте наявний файл).

ВМІСТ ФАЙЛУ:
```javascript
import test from "node:test";
import assert from "node:assert/strict";
import { toWire, fromWire, composeAddress } from "../js/cardAdapter.js";

test("адреса складається в один рядок без порожніх частин", () => {
  assert.equal(composeAddress({ city: "Львів", street: "вул. Наукова", house: "17а", flat: "29", landmark: "" }), "Львів, вул. Наукова, 17а, кв. 29");
  assert.equal(composeAddress({ city: " ", street: "", house: "7" }), "7");
});
test("тип події і кількість постраждалих відповідають контракту бекенда", () => {
  const w = toWire({ incident_type: "Газ, загазованість", victims: "2", city: "Львів", street: "Наукова", house: "17а" });
  assert.equal(w.incident_type, "газ");
  assert.equal(w.victims, 2);
  assert.equal(w.address, "Львів, Наукова, 17а");
  assert.equal(toWire({ incident_type: "Рятування людей" }).incident_type, "рятування");
  assert.equal(toWire({ victims: "" }).victims, "");
  assert.equal(toWire({ victims: "abc" }).victims, "");
  assert.equal(toWire({ victims: "-3" }).victims, 0);
});
test("поверхи, загроза вибуху і під'їзд", () => {
  const w = toWire({ floors: "9", explosion: "Є", access: " шлагбаум " });
  assert.equal(w.floors, 9);
  assert.equal(w.explosion, "так");
  assert.equal(w.access, "шлагбаум");
  assert.equal(toWire({ explosion: "Немає" }).explosion, "ні");
  assert.equal(toWire({ explosion: "Невідомо" }).explosion, "невідомо");
  assert.equal(toWire({ floors: "" }).floors, "");
  assert.equal(toWire({ floors: "x" }).floors, "");
  assert.equal(toWire({ floors: "-2" }).floors, 0);
});
test("поля «стан постраждалих» більше немає", () => {
  const w = toWire({ victims_state: "Легкі" });
  assert.equal("ui_victims_state" in w, false);
  assert.equal("victims_state" in fromWire({}), false);
});
test("круговий обмін зберігає поля", () => {
  const ui = { incident_type: "Пожежа", victims: "1", explosion: "Є", floors: "5", access: "шлагбаум", city: "Львів", street: "Зелена", house: "3", flat: "9", landmark: "біля аптеки", caller_name: "Мельник", phone: "+380501234567", notes: "дим" };
  assert.deepEqual(fromWire(toWire(ui)), ui);
});
test("стара картка без ui_* потрапляє в поле міста, нічого не губиться", () => {
  const ui = fromWire({ incident_type: "пожежа", address: "Одеса, Дерибасівська 5", victims: 1 });
  assert.equal(ui.city, "Одеса, Дерибасівська 5");
  assert.equal(ui.incident_type, "Пожежа");
  assert.equal(ui.explosion, "Невідомо");
});
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && node --check frontend/js/cardAdapter.js && node --test frontend/tests/cardAdapter.test.js 2>&1 | grep -E "^ℹ (pass|fail)"
```
Очікується: два рядки `ℹ pass 6` і `ℹ fail 0`.

### Крок 64. `call.js`: стан дій
Файл: `/Users/artem/Desktop/trainer112/frontend/js/call.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
    mode: "voice", canOpenReport: false,
```

ЗАМІНИТИ НА:
```javascript
    mode: "voice", canOpenReport: false, actions: {},
```

### Крок 65. `call.js`: обробник `onAction` передається в екран
Файл: `/Users/artem/Desktop/trainer112/frontend/js/call.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
onToggleMic, onMicHold, onHome:
```

ЗАМІНИТИ НА:
```javascript
onToggleMic, onMicHold, onAction, onHome:
```

### Крок 66. `call.js`: функція `onAction`
Файл: `/Users/artem/Desktop/trainer112/frontend/js/call.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
  function onEnd() { if (finished) return; send("call.end", { reason: "operator" }); endUi("operator"); }
```

ЗАМІНИТИ НА:
```javascript
  function onEnd() { if (finished) return; send("call.end", { reason: "operator" }); endUi("operator"); }
  // кнопки «Тривога» і «Доповідь»: одна відправка на дію, час показуємо одразу
  function onAction(id) {
    if (finished || st.actions[id] != null) return;
    if (!send("operator.action", { action: id })) return;
    push({ actions: { ...st.actions, [id]: Math.round(st.elapsed * 1000) } });
  }
```

### Крок 67. `call.js`: дії зі знімка стану
Файл: `/Users/artem/Desktop/trainer112/frontend/js/call.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
          if (p.card && !Object.keys(st.dirty).length) patch.card = fromWire(p.card);
```

ЗАМІНИТИ НА:
```javascript
          if (p.card && !Object.keys(st.dirty).length) patch.card = fromWire(p.card);
          if (p.actions) patch.actions = p.actions;
```

### Крок 68. `call.js`: подія `operator.action` з сервера
Файл: `/Users/artem/Desktop/trainer112/frontend/js/call.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
        case "operator.final": addLine(p.uid, "op", p.text); break;
```

ЗАМІНИТИ НА:
```javascript
        case "operator.action": push({ actions: { ...st.actions, [p.action]: ev.t } }); break;
        case "operator.final": addLine(p.uid, "op", p.text); break;
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && node --check frontend/js/call.js && echo call-ok
```
Очікується: `call-ok`.

### Крок 69. `report.js`: назви ключових метрик
Файл: `/Users/artem/Desktop/trainer112/frontend/js/report.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
const STEP_KEYS = { address_asked: "До адреси", address_confirmed: "Підтвердження адреси", safety_advice: "Інструкція з безпеки", breathing_check: "Перевірка дихання" };
```

ЗАМІНИТИ НА:
```javascript
const STEP_KEYS = { address_asked: "До адреси", address_confirmed: "Підтвердження адреси", safety_advice: "Інструкція з безпеки", breathing_check: "Перевірка дихання", alarm: "До сигналу «Тривога»", people: "Загроза людям" };
```

### Крок 70. `report.js`: шапка звіту (чіп, причина результату)
Файл: `/Users/artem/Desktop/trainer112/frontend/js/report.js`
Дія: замінити два фрагменти. Виконайте пари по черзі.

ЗНАЙТИ:
```javascript
      h("span", { class: `chip ${passed ? "green" : "red"} self-start` }, passed ? "Зараховано" : "Не зараховано"),
```

ЗАМІНИТИ НА:
```javascript
      h("div.row.tight", h("span", { class: `chip ${passed ? "green" : "red"} self-start` }, passed ? "Зараховано" : "Не зараховано"),
        s.options && s.options.blind ? h("span.chip", "Випадкова ситуація") : null),
```

ЗНАЙТИ:
```javascript
      h("p.lead.m-0", headline),
```

ЗАМІНИТИ НА:
```javascript
      h("p.lead.m-0", headline),
      r.pass_reason ? h("p.small.m-0", r.pass_reason) : null,
```

### Крок 71. `report.js`: «Абонент» → «Заявник»
Файл: `/Users/artem/Desktop/trainer112/frontend/js/report.js`
Дія: замінити три фрагменти. Виконайте пари по черзі.

ЗНАЙТИ:
```javascript
rec.quote_who === "operator" ? "Ви" : "Абонент"
```

ЗАМІНИТИ НА:
```javascript
rec.quote_who === "operator" ? "Ви" : "Заявник"
```

ЗНАЙТИ:
```javascript
h("h3", "Паніка і довіра абонента")
```

ЗАМІНИТИ НА:
```javascript
h("h3", "Паніка і довіра заявника")
```

ЗНАЙТИ:
```javascript
h("b.muted", "Абонент: ")
```

ЗАМІНИТИ НА:
```javascript
h("b.muted", "Заявник: ")
```

### Крок 72. `report.js`: підстава і джерело кроку в чек-листі
Файл: `/Users/artem/Desktop/trainer112/frontend/js/report.js`
Дія: замінити два фрагменти. Виконайте пари по черзі.

ЗНАЙТИ:
```javascript
c.late ? h("span.chip.amber", "запізно") : null,
```

ЗАМІНИТИ НА:
```javascript
c.late ? h("span.chip.amber", "запізно") : null,
            c.basis === "методична" ? h("span.chip", "методична вимога") : null,
            c.basis === "потребує підтвердження" ? h("span.chip.amber", "потребує підтвердження") : null,
```

ЗНАЙТИ:
```javascript
          c.done ? h("div.q", h("span.mono", fmtT(c.t)),
```

ЗАМІНИТИ НА:
```javascript
          c.source ? h("div.tiny.muted", "Підстава: " + c.source) : null,
          c.done ? h("div.q", h("span.mono", fmtT(c.t)),
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && node --check frontend/js/report.js && echo report-ok
```
Очікується: `report-ok`.

### Крок 73. `methodist.js`: шаблон нового сценарію
Файл: `/Users/artem/Desktop/trainer112/frontend/js/methodist.js`
Дія: замінити п'ять фрагментів. Виконайте пари по черзі.

ЗНАЙТИ:
```javascript
  location: де знаходиться абонент
```

ЗАМІНИТИ НА:
```javascript
  location: де знаходиться заявник
```

ЗНАЙТИ:
```javascript
    say: ["Ольга."]
```

ЗАМІНИТИ НА:
```javascript
    say: ["Ольга Зінчук."]
```

ЗНАЙТИ:
```javascript
    truth: {caller_name: Ольга}
```

ЗАМІНИТИ НА:
```javascript
    truth: {caller_name: Зінчук}
```

ЗНАЙТИ:
```javascript
      deadline_s: 90
```

ЗАМІНИТИ НА:
```javascript
      deadline_s: 120
```

ЗНАЙТИ:
```javascript
victims: 1, caller_name: Ольга}
```

ЗАМІНИТИ НА:
```javascript
victims: 1, caller_name: Зінчук}
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && node --check frontend/js/methodist.js && echo methodist-ok
```
Очікується: `methodist-ok`.

### Крок 74. `standalone/boot.js`: екран завантаження
Файл: `/Users/artem/Desktop/trainer112/standalone/boot.js`
Дія: замінити один фрагмент.

ЗНАЙТИ:
```javascript
<span class="brand-badge">112</span><b>Тренажер оператора</b>
```

ЗАМІНИТИ НА:
```javascript
<span class="brand-badge">101</span><b>Тренажер оператора ПЗЧ</b>
```

### Контрольна точка 3. Фронтенд завершено
ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && for f in frontend/js/*.js standalone/boot.js; do node --check "$f" || echo "ПОМИЛКА $f"; done; echo syntax-done
```
Очікується: лише один рядок `syntax-done` (жодного `ПОМИЛКА`).

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && grep -rn "112" frontend/ --include='*.js' --include='*.html' | grep -v t112 | wc -l
```
Очікується: число `0` (перед нулем можуть бути пробіли).

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && node --test frontend/tests/cardAdapter.test.js 2>&1 | grep -E "^ℹ (pass|fail)"
```
Очікується: два рядки `ℹ pass 6` і `ℹ fail 0`.

---

# ЧАСТИНА 4. Збирання, документація, журнал

### Крок 75. Перезбирання автономного файла `trainer112.html`
Файл: `/Users/artem/Desktop/trainer112/trainer112.html`
Дія: виконати команду. Файл `trainer112.html` не редагується руками, його створює скрипт (потрібні Node.js і мережа для `npx esbuild`; якщо `npx` просить дозволу чи нічого не друкує, це нормально, зачекайте до кінця).

КОМАНДА:
```bash
cd /Users/artem/Desktop/trainer112 && python3 tools/build_standalone.py
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && grep -c "cardiac-arrest-01" trainer112.html; grep -c "Тренажер оператора ПЗЧ" trainer112.html; grep -c "house-fire-01" trainer112.html
```
Очікується: три числа, по одному на рядок. Перше `0` (архівні сценарії не потрапили у файл), друге і третє більші за `0`.

### Крок 76. `README.md`: назва, профіль, кількість тестів, приклади
Файл: `/Users/artem/Desktop/trainer112/README.md`
Дія: замінити шість фрагментів і додати розділ в кінець. Виконайте пари по черзі, кожен ЗНАЙТИ зустрічається у файлі рівно один раз.

ЗНАЙТИ:
```markdown
# Тренажер оператора 112 — мультиагентна симуляція дзвінка
```

ЗАМІНИТИ НА:
```markdown
# Тренажер оператора ПЗЧ — мультиагентна симуляція повідомлення про пожежу
```

ЗНАЙТИ:
```markdown
Курсант чує одного живого абонента, а за ним працює команда агентів над одним спільним станом дзвінка.
```

ЗАМІНИТИ НА:
```markdown
Курсант (оператор пункту зв'язку пожежно-рятувальної частини, НПРЧ ЛДУБЖД) чує одного живого заявника на лінії 101,
а за ним працює команда агентів над одним спільним станом дзвінка. Курсант заповнює картку виклику, подає сигнал «Тривога»
і доповідає про виїзд. Нормативна основа і всі рішення: `docs/pipeline/01-target-logic.md`, `docs/pipeline/02-normative-and-tech-decisions.md`.
```

ЗНАЙТИ:
```markdown
(67 тестів, ~6 с,
```

ЗАМІНИТИ НА:
```markdown
(73 тести, ~7 с,
```

ЗНАЙТИ:
```markdown
1. Увійдіть як **Курсант**, оберіть «Запах газу в квартирі» → «До дзвінка» → «Прийняти виклик».
2. Говоріть у мікрофон або друкуйте. Спробуйте: «Служба 112, що сталося?», «Назвіть точну адресу: вулицю і номер будинку»,
   «Повторюю: Київська, 17а, правильно?», «Не вмикайте світло, відкрийте вікна і виходьте з квартири».
```

ЗАМІНИТИ НА:
```markdown
1. Увійдіть як **Курсант**, натисніть «Почати тренування» (ситуацію система обирає сама) або оберіть «Запах газу в квартирі» в бібліотеці ситуацій → «Прийняти виклик».
2. Говоріть у мікрофон або друкуйте. Спробуйте: «Пожежно-рятувальна частина, оператор курсант Іваненко. Що сталося?»,
   «Назвіть точну адресу: населений пункт, вулицю і номер будинку», «Повторюю: Наукова, 17а, правильно?»,
   «Не вмикайте світло, відкрийте вікна і виходьте з квартири». Заповнюйте картку і натисніть «Подати сигнал «Тривога»».
```

ЗНАЙТИ:
```markdown
| 10 сценаріїв і базовий протокол (чернетка методики) |
```

ЗАМІНИТИ НА:
```markdown
| 10 сценаріїв (7 адаптованих і 3 нових; непрофільні лежать у `scenarios/archive/` і не завантажуються) і базовий протокол з 15 кроків, кожен із посиланням на норму (`source`) і ознакою підстави (`basis`) |
```

ЗНАЙТИ:
```markdown
house, apartment, people, name, phone, condition, reassure, instruct, confirm, rude, location_detail, any`.
```

ЗАМІНИТИ НА:
```markdown
house, apartment, people, name, phone, condition, reassure, instruct, confirm, rude, location_detail, floors, access, danger, any`.
```

ЗНАЙТИ:
```markdown
демо-вхід → корпоративний SSO з ролями (E1-03); метрики → OpenTelemetry + дашборд.
```

ЗАМІНИТИ НА:
```markdown
демо-вхід → корпоративний SSO з ролями (E1-03); метрики → OpenTelemetry + дашборд.

## Профіль і нормативна основа

Тренажер навчає оператора пункту зв'язку пожежно-рятувальної частини приймати повідомлення про пожежу та інші події.
Кожен крок протоколу має посилання на норму (`source`) і ознаку підстави (`basis`: «норма», «методична», «потребує підтвердження»);
вони видні у звіті, а для «потребує підтвердження» методист має звірити крок із чинним текстом наказу. Картка виклику
(місце, подія, загрози, поверхи, особливості під'їзду, заявник) звіряється з даними сценарію. Кнопки «Подати сигнал «Тривога»»
і «Доповісти про виїзд» на картці зараховуються як окремі кроки. Кнопка «Почати тренування» запускає випадкову ситуацію,
назва якої відкривається лише після завершення дзвінка.
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && grep -c "112" README.md; grep -c "73 тести" README.md; grep -c "Профіль і нормативна основа" README.md
```
Очікується: три числа. Перше може бути більшим за `0` (порти `8112` і назви `trainer112` законні), друге `1`, третє `1`.

### Крок 77. `DESIGN.md`: назва і опис ролі
Файл: `/Users/artem/Desktop/trainer112/DESIGN.md`
Дія: замінити два фрагменти. Виконайте пари по черзі.

ЗНАЙТИ:
```markdown
# Дизайн-система тренажера 112 · v2
```

ЗАМІНИТИ НА:
```markdown
# Дизайн-система тренажера оператора ПЗЧ · v2
```

ЗНАЙТИ:
```markdown
Режим **Operate**: користувач працює в стресі, тому читабельність і швидкість важливіші за декор.
```

ЗАМІНИТИ НА:
```markdown
Режим **Operate**: користувач (оператор пункту зв'язку пожежно-рятувальної частини) працює в стресі, тому читабельність і швидкість важливіші за декор.
Кнопки «Подати сигнал «Тривога»» і «Доповісти про виїзд» на картці виклику другорядні (`.btn`), єдина `.btn.primary` на головній сторінці курсанта: «Почати тренування».
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && head -4 DESIGN.md
```
Очікується: перший рядок `# Дизайн-система тренажера оператора ПЗЧ · v2`, у третьому рядку слова «Режим **Operate**: користувач (оператор пункту зв'язку пожежно-рятувальної частини)».

### Крок 78. Створення журналу виконання `04-implementation-log.md`
Файл: `/Users/artem/Desktop/trainer112/docs/pipeline/04-implementation-log.md`
Дія: створити файл з нижчого шаблону, а потім ЗАМІНИТИ кожне слово `ЗАПОВНИТИ` справжніми даними з ваших нотаток по кожному кроку. У колонці «Виконано» напишіть `так`, `ні` або `пропущено`. У колонці «Перевірка» напишіть `пройшла` або `не пройшла`, а для невдалої додайте один рядок виводу. У колонці «Відхилення» напишіть, що ви зробили інакше, ніж в інструкції, або залиште порожньою. Якщо ви зупинилися на якомусь кроці (див. розділ «Якщо перевірка не пройшла»), для всіх кроків, яких не виконували, напишіть `пропущено` і `не виконувалось`. Файл НЕ повинен містити слово `ЗАПОВНИТИ` після завершення.

ВМІСТ ФАЙЛУ:
```markdown
# Журнал виконання кроків з 03-implementation-steps.md

Виконавець: Haiku 5.5.
Дата завершення: ЗАПОВНИТИ

## Підсумок

| Показник | Значення |
|---|---|
| Кроків виконано з 79 | ЗАПОВНИТИ |
| Кроків зупинено або пропущено | ЗАПОВНИТИ |
| Результат `python -m pytest -q` | ЗАПОВНИТИ (очікувалось `73 passed`) |
| Результат `node --test frontend/tests/cardAdapter.test.js` | ЗАПОВНИТИ (очікувалось `pass 6`, `fail 0`) |
| Результат `node --check` по всіх файлах | ЗАПОВНИТИ |
| Результат `grep 112` у frontend | ЗАПОВНИТИ (очікувалось `0`) |

## Кроки

| Крок | Назва | Виконано | Перевірка | Відхилення |
|---|---|---|---|---|
| 1 | Перевірка вихідного стану | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 2 | models.py: власник події `operator.action` | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 3 | models.py: нові поля стану дзвінка | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 4 | models.py: редуктор подій | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 5 | models.py: інтенти та словник дій | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 6 | models.py: правило кроку (`StepRule`) | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 7 | models.py: джерело і підстава кроку (`ProtocolStep`) | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 8 | scenarios.py: перевірка правил із діями | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 9 | nlu.py: привітання підрозділу | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 10 | nlu.py: фрази про виїзд караулу | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 11 | nlu.py: уточнення місця та нові інтенти | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 12 | nlu.py: нові інтенти є питаннями | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 13 | nlu.py: розведення конфліктів «поверхи» / «люди» / «квартира» | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 14 | evaluator.py: повний новий вміст | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 15 | orchestrator.py: дії оператора | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 16 | service.py: випадковий сценарій на сервері | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 17 | main.py: назва, події курсанта, прихований сценарій, категорія | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 18 | bot.py: повний новий вміст | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 19 | reporter.py: джерело кроку, причина заліку, тексти | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 20 | normalizer.py: довідник вулиць і населених пунктів Львова | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 21 | caller.py і director.py: тексти промптів | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 22 | director.py: текст промпту | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 23 | Перенесення непрофільних сценаріїв в архів | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 24 | Базовий протокол `standard.yaml` (повний новий вміст) | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 25 | Сценарій `house-fire-01` (повний новий вміст) | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 26 | Сценарій `gas-leak-03` (повний новий вміст) | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 27 | Сценарій `road-accident-02` (повний новий вміст) | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 28 | Сценарій `shelling-rubble-01` (повний новий вміст) | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 29 | Сценарій `co-poisoning-01` (повний новий вміст) | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 30 | Сценарій `drowning-01` (повний новий вміст) | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 31 | Сценарій `elderly-fall-01` (повний новий вміст) | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 32 | Новий сценарій `apartment-fire-01` | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 33 | Новий сценарій `grass-fire-01` | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 34 | Новий сценарій `car-fire-01` | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 35 | Перевірка наявності джерела (source) у кроків протоколу | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 36 | Тести API: фраза оператора | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 37 | Тести API: два нові тести | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 38 | Тести модулів: імпорти | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 39 | Тести модулів: нові тести | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 40 | `index.html`: назва вкладки | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 41 | `index.html`: значок вкладки | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 42 | `core.js`: колір категорії «рятування» | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 43 | `core.js`: іконка категорії «рятування» | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 44 | `app.js`: значок і назва в шапці | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 45 | `app.js`: плитка курсанта на вході | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 46 | `app.js`: заголовок входу | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 47 | `app.js`: головна сторінка, секція «Почати тренування» | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 48 | `app.js`: бібліотека ситуацій | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 49 | `app.js`: історія, випадкова ситуація | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 50 | `app.js`: функція `startRandom` | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 51 | `callScreen.js`: назва екрана і лінії | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 52 | `callScreen.js`: текст вхідного виклику | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 53 | `callScreen.js`: тексти картки виклику | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 54 | `callScreen.js`: підписи розмови | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 55 | `callScreen.js`: типи подій і списки | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 56 | `callScreen.js`: значення за замовчуванням | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 57 | `callScreen.js`: вибір «Загроза вибуху» і кнопки дій (створення елементів) | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 58 | `callScreen.js`: нова розмітка групи «Загрози» та далі | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 59 | `callScreen.js`: підказка міста в картці | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 60 | `callScreen.js`: оновлення кнопок дій у `render()` | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 61 | `callScreen.js`: літера в аватарі заявника | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 62 | `cardAdapter.js`: повне переписування | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 63 | Тест `cardAdapter.test.js`: повне переписування | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 64 | `call.js`: стан дій | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 65 | `call.js`: обробник `onAction` передається в екран | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 66 | `call.js`: функція `onAction` | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 67 | `call.js`: дії зі знімка стану | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 68 | `call.js`: подія `operator.action` з сервера | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 69 | `report.js`: назви ключових метрик | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 70 | `report.js`: шапка звіту (чіп, причина результату) | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 71 | `report.js`: «Абонент» → «Заявник» | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 72 | `report.js`: підстава і джерело кроку в чек-листі | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 73 | `methodist.js`: шаблон нового сценарію | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 74 | `standalone/boot.js`: екран завантаження | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 75 | Перезбирання автономного файла `trainer112.html` | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 76 | `README.md`: назва, профіль, кількість тестів, приклади фраз | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 77 | `DESIGN.md`: назва і опис ролі | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 78 | Створення журналу `04-implementation-log.md` | ЗАПОВНИТИ | ЗАПОВНИТИ | |
| 79 | Остаточна перевірка всього | ЗАПОВНИТИ | ЗАПОВНИТИ | |

## Контрольні точки

| Контрольна точка | Після кроку | Очікувалось | Фактично |
|---|---|---|---|
| 1. Ядро бекенда | 22 | `68 passed` | ЗАПОВНИТИ |
| 2. Бекенд і тести | 39 | `73 passed` і `невдач 0` | ЗАПОВНИТИ |
| 3. Фронтенд | 74 | `syntax-done`, `0`, `pass 6` | ЗАПОВНИТИ |
| 4. Остаточна перевірка | 79 | див. крок 79 | ЗАПОВНИТИ |

## Зупинені кроки і причини

ЗАПОВНИТИ (напишіть `немає`, якщо жоден крок не зупинявся; інакше номер кроку, команду, що впала, і її вивід)

## Додаткові зауваження

ЗАПОВНИТИ (напишіть `немає`, якщо їх нема)
```

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && ls docs/pipeline/ && grep -c "ЗАПОВНИТИ" docs/pipeline/04-implementation-log.md
```
Очікується: у списку є `04-implementation-log.md`, а останнє число (кількість рядків зі словом ЗАПОВНИТИ) дорівнює `0` після того, як ви все заповнили.

### Крок 79. Остаточна перевірка всього (контрольна точка 4)
Файл: `/Users/artem/Desktop/trainer112`
Дія: виконати чотири перевірки нижче.

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && /private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python -m pytest -q -p no:cacheprovider . 2>&1 | tail -3
```
Очікується: `73 passed` (і, можливо, `1 warning`).

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && for f in frontend/js/*.js standalone/boot.js; do node --check "$f" || echo "ПОМИЛКА $f"; done; node --test frontend/tests/cardAdapter.test.js 2>&1 | grep -E "^ℹ (pass|fail)"
```
Очікується: два рядки `ℹ pass 6` і `ℹ fail 0`, без жодного рядка `ПОМИЛКА`.

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && ls scenarios scenarios/archive protocols
```
Очікується: у `scenarios` 10 файлів `.yaml` (`apartment-fire-01`, `car-fire-01`, `co-poisoning-01`, `drowning-01`, `elderly-fall-01`, `gas-leak-03`, `grass-fire-01`, `house-fire-01`, `road-accident-02`, `shelling-rubble-01`) і папка `archive`; в `archive` три файли (`cardiac-arrest-01`, `child-choking-01`, `domestic-violence-01`); у `protocols` файл `standard.yaml`.

ПЕРЕВІРКА:
```bash
cd /Users/artem/Desktop/trainer112 && grep -rn "112" frontend/ --include='*.js' --include='*.html' | grep -v t112 | wc -l
```
Очікується: число `0` (перед нулем можуть бути пробіли).

---

# Відхилення від 02

Усе, що в 02 прописано, реалізовано буквально, окрім нижчезазначеного. Кожне відхилення мінімальне, і причина в тому, що буквальна версія не працює.

1. Кнопка «Обрати ситуацію» на головній (крок 47). У 02 це `h("a.btn.big", {href:"#library"}, ...)`. Посилання `href="#library"` змінює `location.hash` і ламає маршрутизатор додатка (він очікує хеш виду `#/home`). Замість нього зроблено `h("button.btn.big", ...)` з `scrollIntoView` на елементі `#library`. Вигляд і призначення ті самі.
2. Підпис кнопок дій після натискання (крок 60). У 02 є два формулювання: «✓ + label + · + час» і «шаблон `Виконано о {mm:ss}`». Реалізовано перше: `✓ Подати сигнал «Тривога» · 00:42`, слова «Виконано о» не використано (дублюють одне одного).
3. Сценарій `grass-fire-01`, поле `access` (крок 33). У 02: `access [польов, асфальт]` і текст «польова дорога». Нормалізатор розпізнає слово «польова» як вулицю «Польова» і скидає підтвердження адреси, через що «ідеальний» бот не набирав зарахування. Тому текст факту «Ґрунтова дорога, після дощу розкисла, вантажівка пройде тільки з боку асфальту», а `card_truth.access` це `["ґрунтов", "асфальт"]`. За змістом нічого не змінилося.
4. Шаблон нового сценарію в методиста (крок 73). Окрім заміни імені на прізвище (вимога 02), `deadline_s` кроку `safety_advice` піднято з 90 до 120, бо правило з Б2 «не менше 120» стосується й шаблону.
5. Картка: початкове значення «Загроза вибуху» (крок 62). Якщо бекенд ще нічого не надіслав, список показує «Невідомо» (а не порожній вибір). У 02 про початкове значення не сказано.
6. Сценарій `gas-leak-03`, `road-accident-02`, `drowning-01`, `grass-fire-01`, `car-fire-01`, `apartment-fire-01`, `co-poisoning-01`, `shelling-rubble-01`, `house-fire-01`, `elderly-fall-01`. Тексти фактів, реплік і подій у 02 задані лише за змістом (хто, де, що), тому літеральні фрази складено за цим змістом. Усі ключові дані з таблиць 02 (адреси, прізвища, поверхи, `card_truth`, `deadline_s: 120`, ключові слова порад, `remove: [floors]`, перейменування `access` на `door_access`, `source` і `basis`) збережено. Для `gas-leak-03`, `shelling-rubble-01` і подібних додано перевизначення `fire_place` з назвою та прикладом під ситуацію (у 02 його прямо вказано лише для `road-accident-02`, `drowning-01`, `house-fire-01`; для інших це та сама ідея, що й у Б2 «перевизначення за потреби»).
7. Тест `test_nlu_access_and_danger` (крок 39). 02 каже «приклади з Б2»; у Б2 це набори патернів, а не готові фрази, тому тест використовує чотири конкретні фрази, складені з тих патернів.
8. Не змінювалися тексти `console.js`, `cabinet.js` і вкладки методиста («Абонент» у підписах пульта інструктора і редактора). У 02 для цього пункту названо лише `report.js`; решту не чіпано, щоб не розширювати обсяг.
9. Повна назва системи «Тренажер прийому повідомлень про пожежу · НПРЧ ЛДУБЖД» (Б8) використана лише в підзаголовку входу в скороченому вигляді («Прийом повідомлень про пожежу та інші події. Навчальна пожежно-рятувальна частина ЛДУБЖД.»), як і задано в таблиці Б8; окремого місця для повної назви в таблиці 02 немає.

---

# Якщо перевірка не пройшла

Спокійно. Нічого не вигадуйте і не «покращуйте».

## Порядок дій

1. Перечитайте крок ще раз від початку до кінця.
2. Порівняйте те, що ви записали у файл, із текстом у кроці СИМВОЛ У СИМВОЛ: відступи, лапки, дужки, коми, апострофи `'` і `’`, кирилицю і латиницю, зайві порожні рядки, зайві пробіли в кінці рядків. Найчастіше помилка саме тут.
3. Виправте розбіжність і ПОВТОРІТЬ ПЕРЕВІРКУ (спроба 2).
4. Якщо після двох спроб перевірка все ще не проходить:
   - ЗУПИНІТЬСЯ на цьому кроці. Не переходьте до наступних залежних кроків.
   - Запишіть у нотатки: номер кроку, команду перевірки, очікуваний і справжній вивід (останні 10 рядків).
   - Продовжуйте ЛИШЕ з кроками, які від зупиненого не залежать (див. нижче).
   - Наприкінці створіть журнал (крок 78) і впишіть зупинений крок у розділ «Зупинені кроки і причини».

## Які кроки незалежні

| Якщо зупинилися на | Що все одно можна виконувати |
|---|---|
| кроці 2 до 39 (бекенд) | кроки 40 до 74 (фронтенд), кроки 76 і 77, потім 78 і 79 (у 79 очікуйте, що частина перевірок не пройде, і запишіть це) |
| кроці в частині 3 (40 до 74) | решту кроків частини 3 з ІНШИХ файлів, кроки 76 і 77 і 78. Кроки в тому самому файлі після зупиненого пропустіть, бо вони залежать від попередніх змін у цьому файлі |
| кроці 75 | 76, 77, 78, 79 |
| кроці 76 або 77 | усі інші |

Зупинений крок в одному файлі блокує подальші кроки для того ж файла. Приклад: якщо крок 57 не пройшов, кроки 58, 60 не виконуйте (вони змінюють той самий `callScreen.js` на основі попередніх), але кроки 64 до 68 (інший файл `call.js`) можна.

## Типові причини

| Симптом | Що перевірити |
|---|---|
| Edit каже, що фрагмент ЗНАЙТИ не знайдено | крок уже виконано (тоді ЗАМІНИТИ НА вже у файлі); у вас на початку рядка табуляція замість пробілів; у блоці ЗНАЙТИ зайвий порожній рядок знизу; не збігаються апострофи `'` і `’`; ви правите не той файл (звірте шлях у `Файл:`) |
| Edit каже, що фрагмент знайдено більше ніж раз | ви скопіювали не весь блок ЗНАЙТИ (його частину); скопіюйте блок цілком |
| `SyntaxError` у Python | відступи (4 пробіли), не закрита дужка чи лапка, залишився фрагмент старого коду |
| `IndentationError` | змішані табуляції і пробіли; у блоках цього документа лише пробіли |
| `yaml.scanner.ScannerError` або «mapping values are not allowed here» | у заголовку `title:` є двокрапка з пробілом без лапок (у цьому документі такі заголовки в лапках); зайвий відступ; не закрита лапка |
| сценарій дає помилку валідації | у `Library().errors` прочитайте текст помилки. Найчастіше телефон без лапок, літера `М` чи `ГБО` латинська, відсутнє джерело (`source`) в кроці |
| `node --check` показує помилку | зайва чи пропущена дужка у вставленому JS; порівняйте блок ЗАМІНИТИ НА символ у символ |
| на контрольній точці кількість тестів `passed` не така, як очікується | прочитайте назву тесту, що впав, у виводі `pytest` (рядки `FAILED ...`); знайдіть крок, що змінює цю частину коду, і перевірте його |

## Чого робити не можна

- Не змінюйте тести, щоб вони «проходили».
- Не змінюйте очікуване число тестів.
- Не видаляйте рядки, які здаються зайвими.
- Не запускайте сервер на 8112 чи 8113.
- Не встановлюйте пакети.

---

# Чек-лист перевірки (для замовника, після виконання)

Усі команди виконуються з `/Users/artem/Desktop/trainer112`. `PY` це `/private/tmp/claude-501/-Users-artem-Desktop-trainer112/15283213-d3e0-4f37-953b-a9791065c843/scratchpad/venv/bin/python`.

| № | Перевірка | Команда | Очікується |
|---|---|---|---|
| Ч1 | Усі тести бекенда | `PY -m pytest -q -p no:cacheprovider .` | `73 passed` |
| Ч2 | Синтаксис усього JS | `for f in frontend/js/*.js standalone/boot.js; do node --check "$f" \|\| echo ERR $f; done` | жодного `ERR` |
| Ч3 | Тест адаптера картки | `node --test frontend/tests/cardAdapter.test.js` | `pass 6`, `fail 0` |
| Ч4 | Бібліотека: 10 валідних сценаріїв | `cd backend && PY -c "from app.scenarios import Library; l=Library(); print(len(l.items), sorted(l.errors))"` | `10 []` |
| Ч5 | Протокол: 15 кроків, вага 115, критичні | `cd backend && PY -c "from app.scenarios import load_base_protocol as b; s=b('standard'); print(len(s), sum(x.weight for x in s), [x.id for x in s if x.critical])"` | `15 115.0 ['address_asked', 'address_confirmed', 'alarm', 'people']` (число 115 може бути виведене як `115` або `115.0`) |
| Ч6 | Кожен крок усіх сценаріїв має `source` і `basis` | `PY -m pytest -q -p no:cacheprovider tests/test_units.py -k source` | `1 passed` |
| Ч7 | Бот «ідеальний» зараховується (≥ 90) по всіх сценаріях і гілках, «забуває адресу» падає | `PY -m pytest -q -p no:cacheprovider tests/test_regression.py` | `49 passed` |
| Ч8 | Приховування випадкового сценарію і дія «Тривога» | `PY -m pytest -q -p no:cacheprovider tests/test_api.py -k "random or alarm"` | `2 passed` |
| Ч9 | Архів не завантажується, але файли збережені | `ls scenarios/archive` | `cardiac-arrest-01.yaml`, `child-choking-01.yaml`, `domestic-violence-01.yaml` |
| Ч10 | У видимих текстах фронтенда немає «112» (К10) | `grep -rn "112" frontend/ --include='*.js' --include='*.html' \| grep -v t112 \| wc -l` | `0` |
| Ч11 | Службові імена не перейменовано | `grep -c "t112.user" frontend/js/core.js; grep -c "t112.theme" frontend/js/core.js; ls trainer112.html tools/build_standalone.py` | `1`, `1`, обидва файли існують |
| Ч12 | Залишки старої термінології в бекенді | `grep -rn "112" backend/app --include='*.py' \| grep -v "trainer112\|8112"` | рівно один рядок: шаблон привітання `"112"` у `backend/app/nlu.py` |
| Ч13 | Автономний файл перезібрано | `grep -c "cardiac-arrest-01" trainer112.html; grep -c "Тренажер оператора ПЗЧ" trainer112.html` | `0`, і число більше `0` |
| Ч14 | Журнал виконання існує і заповнений | `grep -c "ЗАПОВНИТИ" docs/pipeline/04-implementation-log.md; grep -c "^| [0-9]" docs/pipeline/04-implementation-log.md` | `0`, і число не менше `79` (79 кроків плюс 4 рядки контрольних точок) |
| Ч15 | README оновлено | `grep -c "73 тести" README.md; grep -c "Профіль і нормативна основа" README.md` | `1`, `1` |
| Ч16 | DESIGN.md оновлено | `head -1 DESIGN.md` | `# Дизайн-система тренажера оператора ПЗЧ · v2` |
| Ч17 | Кнопки дій і поля картки в екрані виклику | `grep -c "data-action\|f-explosion\|'floors'\|'access'" frontend/js/callScreen.js` | число не менше `4` |
| Ч18 | «Почати тренування» і прихована ситуація на головній | `grep -c "startRandom\|id: \"library\"" frontend/js/app.js` | число не менше `3` |
| Ч19 | Автоматичний сценарний огляд (КТ2, скрипт) | скрипт з контрольної точки 2 | остання лінія `запусків 39 невдач 0` |
| Ч20 | Ручний огляд у браузері (виконую я, не Haiku) | сервер на вільному порту (не 8112 і не 8113), вхід курсантом | на головній «Почати тренування»; у виклику картка з полями «Поверхів у будівлі», «Загроза вибуху», «Особливості під'їзду» і двома кнопками дій; після натискання кнопка неактивна з часом; у звіті видно «Підстава: ...» біля кроків |

Додатково я переглядаю: відхилення, записані в журналі; чи не змінено файли поза списком кроків; чи не лишилось нових файлів у проєкті, крім `scenarios/*.yaml`, `scenarios/archive/`, `docs/pipeline/04-implementation-log.md`.
